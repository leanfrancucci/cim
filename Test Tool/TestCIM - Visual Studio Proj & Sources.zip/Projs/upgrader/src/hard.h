/*
 * 		hard.h
 */

enum
{
	DEVICE_SAFE, DEVICE_TEST, DEVICE_VAL
};

void write_comm_tables( void );

void init_hardware( void );
void run_hardware( void );
void stop_hardware( void );
void deinit_hardware( void );

