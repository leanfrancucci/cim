/*
 *		terminal.c
 *			Implments 'terminal.h' functions
 *			Windows implementation
 * 				Version 1.0
 * 				EAM 2/5/07
 */

#include <conio.h>
#include <stdio.h>
#include <stdlib.h>

#include <windows.h>

#include "lang.h"
#include "terminal.h"

#define ESC		0x1b

enum
{
	NO, YES,
	ASSERT_MAX
};

static const char * const yes_any_answer[ NUM_LANG ] =
{
	" (Y/*)? : ",
	" (S/*)? : "
};


static char const yes_any[ NUM_LANG ][ ASSERT_MAX ] =
{
	{ 'N', 'Y' },
	{ 'N', 'S' }
};

static const char * const prompt_msgs_with_escape[ NUM_LANG ] =
{
	"Strike any key to continue (ESC to abort)......",
	"Cualquier tecla para continuar (ESC para abortar) ...."
};

static const char * const prompt_msgs[ NUM_LANG ] =
{
	"Strike any key to continue ....",
	"Cualquier tecla para continuar ...."
};

static const char * const abort_msgs[ NUM_LANG ] =
{
	"Aborting....",
	"Abortando...."
};

void
sak_flat( void )
{
	fprintf( stderr, prompt_msgs[ lang ] );
	getch();
}

void
sak( void )
{
	int c;

	fprintf( stderr, prompt_msgs_with_escape[ lang ] );
	c = getch();
	fprintf( stderr, "\n" );
	if( c == ESC )
	{
		fprintf( stderr, "\n%s\n", abort_msgs[ lang ] );
		exit( EXIT_SUCCESS );
	}
}

int
test_key( void )
{
	int c;

	if( !kbhit() )
		return 0;
	c = getch();
	if( c == ESC )
	{
		fprintf( stderr, "\n%s\n", abort_msgs[ lang ] );
		exit( EXIT_SUCCESS );
	}
	return c;
}

/*
 * 		select_yes_no:
 * 			Prints prompt command and awaits only an input char
 * 			for Yes or anything else for no
 * 			Prompts character selected, returns if yes selected
 */

int
select_yes_no( const char *fmt, ... )
{
	va_list ap;
	int is_yes;

	va_start( ap, fmt );
	vfprintf( stderr, fmt, ap );
	fprintf( stderr, yes_any_answer[ lang ] );
	va_end( ap );
	is_yes = ( toupper( getch() ) == yes_any[lang][YES] );
	printf( "%c\n", yes_any[lang][is_yes?YES:NO] );
	return is_yes;
}


