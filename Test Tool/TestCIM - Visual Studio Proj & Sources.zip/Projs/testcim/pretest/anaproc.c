/*
 * 	anaproc.cpp
 * 		Analog processing after
 * 		signal acquisition
 */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>


#include "fftw3.h"
#include "fft.h"

#define PI	3.14159265358979325
#define sqr(x)	pow((x),2.0)
#define DELTA_MIN	0.01

/*
 * 		calculate_fourier:
 * 		Receives:
 *			'n' number of data points
 *			'data" pointer to data
 *		Returns:
 *			'dc_level' pointer to level of dc component
 *			'rms_tot' pointer to value of true rms total value (including DC)
 *			'rms_var' pointer tovalue of true rms excluding DC
 *			'pbase' pointer to FFT slot of fundamental
 *			'pnoise' pointer to noise to signal ratio (perdentage)
 *			'distortion' in percentage as return of function
 */

double
calculate_fourier( int n, const double *data, double *dc_level, double *rms_tot, double *rms_var, int *pbase, double *pnoise )
{
	int nc, i;
	double *in;
	double *in2;
	fftw_complex *out;
	fftw_plan plan_backward;
	fftw_plan plan_forward;
	double freq_value, base_value, thd, power_sum_tot, power_sum_var, harmonic_sum, noise_sum;
	double temp, lim;

	nc = ( n / 2 ) + 1;

	in = (double *)fftw_malloc ( sizeof ( double ) * n );
	out = (fftw_complex *)fftw_malloc ( sizeof ( fftw_complex ) * nc );
	in2 = (double *)fftw_malloc ( sizeof ( double ) * n );

	memcpy( in, data, n * sizeof( double ) );
	plan_forward = fftw_plan_dft_r2c_1d ( n, in, out, FFTW_ESTIMATE );
	plan_backward = fftw_plan_dft_c2r_1d ( n, out, in2, FFTW_ESTIMATE );

	fftw_execute ( plan_forward );

	/*
	 * 	Calculate distortion
	 */

#ifdef FFT_TEST

	printf ( "Output FFT Coefficients: ++++++++++++++++++++++++\n" );

	for ( i = 0; i < nc; i++ )
	{
		printf( "  %3d  %12f  %12f\n", i, out[i][0], out[i][1] );
	}
#endif

	for( i = 1, *pbase = 0, lim = DELTA_MIN; i < nc ; ++i )
		if( ( temp = sqrt( sqr( out[i][0] ) + sqr( out[i][1] ) ) ) > lim )
			lim = temp;
		else if( lim > DELTA_MIN )
		{
			*pbase = i-1;
			break;
		}

	*dc_level = sqrt( sqr( out[0][0] ) + sqr( out[0][1] ) );
	if( *pbase == 0 )
	{
		thd = 0;
	} else
	{
		for( i = 1, harmonic_sum = 0, noise_sum = 0 ; i < nc ; ++i )
		{
			freq_value = sqr( out[i][0] ) + sqr( out[i][1] );
			if( i == *pbase )
				base_value = freq_value;
			else if( (i % *pbase) == 0 )
				harmonic_sum += freq_value;
			else
				noise_sum += freq_value;
		}
		thd = harmonic_sum/base_value * 100;
		*pnoise = noise_sum/( harmonic_sum + base_value ) * 100;
	}
	*dc_level /= n;

	for( i = 0, power_sum_tot = power_sum_var = 0 ; i < n ; ++i )
	{
		power_sum_tot += sqr( data[i] );
		power_sum_var += sqr( data[i] - *dc_level );
	}

	*rms_tot = sqrt( power_sum_tot/n );
	*rms_var = sqrt( power_sum_var/n );

	fftw_destroy_plan ( plan_forward );
	fftw_destroy_plan ( plan_backward );

	fftw_free ( in );
	fftw_free ( in2 );
	fftw_free ( out );


	return thd;
}

#define NUM_VALUES	1000

static double values[ NUM_VALUES ];

int
main( void )
{
	int i;
	double dc_level, rms_tot, rms_var, thd, noise;
	int base;
	int val;


	freopen( "output", "wt", stdout );
	for( i = val = 0 ; i < NUM_VALUES ; ++i )
	{
//		values[i] = (i % (NUM_VALUES/8)) == 0 ? val ^= 1: val;
		values[i] = 1 + 1*cos( 2*PI/NUM_VALUES * i ) + 1*sin( 6*PI/NUM_VALUES * i  );
		printf( "%3d -> %.5f\n", i, values[i] );
	}

	thd = calculate_fourier( NUM_VALUES, values, &dc_level, &rms_tot, &rms_var, &base, &noise );
	printf( "Total harmonic distortion %.4f%% dc_level = %.2f rms_tot = %.3f rms_var = %.3f base = %d, noise %.2f%%\n",
		thd, dc_level, rms_tot, rms_var, base, noise );

	return 0;
}


