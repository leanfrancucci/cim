/*
 * sbeqtst.h
 */

#define CMD_DELAY (100/SLEEP_BASE)

#define	PRIVDC		10		
#define	SECVDC		11	
#define	VBATT		12

#define	VD_PLUNGER	0x00	
#define	MD_PLUNGER	0x03	
//enum{ P_OPENED, P_CLOSED };

#define	VD_SW		0x01	
#define	MD_SW		0x04	
//enum{ L_LOCKED, L_UNLOCKED };

#define	VD_LOAD		0x02	
#define	MD_LOAD		0x05	
//enum{ UNCONNECTED, CONNECTED };

#define	STACKER1	0x06	
#define	STACKER2	0x07	
//enum{ S_UNINSTALLED, S_INSTALLED };

#define	TP1			13
#define	TP2			14 	
#define	TP3			15 	
#define	TP4			16 	
#define	TP5			17 	
#define	TP6			22 
#define	TP7			23 	
#define	TIP_S		24 	
#define	RING_S		25 	
#define	TIP_O		26 	
#define	RING_O		27 	
#define	TP8			42 	
#define	TP9			43 	
#define	TP10		44 	
#define	TP11		45 	
#define	TP12		46 	
#define	TP13		47 	
#define	TP14		67
//enum{ LOW, HIGH };

#define	BATTERY		30 	
//enum{ BATT_CONNECTED, BATT_UNCONNECTED };

#define	VALSW		31 	
//enum{ VALIDATOR1, VALIDATOR2 };

#define	RS485SW		32 	
//enum{ COMPRIMARY, COMSECONDARY };

#define	KEY_SW		35 	
//enum{ OPEN, CLOSE };

#define	VDCURR_PIN	36
#define	MDCURR_PIN	37 	
//enum{ DRIVED, NOT_DRIVED };

#define	PRI_PWR		33 	
#define	SEC_PWR		34 	
#define	LED0		50	
#define	LED1		51	
#define	LED2		52	
#define	LED3		53	
#define	LED4		54
#define	LED5		55	
#define	LED6		56	
#define	LED7		57	
//enum{ OFF, ON };

#define	DURESS_NC	63	
#define	DURESS_NO	64
#define	BURGLAR_NC	65
#define	BURGLAR_NO	66
//enum{ ACTIVATED, UNACTIVATED };

int get_lpin_tst( char number );
int get_apin_tst( char number );

void set_pin_tst( char who );
void clr_pin_tst( char who );
