/*
 * 		internal.c
 * 			functions for embedded actions
 *
 */

/*
 * 	System includes
 */

#include <windows.h>
#include <stdio.h>
#include <setjmp.h>

/*
 * 	Project includes
 */

#include "internal.h"
#include "pubvars.h"
#include "testsrc.h"


/*
 * 	Library includes
 */

#include "terminal.h"
#include "log.h"
#include "lang.h"
#include "messages.h"
#include "console.h"

extern jmp_buf	excel_buff;

/*
 *	Macros
 */

#define execute(member)										\
	do														\
	{														\
		if( cfuncs != NULL && cfuncs->member != NULL )		\
			(*cfuncs->member)();							\
	} while(0)

#define execute_arg(member,name)							\
	do														\
	{														\
		if( cfuncs != NULL && cfuncs->member != NULL )		\
			(*cfuncs->member)(name);						\
	} while(0)


/*
 * 	Static variables
 * 	uninitialized
 */

static char last_test[ 100 ];
static int count_test;
static jmp_buf test_buff;
static ITEST_T *cfuncs;
int global_errors;

/*
 * 	Static variables
 * 	initialized and constant
 */

static const char fail_string[] = "FAIL";
static const char pass_string[] = "PASS";
static char first_pass;

/*
 * 	Public functions
 */

/*
 * 	do_warning:
 * 		A fail in test has been detected
 * 		If 'fatal' != 0, test must terminate
 */

void
do_warning( int fatal )
{
	++global_errors;
	++count_test;
#ifndef ERRORS_SKIP
	if( fatal )
	{
		log_both( ending_tests_in_error[ lang ] );
		longjmp( test_buff, 1 );
	}
#endif
}

void
do_warning_analog( double min, double max, double value, const char *msg_english, const char *msg_spanish, int fatal )
{
	log_both( error_in_analog_test[ lang ], lang ? msg_spanish : msg_english, min/10, value/10, max/10 );
	do_warning( fatal );
}

void
make_warning_analog( double min, double max, double val, const char *msg_english, const char *msg_spanish, int fatal )
{
	if( val < min || val > max )
		do_warning_analog( min, max, val , msg_english, msg_spanish, fatal );
	else
	{
#ifdef GOOD_LOG_SCREEN
		fprintf( stderr, "\t\t --- %.2f\n", val );
#endif
		log( "\t\t--- %.2f", val );
	}
}


void
do_warning_digital( int must_be, int bit, const char *msg_english, const char *msg_spanish, int fatal )
{
	log_both( error_in_digital_test[ lang ], lang ? msg_spanish : msg_english, must_be, bit );
	do_warning( fatal );
}


/*
 * 	------	Operational functions
 */

/*
 * 	sak_user:
 * 		Show prompt and waits for key entry
 */

void
sak_user( const char *prompt_english, const char *prompt_spanish )
{
	int c;

	setrgb( RED_ON_BLACK );
	fprintf( stderr, "\t%s...", lang == ENGLISH ? prompt_english: prompt_spanish );
	setrgb( WHITE_ON_BLACK );
	while( !( c = test_key()) )
	;
	fputc( '\n', stderr );
	c = toupper( c );
	if( c == 'C' )
		return;
	longjmp( excel_buff, 1 );
}

/*
 * 	sleep_user:
 * 		Waits 'msecs' milliseconds to
 * 		continue
 */

void
sleep_user( unsigned long msecs )
{
//	log_both( sleeping_process[ lang ], msecs );
	Sleep( msecs );
}

/*
 * 	----- Information calls
 */

/*
 * 	begin_test:
 * 		Receives what test to be done
 */

void
begin_test( const char *test, const char *msg_english, const char *msg_spanish )
{
	execute_arg(on_begin_one_test,test);
	strncpy( last_test, test, sizeof( last_test ) );
	log_both( begin_test_msg[ lang ], test, lang ? msg_spanish: msg_english );
	count_test = 0;
}

/*
 * 	end_test:
 * 		Finalizes last test
 */

void
end_test( void )
{
	if( count_test != 0 )
	{
		execute(on_end_one_test_fail);
		setrgb( RED_ON_BLACK );	
		fprintf( stderr, end_test_msg_console[ lang ], fail_string );
	}
	else
	{
		execute(on_end_one_test_pass);
		setrgb( GREEN_ON_BLACK );	
		fprintf( stderr, end_test_msg_console[ lang ], pass_string );
	}
	setrgb( WHITE_ON_BLACK );
	log( end_test_msg[ lang ], last_test, count_test ? fail_string : pass_string );
}

/*
 * 	------- Internal calls
 */

/*
 * 	init_all_tests:
 * 		Called before executing Excel program
 */

void
init_all_tests( void )
{
	global_errors = 0;
	first_pass = 1;
}

/*
 * 	error_status:
 * 		Returns number of non fatal errors
 * 		reported
 * 		If 0, then test PASS
 */

int
error_status( void )
{
	return global_errors;
}

/*
 * 	begin_all_tests
 * 		Wrapper for do_tests in order
 * 		to setjmp it
 */

int
begin_all_tests( void )
{
	int status;

	if( setjmp( test_buff ) )
	{
		execute(on_end_all_tests_fail);
		return global_errors;
	}
	status = do_tests();
	execute(on_end_all_tests_pass);
	return status;
//	return setjmp( test_buff ) ? global_errors : do_tests();
}

/*
 *	set_func_tests
 *		Sets callback functions
 *		for each begin and end of tests
 *		Variable ITEST must be maintained
 *		outside this file, that is, by caller
 */

void
set_func_tests( ITEST_T *p )
{
	cfuncs = p;
	if( p->on_exit != NULL )
		atexit( p->on_exit );
}

int
is_first_pass( void )
{
	return first_pass;
}

void
first_pass_done( void )
{
	first_pass = 0;
}
		
