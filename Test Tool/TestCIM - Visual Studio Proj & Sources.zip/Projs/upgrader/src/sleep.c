/*
 * sleep.c
 */
#include <windows.h>
#include "timer.h"
#include "sleep.h"

static volatile unsigned sleep_timer;

static
void
timer_int( void )
{
	if( sleep_timer && --sleep_timer <= 0 )
		sleep_timer = 0;
}

void
sleep( unsigned ms )
{
	sleep_timer = ms;
	while( sleep_timer )
		Sleep(0);
}

void
init_timer( void )
{
	init_timer_hard( timer_int );
	enable_timer_interrupts();
}

