/*
 * 		utilstr.h
 *			Utilities regarding string manipulation
 */

#ifdef __cplusplus
extern "C" {
#endif


int is_string_all_digit( char *p );
char *str2lower( char *p );

#ifdef __cplusplus
}
#endif

