
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "lang.h"
#include "menutbl.h"
#include "options.h"
#include "log.h"
#include "sleep.h"
#include "hard.h"
#include "timer.h"

int debug_flag;				/*	For debugging without hardware	*/
extern char option_file[ MAX_OPTION_FILE ];

int
main( void )
{
	set_language( ENGLISH );
	
//	open_log();
	read_option_file(option_file);
	init_hardware();
	run_hardware();

	set_begin_char( 'a' );
	
	for(;;)
		do_menu( menus );
}




