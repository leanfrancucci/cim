/*
 * 	endians.h
 */

#include "mytypes.h"

#ifdef __cplusplus
extern "C" {
#endif

enum
{
	LITTLE_ENDIAN, BIG_ENDIAN
};

#define assign(to,fro,type) 									\
	do															\
	{															\
		(to) = (fro);											\
		byte_swap((unsigned char *)&(to), sizeof(type));		\
	} while(0)

void byte_swap( unsigned char *b, int n );
int test_byte_order( void );

#ifdef __cplusplus
}
#endif
