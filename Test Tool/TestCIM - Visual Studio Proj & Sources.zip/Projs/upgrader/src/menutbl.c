/*
 * menutbl.c
 */

#include <string.h>
#include "menutbl.h"
#include "datafs.h"
#include "dfstst.h"
#include "upgrade.h"
#include "upgtst.h"

static
int
_BlankDFS( void )
{
	filesys_blanking();
	return 1;
}

static
int
_ResetMCU( void )
{
	reset_mcu();
	return 1;
}

static
int
_CreateFile( void )
{
	do_create_file();
	return 1;
}

static
int
_StatFile( void )
{
	show_file_status();
	return 1;
}

static
int
_ReadFile( void )
{
	do_read_file();
	return 1;
}

static
int	
_WriteFile( void )
{
	do_write_file();
	return 1;
}

static
int	
_SeekFile( void )
{
	do_seek_file();
	return 1;
}

static
int	
_ReinitFile( void )
{
	do_reinit_file();
	return 1;
}

static
int	
_DFSInfo( void )
{
	show_sys_info();
	return 1;
}

static
int	
_BinDownload( void )
{
	do_bindownload();
	return 1;
}

static
int	
_BinUpload( void )
{
	do_binupload();
	return 1;
}

static
int
_GetVersion( void )
{
	do_getversion();
	return 1;
}

static
int
_CrateTstFile( void )
{
	create_test_file();
	return 1;
}

static
int
_FileSysTst( void )
{
	file_system_test();
	while( chk_grstatus() >= 0 );
	return 1;
}

static
int
_SecDown( void )
{
	secure_download();
	return 1;
}

static
int
_UpgradeTest( void )
{
	upgrade_test();
	return 1;
}

static
int
_Power_up( void )
{
	do_power_up();
	return 1;
}

const MENU_T menus[] =
{
	{	"Power Up",				_Power_up 		},
	{	"Safe Board Version",	_GetVersion 	},
	{	"Reset Safe Board",		_ResetMCU		},
	{	"Secure Download",		_SecDown	 	},
	{	"File Download",		_BinDownload	},
	{	"File Upload",			_BinUpload		},
	{	"Blank DFlash FS",		_BlankDFS		},
	{	"Create File",			_CreateFile		},
	{	"Status File",			_StatFile		},
	{	"Read File",			_ReadFile		},
	{	"Write File",			_WriteFile		},
	{	"Seek File",			_SeekFile		},
	{	"Reinit File",			_ReinitFile		},
	{	"DFlash FS Info",		_DFSInfo		},
	{	"Create Test File",		_CrateTstFile	},
	{	"File System Test",		_FileSysTst		},
	{	"Upragade Test",		_UpgradeTest	},
	{	"Exit to system",		terminate		},
	NULL
};

