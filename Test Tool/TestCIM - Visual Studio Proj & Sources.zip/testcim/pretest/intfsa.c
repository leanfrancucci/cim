/*
 * 		intfsa.cpp
 */

#include "intfsa.h"

#include "rerror.h"
#include "actdef.h"
#include "vars.h"

static int state = IDLE;

static void in_idle( void ), in_subproc( void ), in_test( void ), in_for( void ), in_for_sub( void ), in_error( void );

static void (* const moore_actions[ NUM_STATES ])( void ) =
{
	in_idle, in_subproc, in_test, in_for, in_for_sub, in_error
};

static
void
in_idle( void )
{
}

static
void
in_subproc( void )
{
}

static
void
in_test( void )
{
}

static
void
in_for( void )
{
}

static
void
in_for_sub( void )
{
}

static
void
in_error( void )
{
	fatal( "Instruction out of place in line %u", line );
}


void
parse( int action_num )
{
	if( action_num >= NUM_ACTIONS )
		fatal( "Action number %d out of range in line %u", action_num, line );
	state = parse_matrix[ action_num ][ state ];
	(*moore_actions[ state ])();
}

