/*
 * 		vars.h
 */
//#define MAX_FIELDS	20

#define COMMENT_CHAR	'#'

/*
 * 	Excel column labels
 *	Used to index 'fields'
 */

enum
{
	BEG_COMMENT, LABEL,	OPERATION,	PORT, 	LOW_VALUE,	HI_VALUE,	FATAL,	STEP_TEXT,	ENGLISH_TEXT,	SPANISH_TEXT,
	NUM_COLUMNS
};



extern char *fields[ NUM_COLUMNS ];
extern unsigned long line;


