/*
 * 		utildtim.h
 * 			Utilities regarding date and time
 */
#ifdef __cplusplus
extern "C" {
#endif

/*
 * 	get_date_time:
 * 		Gets pointer to constant string in the format
 * 		established by format string
 */

char *get_date_time( const char *fmt );

#ifdef __cplusplus
}
#endif
