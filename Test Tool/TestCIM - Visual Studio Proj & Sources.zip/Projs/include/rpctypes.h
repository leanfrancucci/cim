#ifndef __RPCTYPES_H__
#define __RPCTYPES_H__

#ifdef __cplusplus
extern "C" {
#endif

/*
 * 	rpctypes.h
 */

#include "mytypes.h"

typedef MInt		SBYTE;
typedef	MUInt		UBYTE;
typedef	uint		UWORD;
typedef	int			SWORD;
typedef ulong		UQUAD;
typedef long		SQUAD;

#define	IN(x)		const *x
#define OUT(x)		*x
#define INOUT(x)	*x

#ifdef __cplusplus
}
#endif

#endif
