/*
 * 		procfld.h
 */

enum
{
	PASS1, PASS2
};

void do_pass( int pass );
void generate_main_section( void );
void write_heading( void );


