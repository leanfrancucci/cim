#ifndef __C485DEFS_H__
#define __C485DEFS_H__

/*
 * 	c485defs.h
 */

#define	NUM_UID		16
#define NUM_PASS	8
#define NUM_VERSION	35
#define LEO_BUFF	250

#define NUM_VALS	2

/*
 * 		It defines facilty for
 * 		unlock command.
 */

enum
{
	SINGLE, DUAL
};


typedef struct
{
	char user[ NUM_UID ];
	char pass[ NUM_PASS ];
} UT_T;

typedef struct
{
	uchar	locker0_status;
	uchar	plunger0_status;
	uchar	locker1_status;
	uchar	plunger1_status;
	uchar	safebox_status;
	uchar	stacker0_status;
	uchar	stacker1_status;
	uchar	locker0_error;
	uchar	locker1_error;
} ST_T;


typedef struct
{
	uchar	user_id[NUM_UID];		/*	user_id is main search key							*/
	ushort	dev_list;				/*	dev_list only for high level software				*/
	uchar	pass0[ NUM_PASS ];		/*	In case validation, here goes the login password	*/
	uchar	pass1[ NUM_PASS ];
} USER_T;

/*
 * 	SUSER_T
 * 		For presenting credentials
 * 		of super user
 * 			Added on 12/1/2007
 */

typedef struct
{
	uchar user_id[ NUM_UID ];
	uchar pass0[ NUM_PASS ];
} SUSER_T;

typedef struct
{
	ushort	fd_used;
	ushort	fd_inerror;
	ushort	fs_page_errors;
	ulong	dfs_size;
} DFS_INFO_T;

/*
 * 	Structure for validators
 * 	communication data
 */

#if 0

/*
 * 	Old structure.
 * 	CIM must know about protocol
 */

typedef struct
{
	uchar	baud_rate;
	uchar	word_bits;
	uchar	parity;
	uchar	stop_bits;
	uchar	datalen_pos;
	uchar	sync;
} VALC_T;

#else

/*
 * 	New structure.
 * 	CIM is transparent
 *
 * 	Changed on 12/1/2007
 */

/*
 * 	VALCOMM_T
 * 		For configuration of asynchronus channels
 * 		for validator
 * 			Included on 12/1/2007
 */

typedef struct
{
	uchar	word_conf;		/*	Word buts, parity, stop bits		*/
	uchar	baud;			/*	Codified baud rate					*/
	uchar	start_timeout;	/*	Start timeout in seconds			*/
} VALCOMM_T;


#endif

typedef struct
{
	uchar	unit_size;		/*	Size of file record					*/
	uchar	file_type;		/*	Type of file (RANDOM or QUEUE		*/
	ulong	num_units;		/*	File capacity in terms of records	*/

	ulong	out_index;		/*	indices are measured in terms of....	*/
	ulong	in_index;		/*	....number of elements from beginning	*/
	ulong	num_elems;		/*	Elements between in_index and out_index	*/

	ulong	position;		/*	Current position for RANDOM	*/
} FILESYS_T;

#endif
