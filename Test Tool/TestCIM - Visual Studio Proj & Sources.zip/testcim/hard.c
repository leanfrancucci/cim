/*
 * 		hard.c
 */

/*
 * 	System includes
 */

#include <string.h>

/*
 * 	Project includes
 */

#include "mytypes.h"
#include "hard.h"
#include "serdefs.h"
#include "hard485.h"
#include "hardtest.h"
#include "hardval.h"
#include "options.h"
#include "rerror.h"
#include "serial.h"
#include "timer.h"
#include "valproc.h"

/*
 * 	Defines
 */

#define MAX_TIMERS	10

/*
 * 	External variables uninitialized
 */

SERIAL_T serials[ NUM_SERIALS ];				/*	Table to satisfy serdefs.h	*/

/*
 * 	Static variables uninitialized
 */

static SERIAL_CBACK_T serial_callback;			
static void (*timers[ MAX_TIMERS ])( void );

/*
 * 	Static functions
 */

/*
 *	timer_tick:
 *		Sweeps all timer routines that are not NULL
 *		in array 'timers'
 */

static
void
timer_tick( void )
{
	void (**p)(void);
	int i;

	for( i = 0, p = timers ; i < MAX_TIMERS ; ++i, ++p )
		if( *p != NULL )
			(**p)();
}

/*
 *	write_comm_device_table:
 *		Writes table pointed by ps for 'device'
 *		with data in p
 */

static
void
write_comm_device_table( int device, COMM_T *p )
{
	SERIAL_T *ps;

	if( device >= NUM_SERIALS )
		fatal( "%s: device %u exceeds limit (%u)", __FUNCTION__, device, NUM_SERIALS );

	ps = &serials[ device ];

	strcpy( ps->com_name, p->com_name );
	ps->baud = p->baud;
	ps->bit_num = p->bit_num;
	ps->parity = p->parity;
	ps->stop_num = p->stop_num;
	ps->is_modem = 0;
}

/*
 *	send_comm_frame:
 *		sends 'qty' data pointed by 'p' to
 *		'device'
 */

static
void
send_comm_frame( uint device, uchar *p, uint qty )
{
	while( qty-- )
		tx_data( device, *p++ );
}

/*
 *	send_safe_frame:
 *		sends frame pointed by 'p' and of length 'qty'
 *		to device SAFE
 */

static
void
send_safe_frame( uchar *p, uint qty )
{
	send_comm_frame( DEVICE_SAFE, p, qty );
}

/*
 *	send_test_frame:
 *		sends frame pointed by 'p' and of length 'qty'
 *		to device TEST
 */

static
void
send_test_frame( uchar *p, uint qty )
{
	send_comm_frame( DEVICE_TEST, p, qty );
}

/*
 *	send_val_frame:
 *		sends frame pointed by 'p' and of length 'qty'
 *		to device VAL
 */

static
void
send_val_frame( uchar *p, uint qty )
{
	send_comm_frame( DEVICE_VAL, p, qty );
}

/*
 *	init_comm_safe:
 *		Inits device SAFE: comm section and timer section
 */

static
void
init_comm_safe( void )
{
	memset( &serial_callback, 0, sizeof( serial_callback ) );
	serial_callback.rx = init_safe_channel( send_safe_frame );
	init_serial_hard( DEVICE_SAFE, &serial_callback );
	timers[ DEVICE_SAFE ] = init_safe_timer( options.safe.timeout1, options.safe.timeout2 );
}

/*
 *	init_comm_safe:
 *		Inits device TEST: comm section and timer section
 */

static
void
init_comm_test( void )
{
	memset( &serial_callback, 0, sizeof( serial_callback ) );
	serial_callback.rx = init_test_channel( send_test_frame );
	init_serial_hard( DEVICE_TEST, &serial_callback );
	timers[ DEVICE_TEST ] = init_test_timer( options.test.timeout1, options.test.timeout2 );
}

/*
 *	init_comm_val:
 *		Inits device VAL: comm section and timer section
 */

static
void
init_comm_val( void )
{
	memset( &serial_callback, 0, sizeof( serial_callback ) );
	serial_callback.rx = init_val_channel( send_val_frame );
	init_serial_hard( DEVICE_VAL, &serial_callback );
	timers[ DEVICE_VAL ] = init_val_timer( options.val.timeout1, options.val.timeout2 );}

/*
 *	init_all_comms:
 */

static
void
init_all_comms( void )
{
	init_comm_safe();
	init_comm_test();
	init_comm_val();
}

/*
 *	connect_all_comms:
 */

static
void
connect_all_comms( void )
{
	connect_serial( DEVICE_SAFE );
	connect_serial( DEVICE_TEST );
	connect_serial( DEVICE_VAL );
}

/*
 *	disocnnect all comms
 */

static
void
disconnect_all_comms( void )
{
	disconnect_serial( DEVICE_SAFE );
	disconnect_serial( DEVICE_TEST );
	disconnect_serial( DEVICE_VAL );
}

/*
 *	Public functions
 */

/*
 *	init_hardware:
 *		Inits timer and all comms
 *		Hardware is initted but not running
 */

void
init_hardware( void )
{
	init_timer_hard( timer_tick );
	init_all_comms();
}

/*
 *	run_hardware:
 *		Sets to run all hardware previously initted
 */

void
run_hardware( void )
{
	enable_timer_interrupts();
	connect_all_comms();
	start_validator();
	resume_validator();
}

/*
 *	write_comm_tables:
 *		Writes in devices comm tables from that
 *		which is in options structure
 */

void
write_comm_tables( void )
{
	write_comm_device_table( DEVICE_SAFE, &options.safe );
	write_comm_device_table( DEVICE_TEST, &options.test );
	write_comm_device_table( DEVICE_VAL , &options.val );
}

/*
 *	stop_hardware:
 *		Stops hardware but maintained initted
 */

void
stop_hardware( void )
{
	destroy_validator();
	disable_timer_interrupts();
	disconnect_all_comms();
}

/*
 *	deinit_hardware:
 *		Hardware is uninitialized
 */

void
deinit_hardware( void )
{
}




