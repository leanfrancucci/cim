/*
 * 	cmd485.c
 * 		Client server to communicate with SAFE
 */

/*
 * 	System includes
 */

#include <string.h>
#include <setjmp.h>

/*
 * 	Project includes
 */

#include "cmd485.h"
#include "cscmds.h"
#include "rxtx485.h"
#include "rerror.h"
#include "endians.h"
#include "str485.h"

/*
 * 	Defines
 */

#define MAX_RETRIES		5
#define NO_VERIFY		-1

/*
 * 	Macros
 */


#define copy_item(to,fro)	memcpy((to),(fro),sizeof(to))

#define do_send_rcv(dev,cmd,qty,vqty)								\
	do																\
	{																\
		send_rcv((dev),(cmd),(qty));								\
		if( (vqty) >= 0 && qty_rec != (vqty) )						\
			fatal( "%s-%s: Bad quantity received %d, awaited %d",	\
				__FILE__, __FUNCTION__, qty_rec, (vqty) ); 			\
	} while(0)

#define make_send_rcv(dev,cmd,qty,vqty)								\
	if( error = setjmp( catch_buffer ) )							\
		return error;												\
	do																\
	{																\
		send_rcv((dev),(cmd),(qty));								\
		if( (vqty) >= 0 && qty_rec != (vqty) )						\
			fatal( "%s-%s: Bad quantity received %d, awaited %d",	\
				__FILE__, __FUNCTION__, qty_rec, (vqty) ); 			\
	} while(0)

/*
 * 	Static vaiables
 * 		uninitialized
 */

/*
 * 	Buffers for send and receive
 */

static SBOX_T	sbox_out, sbox_in;

/*
 * 	Context buffer for proxy exceptions
 */

static jmp_buf	catch_buffer;
static int		error;
static int 		qty_rec;

/*
 * 	Static variables
 * 		initialized
 */

static const char *msg[NUM_485_ERRORS] =
{
	"rs485_ok",	"rs485_timeout", "rs485_check_error"
};


/*
 * 	Static functions
 */

/*
 * 	send_rcv:
 * 		Receives device, op_code or command of
 * 		remote function to execute and
 *		payload byte quantity.
 *		Send buffer is 'sbox_out' and
 *		receive buffer is 'sbox_in'.
 *		Loads device, command and quantity in
 *		protocol header.
 *		Then sits in a retry loop sending
 *		and receiving
 *
 *		If returns a positive number, then command
 *		succesfully executed and value returned is
 *		the payload received quantity.
 *
 *		If the frame received marks an error, returns
 *		what in the frame error code is (a negative number)
 *
 *		If retries exceeded, then returns CMD_COM_ERROR
 *		which is also a negative number exceeding that contained
 *		in the protocol
 */

static
void
send_rcv( uint dev, uint code, ushort qty )
{
	MUInt cmd;
	uint retry;

	sbox_out.data_head.dev = (uchar)(dev);
	sbox_out.data_head.cmd_no = (uchar)code;
#ifdef DATA_2
	assign( sbox_out.data_head.ndata, qty, ushort );
#else
	sbox_out.data_head.ndata = (uchar)qty;
#endif
	for( retry = 0 ; retry < MAX_RETRIES ; ++retry )
	{
		send_packet_485( (uchar *)&sbox_out, qty + sizeof( DHEAD_T ) );
		if( ( qty_rec = rcv_packet_485( (uchar *)&sbox_in, sizeof( sbox_in ) ) ) < 0 )
		{
			debug( "%s: %s", __FUNCTION__, msg[-qty_rec] );
			continue;
		}

		if( ( cmd = sbox_in.data_head.cmd_no ) == SBOX_SUCCESS 
			|| ( sbox_in.data_head.cmd_no == NO_CMD && cmd == NO_CMD ) )
		{
			qty_rec -= sizeof( DHEAD_T );
			return;
		}
		
		if( cmd == SBOX_FAILURE )
		{
			if( sbox_in.data_head.ndata == 0 )
				fatal( "%s-%s: No error code submitted", __FILE__, __FUNCTION__ );
			qty_rec -= sizeof( sbox_in.data.svcl_errorcode.error_code );
			longjmp( catch_buffer, -sbox_in.data.svcl_errorcode.error_code );
		}
		
		if( cmd != SBOX_NACK )
			fatal( "%s-%s: Bad command received: %02.2X", __FILE__, __FUNCTION__, cmd );
		
		debug( "%s: NAK received", __FUNCTION__ );
	}
	debug( "%s: Retries exceeded", __FUNCTION__ );
	longjmp( catch_buffer, CMD_COMM_ERROR );
}

/*
 * 	Public functions
 * 		All functions here constitutes
 * 		the proxy functions for server
 */

/*
 * 	unlock:
 * 		Supports one or two users. type says
 * 		how many users.
 * 		In case of two users validation, there
 * 		is another argument of type ptr to UT_T
 * 		Function returns < 0 in case of error
 */

SBYTE
unlock( UBYTE dev, UBYTE pwd_type, UT_T IN(user1), UBYTE OUT(match_type1), UT_T IN(user2), UBYTE OUT(match_type2) )
{
	CLSV_UNLOCK *ps;
	SVCL_UNLOCK *pr;
	int qty, error;

	if( user1 == NULL || match_type1 == NULL || user2 == NULL || match_type2 == NULL )
		fatal( "%s-%s: NULL pointer received", __FILE__, __FUNCTION__ );

	ps = &sbox_out.data.clsv_unlock;
	pr = &sbox_in.data.svcl_unlock;

	copy_item( ps->ut1.user, user1->user );
	copy_item( ps->ut1.pass, user1->pass );

	if( ( ps->pwd_type = (uchar)pwd_type ) == DUAL )
	{
		qty = sizeof( *ps );
		copy_item( ps->ut2.user, user2->user );
		copy_item( ps->ut2.pass, user2->pass );
	} else
		qty = sizeof( *ps ) - sizeof( UT_T );

	make_send_rcv( dev, UNLOCK, (ushort)qty, sizeof( *pr ) );

	*match_type1 = pr->match_type0;
	*match_type2 = pr->match_type1;

	return 0;
}


/*
 * 	lock:
 * 		Blocks SafeLock lock
 */

SBYTE
lock( UBYTE dev )
{
	make_send_rcv( dev, LOCK, 0, 0 );
	return 0;
}

/*
 * 	actrl:
 * 		Enables/disables an alarm
 */

SBYTE
actrl( UBYTE dev, UBYTE disena )
{
	sbox_out.data.clsv_actrl.disena = (uchar)disena;

	make_send_rcv( dev, ACTRL, sizeof( CLSV_ACTRL ), 0 );

	return 0;
}

/*
 *	version:
 *		Gets hardware and firmware version
 */

SBYTE
version( UBYTE dev, char OUT(swfw_version) )
{
	if( swfw_version == NULL )
		fatal( "%s-%s: NULL pointer received", __FILE__, __FUNCTION__ );

	make_send_rcv( dev, VERSION, 0, NO_VERIFY );

	strcpy( swfw_version, sbox_in.data.svcl_version.swfw_version );

	return 0;
}

/*
 * 	model:
 * 		Gets the SafeBox model
 */

SBYTE
model( UBYTE dev, UBYTE OUT(model) )
{
	if( model == NULL )
		fatal( "%s-%s: NULL pointer received", __FILE__, __FUNCTION__ );

	make_send_rcv( dev, MODEL, 0, sizeof( SVCL_MODEL ) );

	*model = sbox_in.data.svcl_model.model;

	return 0;
}

/*
 * 	shutdown:
 * 		Enables interruption of backup power
 */

SBYTE
shutdown( UBYTE dev )
{
	make_send_rcv( dev, SHUTDOWN, 0, 0 );
	return 0;
}

/*
 * 	gr1_status:
 * 		Gets state of group1
 */

SBYTE
gr1_status( UBYTE dev, ST_T OUT(status) )
{
	if( status == NULL )
		fatal( "%s-%s: NULL pointer received", __FILE__, __FUNCTION__ );

	make_send_rcv( dev, GR1_STATUS, 0, sizeof( SVCL_GR1_STATUS ) );

	*status = sbox_in.data.svcl_gr1_status.status;

	return 0;
}

/*
 * 	addusr:
 * 		For adding user from data in 'user'
 * 		(validated from 'suser')	Added on 12/1/2007
 * 		Returns USERS_OK in case of succcess or a negative number
 * 		in error case
 */

SBYTE
addusr( UBYTE dev, USER_T IN(user), SUSER_T IN(suser) )		/*	Modified 12/1/2007	*/
{
	CLSV_ADDUSR *ps;

	if( user == NULL || suser == NULL )
		fatal( "%s-%s: NULL pointer received", __FILE__, __FUNCTION__ );


	ps = &sbox_out.data.clsv_addusr;

	assign( ps->user.dev_list, user->dev_list, ushort );
	copy_item( ps->user.pass0, user->pass0 );
	copy_item( ps->user.pass1, user->pass1 );
	copy_item( ps->user.user_id, user->user_id );
	copy_item( ps->suser.user_id, suser->user_id );
	copy_item( ps->suser.pass0, suser->pass0 );

	make_send_rcv( dev, ADDUSR, sizeof( CLSV_ADDUSR ), 0 );

	return 0;
}

/*
 * 	delusr:
 * 		Eliminates 'user_id' if exists
 * 		*puser_id is truncated to NUM_UID bytes.
 * 		(Must be validated by a super user)		Added on 12/1/2007
 * 		Returns USERS_OK in case of succcess or a negative number
 * 		in error case
 * 		Changed argument for user_id from version 2.2 and up
 */

SBYTE
delusr( UBYTE dev, uchar IN(usrid), SUSER_T IN(suser) )		/*	Modified 12/1/2007	*/
{
	CLSV_DELUSR *ps;

	if( usrid == NULL || suser == NULL )
		fatal( "%s-%s: NULL pointer received", __FILE__, __FUNCTION__ );

	ps = &sbox_out.data.clsv_delusr;

	copy_item( ps->usrid, usrid );
	copy_item( ps->suser.user_id, suser->user_id );
	copy_item( ps->suser.pass0, suser->pass0 );

	make_send_rcv( dev, DELUSR, sizeof( CLSV_DELUSR ), 0 );

	return 0;
}

/*
 * 	editusrpass:
 * 		Edits user information stored under 'user_id' of '*pold'.
 * 		Presents for logging one of the passwords in 'pass0'.
 * 		(Password in pass1 is don't care).
 * 		Only passwords may be edited; 'edit_pass' says which one or both
 * 		Returns USERS_OK in case of succcess or a negative number
 * 		in error case
 *
 */

SBYTE
editusrpass( UBYTE dev, uchar IN(usrid), uchar IN(old_pwd), uchar IN(new_pwd), MUInt edit_pass )
{
	CLSV_EDITUSRPASS *ps;

	if( usrid == NULL || old_pwd == NULL || new_pwd == NULL )
		fatal( "%s-%s: NULL pointer received", __FILE__, __FUNCTION__ );

	ps = &sbox_out.data.clsv_editusrpass;

	copy_item( ps->usrid, usrid );
	copy_item( ps->old_pwd, old_pwd );
	copy_item( ps->new_pwd, new_pwd );
	ps->edit_pass = (uchar)edit_pass;

	make_send_rcv( dev, EDITUSR, sizeof( CLSV_EDITUSRPASS ), 0 );

	return 0;
}

/*
 * 	getusrdev:
 * 		This call returns '*p_dev_list' related with 'user_id'
 * 		in case 'user_id' exists
 * 		*puser_id is truncated to NUM_UID bytes.
 * 		Returns USERS_OK in case of succcess or a negative number
 * 		in error case
 * 		Changed argument for user_id from version 2.2
 */

SBYTE
getusrdev( UBYTE dev, uchar IN(usrid), UWORD OUT(devlist) )
{
	if( usrid == NULL || devlist == NULL )
		fatal( "%s-%s: NULL pointer received", __FILE__, __FUNCTION__ );

	copy_item( sbox_out.data.clsv_getusrdev.usrid, usrid );
	make_send_rcv( dev, GETUSRDEV, sizeof( CLSV_GETUSRDEV ), sizeof( SVCL_GETUSRDEV ) );
	assign( *devlist, sbox_in.data.svcl_getusrdev.devlist, ushort);

	return 0;
}

/*
 * 	users_set_devlist:
 * 		This calls set 'dev_list' for 'user_id' in case
 * 		'user_id' exists.
 * 		*puser_id is truncated to NUM_UID bytes.
 * 		'dev_list' is truncated to 16 bits.
 * 		(A super user must validate this command)		Added on 12/1/2007
 * 		Returns USERS_OK in case of succcess or a negative number
 * 		in error case
 * 		Changed argument for user_id from version 2.2
 */

SBYTE
setusrdev( UBYTE dev, uchar IN(usrid), UWORD devlist, SUSER_T IN(suser) )	/*	Modified 12/1/2007	 */
{
	CLSV_SETUSRDEV *ps;

	if( usrid == NULL || suser == NULL )
		fatal( "%s-%s: NULL pointer received", __FILE__, __FUNCTION__ );

	ps = &sbox_out.data.clsv_setusrdev;

	copy_item( ps->usrid, usrid );
	assign( ps->devlist, (ushort)devlist, ushort );
	copy_item( ps->suser.user_id, suser->user_id );
	copy_item( ps->suser.pass0, suser->pass0 );

	make_send_rcv( dev, SETUSRDEV, sizeof( CLSV_GETUSRDEV ), 0 );

	return 0;
}

/*
 * 	valusr:
 * 		Validates one user
 * 			In case of two users validation
 * 			this function must be called twice
 * 			as for example in case both must be ok:
 *				user_validation( &user0 ) == USER_OK && user_validation( &user1 ) == USER_OK;
 *			or in case one user must be validated
 *				user_validation( &user0 ) == USER_OK || user_validation( &user1 ) == USER_OK;
 *			Significance of arguments and return values same as 'users_pass_edit'
 *			Returns:
 *				USERS_OK if pass0 of '*p' matches with any one of the two passwords
 *				for user_id in '*p' or negative in error case.
 *				In success case:
 *					Returns in '*pass_match' which of both passwords matched.
 *					In '*pdev_list' returns the actual dev_list
 */

SBYTE
valusr( UBYTE dev, uchar IN(usrid), uchar IN(pwd), UWORD OUT(devlist), UBYTE OUT(pwd_match) )
{
	if( usrid == NULL || pwd == NULL || devlist == NULL || pwd_match == NULL )
		fatal( "%s-%s: NULL pointer received", __FILE__, __FUNCTION__ );

	copy_item( sbox_out.data.clsv_valusr.usrid, usrid );
	copy_item( sbox_out.data.clsv_valusr.pwd, pwd );

	make_send_rcv( dev, VALUSR, sizeof( CLSV_VALUSR ), sizeof( SVCL_VALUSR ) );

	assign( *(ushort *)devlist, sbox_in.data.svcl_valusr.devlist, ushort);
	*(uchar *)pwd_match = sbox_in.data.svcl_valusr.pwd_match;

	return 0;
}

/*
 * 	getusrinfo:
 * 		Returns information about maximum user number
 * 		and free space remaining for users only
 * 		if corresponding pointer is not NULL
 */

SBYTE
getusrinfo( UBYTE dev, UWORD OUT(max_users), UWORD OUT(free_users) )
{
	if( max_users == NULL || free_users == NULL )
		fatal( "%s-%s: NULL pointer received", __FILE__, __FUNCTION__ );

	make_send_rcv( dev, GETUSRINFO, 0, sizeof( SVCL_GETUSRINFO ) );

	assign( *max_users, sbox_in.data.svcl_getusrinfo.max_users, ushort );
	assign( *free_users, sbox_in.data.svcl_getusrinfo.free_users, ushort );

	return 0;
}

/*
 * 	usrformat:
 * 		Formats unconditionally the users 
 * 		flash pages.
 * 		(Must be validated by a super user)		Added on 12/1/2007
 * 		If 'emerg' != 0, then only
 * 		there are transactions with SECONDARY_DEVICE
 * 		and also only this device is formatted
 * 		Must be called after 'users_init'
 */
#if 0
SBYTE
usrformat( UBYTE dev, SUSER_T IN(suser) )	/*	Modified 12/1/2007	*/
{
	CLSV_USRFORMAT *ps;

	if( suser == NULL )
		fatal( "%s-%s: NULL pointer received", __FILE__, __FUNCTION__ );

	ps = &sbox_out.data.clsv_usrformat;

	copy_item( ps->suser.user_id, suser->user_id );
	copy_item( ps->suser.pass0, suser->pass0 );

	make_send_rcv( dev, USRFORMAT, 0, 0 );

	return 0;
}
#else
SBYTE
usrformat( UBYTE dev )
{
	make_send_rcv( dev, USRFORMAT, 0, 0 );
	return 0;
}
#endif

/*
 * 	blankdfs:
 * 		The entire filesystem is destroyed.
 * 		All files are removed
 * 		No input or output
 */

SBYTE
blankdfs( UBYTE dev )
{
	make_send_rcv( dev, BLANKDFS, 0, 0 );
	return 0;
}

/*
 * 	dfilesys_create_file:
 * 		Creates a new file in file system
 * 		Inputs:
 * 			'df_desc' = file descriptor number to be created
 * 			'unit_size' (probably an structure size)
 * 			'*pnum_units' is the number of units that the file must hold.
 * 			In case '*pnum_units' is negative, then all the space remaining
 * 				is allocated for the file and the number of units allocated is returned by
 * 				reference in '*pnum_units"
 * 			'access' is the type of access that the file sustain for reading and writing.
 * 		Conditions
 * 			File contents are initialized to zero (C style)
 * 				Random files: position is reset to 0
 * 				Queue files: input and output index as well as
 * 					queue count are zeroed.
 * 		Returns:
 * 			From function: DFILE_OK or negative on error
 * 			By reference in '*pnum_units' the actual num_units allocated in case
 * 			of no error; *pnum_units as output may be greater as *pnum_units as input:
 * 			this comes from the fact that an integer number of pages is associated to a file.
 * 		Important note: if file system remaining space is less that on '*pnum_units' then
 * 			file DFILE_NOT_ENOUGH error is returned and in '*pnum_units' number of data units
 * 			that could be allocated is returned. File is not created.
 * 		Errors:
 * 			-ERR_DFILE_BAD_ACCESS:		Bad 'access' code
 * 			-ERR_DFILE_NOT_ENOUGH:		See important note
 * 			-ERR_DFILE_BAD_FDESC:		File descriptor not allowed
 * 			-ERR_DFILE_EXISTS_FDESC:	Exists file created with same file descriptor
 */

SBYTE
createfile( UBYTE dev, UBYTE dfdesc, UBYTE unit_size, UBYTE access, SQUAD INOUT(num_units) )
{
	CLSV_CREATEFILE *ps;

	if( num_units == NULL )
		fatal( "%s-%s: NULL pointer received", __FILE__, __FUNCTION__ );

	ps = &sbox_out.data.clsv_createfile;

	ps->dfdesc		= (uchar)dfdesc;
	ps->unit_size	= (uchar)unit_size;
	ps->access		= (uchar)access;
	assign( ps->num_units, *num_units, ulong );

	make_send_rcv( dev, CREATEFILE, sizeof( CLSV_CREATEFILE ), sizeof(SVCL_CREATEFILE) );

	assign( *num_units, sbox_in.data.svcl_createfile.num_units, ulong );

	return 0;
}

/*
 * 	statusfile:
 * 		Return status of file.
 * 		Inputs:
 * 			File decriptor 'df_desc'
 * 		Returns:
 * 			Status returned in structure pointed by 'psta'
 * 			Function returns DFILE_OK on success or negative in case of error
 * 		Errors:
 * 			-ERR_DFILE_BAD_FDESC:	Descriptor out of range
 * 			-ERR_DFILE_NOT_EXISTS:	File not created
 */

SBYTE
statusfile( UBYTE dev, UBYTE dfdesc, FILESYS_T OUT(sta) )
{
	SVCL_STATUSFILE *pr;

	if( sta == NULL )
		fatal( "%s-%s: NULL pointer received", __FILE__, __FUNCTION__ );

	pr = &sbox_in.data.svcl_statusfile;

	sbox_out.data.clsv_statusfile.dfdesc = (uchar)dfdesc;

	make_send_rcv( dev, STATUSFILE, sizeof( CLSV_STATUSFILE ), sizeof(SVCL_STATUSFILE) );

	sta->unit_size = pr->sta.unit_size;
	sta->file_type = pr->sta.file_type;
	assign( sta->num_units, pr->sta.num_units, ulong );
	assign( sta->out_index, pr->sta.out_index, ulong );
	assign( sta->in_index,  pr->sta.in_index, ulong );
	assign( sta->num_elems, pr->sta.num_elems, ulong );
	assign( sta->position, pr->sta.position, ulong );

	return 0;
}

/*
 * 	readfile:
 * 		Reads from a file according to its access mode in creation.
 * 		Conditions
 * 			Random file, reads from its current position.
 * 			Queue file, reads from its logical position. (More about that in
 * 				dfilsys_seek).
 * 		Inputs
 * 			'df_desc' is the file descriptor
 * 			'num_units' carry the units quantity to be read
 * 		Outputs:
 * 			Function returns number of units actually read if >= 0 or negative
 * 				in error case
 * 			If no error, 'pbuff' contains data.
 * 			In case of -DFILE_SECTOR_ERROR, 'pbuff' contains data that
 * 				was read but without guarantee of corrctness
 *
 * 		If value returned (being positive) is less that 'num_units'
 * 		(including 0) represents that:
 * 			Random file: end of file has been reached.
 * 			Queue file: trying to read from a logical position
 * 				that is beyond the input pointer or the queue has
 * 				lesser units than requiered or the queue is empty 
 * 		Errors:
 * 			-ERR_DFILE_BAD_FDESC:		Descriptor out of range
 * 			-ERR_DFILE_BAD_NUMUNITS:	num_units is 0
 * 			-ERR_DFILE_NOT_EXISTS:		File not created
 * 			-ERR_DFILE_SECTOR_ERROR:	There was a sector error
 */

SBYTE
readfile( UBYTE dev, UBYTE dfdesc, UBYTE num_units, uchar OUT(buff) )
{
	CLSV_READFILE *ps;
	SVCL_READFILE *pr;

	if( buff == NULL )
		fatal( "%s-%s: NULL pointer received", __FILE__, __FUNCTION__ );
	if( num_units == 0 )
		fatal( "%s-%s: no units to read", __FILE__, __FUNCTION__ );

	ps = &sbox_out.data.clsv_readfile;
	pr = &sbox_in.data.svcl_readfile;

	ps->dfdesc = (uchar)dfdesc;
	ps->num_units = (uchar)num_units;

	if( error = setjmp( catch_buffer ) )
	{
		if( qty_rec > 0 )
			memcpy( buff, pr->buff, qty_rec );
		return error;
	}

	do_send_rcv( dev, READFILE, sizeof( CLSV_READFILE ), NO_VERIFY );
	qty_rec -= sizeof( pr->num_units);

	if( qty_rec > 0 )
		memcpy( buff, pr->buff, qty_rec );

	return pr->num_units;
}

/*
 * 	writefile:
 * 		Writes in a file according to its access mode in creation.
 * 		Doesn't allows to write randomly in a QUEUE file reopened as random
 * 		Inputs:
 * 			'num_units' quantity to be written is passed
 * 			'pbuff' contains data to be written.
 *		Conditions:
 * 			Random file, writes into its current position.
 * 			Queue file, writes into input index. If queue is full
 * 				overwrites older registers
 * 		Function returns number of units actually written if >= 0 or negative
 * 			in error case.
 *
 * 		If value returned (being positive) is less that 'num_units'
 * 		represents that:
 * 			Random file: end of file has been reached.
 * 			Queue file: only in case 'num_units' exceeds total queue size
 * 		Errors:
 * 			-ERR_DFILE_BAD_FDESC:		Descriptor out of range
 * 			-ERR_DFILE_BAD_NUMUNITS:	num_units is 0
 * 			-ERR_DFILE_NOT_EXISTS:		File not created
 * 			-ERR_DFILE_NOT_ALLOWED:		A write intent over a QUEUE file reopened as RANDOM
 *
 * 		Note: num_units is in terms of size of data object. 
 * 			From here is needed the byte_count
 */

SBYTE
writefile( UBYTE dev, UBYTE dfdesc, UBYTE num_units, uchar IN(buff), UBYTE byte_count )
{
	CLSV_WRITEFILE *ps;

	if( buff == NULL )
		fatal( "%s-%s: NULL pointer received", __FILE__, __FUNCTION__ );
	if( num_units == 0 )
		fatal( "%s-%s: no units to read", __FILE__, __FUNCTION__ );
	if( byte_count > LEO_BUFF )
		fatal( "%s-%s: too many bytes %d", __FILE__, __FUNCTION__, byte_count );
	else if( byte_count == 0 )
		fatal( "%s-%s: no bytes to write", __FILE__, __FUNCTION__ );

	ps = &sbox_out.data.clsv_writefile;

	ps->dfdesc = (uchar)dfdesc;
	ps->num_units = (uchar)num_units;
	memcpy( ps->buff, buff, byte_count );

	make_send_rcv( dev, WRITEFILE, (ushort)( sizeof( CLSV_WRITEFILE ) - LEO_BUFF + byte_count ), sizeof(SVCL_WRITEFILE) );

	return sbox_in.data.svcl_readfile.num_units;
}

/*
 *	 seekfile:
 *	 	Only used for files created as random or for files
 *	 	created for queue use in case reopened as random.
 *	 	Inputs:
 *	 		'df_desc' is file handler
 *	 		'offset' is desplacement from 'whence' point measure in terms
 *	 			of object units.
 *	 		'whence' specifies frow where 'offset' is measured
 *	 			Note: arguments are very similar to that of 'seek' Unix system call
 *	 	Important note: in case of QUEUE files, this seek only serves for reading
 *	 		and not for writing.
 *	 		QUEUE files are written as normal queues, i.e. using an input pointer
 *	 		regardless of the position reached by this call.
 *	 		In read case, the position is relative to the beginning of queue, i.e.
 *	 		the position is logical within the queue and not physical as is in
 *	 		the case of RANDOM files
 *	 		The seek in QUEUE files is valid for read. Each subsequent read advances
 *	 		position in num_items efectively read.
 *	 		In case a QUEUE file write is done, next position for read is reset to
 *	 		first position, i.e. to beginning of queue
 *	 	Outputs:
 *	 		Function returns DFILE_OK on succcess or negative in error case
 * 		Errors:
 * 			-ERR_DFILE_BAD_FDESC:		Descriptor out of range
 * 			-ERR_DFILE_NOT_EXISTS:		File not created
 * 			-ERR_DFILE_NOT_ALLOWED:		Seek on a QUEUE file not reopened as RANDOM
 * 			-ERR_DFILE_BAD_WHENCE:		whence code incorrect
 * 			-ERR_DFILE_BAD_SEEK:		Seek before beginning of file or past end of file
 *											Seek not done
 *
 */

SBYTE
seekfile( UBYTE dev, UBYTE dfdesc, SQUAD offset, UBYTE whence )
{
	CLSV_SEEKFILE *ps;

	ps = &sbox_out.data.clsv_seekfile;

	ps->dfdesc = (uchar)dfdesc;
	assign( ps->offset, offset, ulong );
	ps->whence = (uchar)whence;

	make_send_rcv( dev, SEEKFILE, sizeof( CLSV_SEEKFILE ), 0 );

	return 0;
}

/*
 * 	reinitfile:
 * 		This call reinits a file to its empty condition
 * 		Input:
 * 			'df_desc' file descriptor
 * 		Conditions:
 * 			Random file: all of its contents are zeroed and position
 * 				is reset to 0
 * 			Queue file: input and output index are zeroed and
 * 				also queue count
 * 		Output:
 * 			Function returns DFILE_OK on success or negative in error case
 * 		Errors:
 * 			-ERR_DFILE_BAD_FDESC:		Descriptor out of range
 * 			-ERR_DFILE_NOT_EXISTS:		File not created
 */

SBYTE
reinitfile( UBYTE dev, UBYTE dfdesc )
{
	sbox_out.data.clsv_reinitfile.dfdesc = (uchar)dfdesc;
	make_send_rcv( dev, REINITFILE, sizeof( CLSV_REINITFILE ), 0 );
	return 0;
}

/*
 * 	getdfsinfo:
 * 		Returns the bit field of file descriptors used,
 * 		bit field of file descriptors in error, file system 
 * 		pages in error and file system size.
 * 		Note: Must be called after 'dfilesys_init' function.
 *
 * 		If NULL, error.
 */

SBYTE
getdfsinfo( UBYTE dev, DFS_INFO_T OUT(info) )
{
	SVCL_GETDFSINFO *pr;

	if( info == NULL )
		fatal( "%s-%s: NULL pointer received", __FILE__, __FUNCTION__ );

	pr = &sbox_in.data.svcl_getdfsinfo;

	make_send_rcv( dev, GETDFSINFO, 0, sizeof(SVCL_GETDFSINFO) );

	assign( info->fd_used,			pr->info.fd_used, 			ushort );
	assign( info->fd_inerror,		pr->info.fd_inerror, 		ushort );
	assign( info->fs_page_errors, 	pr->info.fs_page_errors, 	ushort );
	assign( info->dfs_size, 		pr->info.dfs_size,			ulong );

	return 0;
}

/*
 * 	tlock:
 * 		Changes blocking time
 */

SBYTE
tlock( UBYTE dev, UBYTE tlock0, UBYTE tlock1 )
{
	sbox_out.data.clsv_tlock.tlock0 = (uchar)tlock0;
	sbox_out.data.clsv_tlock.tlock1 = (uchar)tlock1;

	make_send_rcv( dev, TLOCK, sizeof( CLSV_TLOCK ), 0 );
	return 0;
}

/*
 * 	tunlockenable
 */

SBYTE
tunlockenable( UBYTE dev, UBYTE tlock )
{
	sbox_out.data.clsv_tunlockenable.tlock = (uchar)tlock;
	make_send_rcv( dev, TUNLOCKENABLE, sizeof( CLSV_TUNLOCKENABLE ), 0 );
	return 0;
}

/*
 * 	valconfig
 */

SBYTE
valconfig( UBYTE dev, VALCOMM_T IN(vals0), VALCOMM_T IN(vals1) )		/*	Changed on 12/1/2007	*/
{
	CLSV_VALCONFIG *ps;

	if( vals0 == NULL || vals1 == NULL )
		fatal( "%s-%s: NULL pointer received", __FILE__, __FUNCTION__ );

	ps = &sbox_out.data.clsv_valconfig;

	copy_item( ps->vals0, vals0 );
	copy_item( ps->vals1, vals1 );

	make_send_rcv( dev, VALCONFIG, sizeof( CLSV_VALCONFIG ), 0 );

	return 0;
}

/*
 * 	valframe:
 * 		Sends a frame to CIM in order to resend to validator 'dev'
 * 		Whichever responds validator to CIM is echoed transparently
 * 		returnin the payload byte quantity received
 */

SBYTE
valframe( UBYTE dev, UBYTE byte_count, uchar INOUT(buffer) )
{
	CLSV_VALFRAME *ps;
	SVCL_VALFRAME *pr;

	if( buffer == NULL )
		fatal( "%s-%s: NULL pointer received", __FILE__, __FUNCTION__ );
	if( byte_count > LEO_BUFF )
		fatal( "%s-%s: too many bytes %d", __FILE__, __FUNCTION__, byte_count );
	else if( byte_count == 0 )
		fatal( "%s-%s: no bytes to send", __FILE__, __FUNCTION__ );

	ps = &sbox_out.data.clsv_valframe;
	pr = &sbox_in.data.svcl_valframe;

	memcpy( ps->buff, buffer, byte_count );

	make_send_rcv( dev, NO_CMD, (ushort)( sizeof( CLSV_VALFRAME ) - LEO_BUFF + byte_count ), NO_VERIFY );

	if( qty_rec > 0 )
		memcpy( buffer, pr->buff, qty_rec );

	return qty_rec;
}

/*
 * 	hctrl:
 * 		ON/OFF Host Power
 */

SBYTE
hctrl( UBYTE dev, UBYTE onoff )
{
	sbox_out.data.clsv_hctrl.onoff = (uchar)onoff;

	make_send_rcv( dev, HOSTPWR, sizeof( CLSV_HCTRL ), 0 );
	return 0;
}

/*
 * 	forcereset:
 * 		Request Foreced MCU Reset
 */

SBYTE
forcereset( UBYTE dev )
{
	make_send_rcv( dev, RESETMCU, 0, 0 );
	return 0;
}

/*
 * forceusrpass:
 *		Request forced change of the user password
 *		checks frames counter.
 */
SBYTE
forceusrpass( UBYTE dev, UT_T IN(user), UWORD frames )
{
	CLSV_FORCEUSRPASS *ps;
	int qty;

	if( user == NULL )
		fatal( "%s-%s: NULL pointer received", __FILE__, __FUNCTION__ );

	ps = &sbox_out.data.clsv_forceusrpass;

	ps->user = *user;
	ps->frames = frames;

	make_send_rcv( dev, FORCEUSRPASS, sizeof( CLSV_FORCEUSRPASS ), 0 );

	return 0;

}

/*
 * syncnumframes:
 *		Clears frame counter.
 */
SBYTE
syncnumframes( UBYTE dev )
{
	make_send_rcv( dev, SYNCNUMFRAMES, 0, 0 );

	return 0;
}
