
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#include "menus.h"
#include "lang.h"
#include "utilfile.h"

static
int
option1( void )
{
	printf( "Opcion1" );
	return 0;
}

static
int
option2( void )
{
	printf( "Opcion2" );
	return 1;
}


static const MENU_T menus[] =
{
	{	"Opcion 1",					option1		},
	{	"Opcion 2",					option2		},
	{	"Exit to system",			terminate	},
	NULL
};


int
main( void )
{
	set_language( SPANISH );
	set_begin_char( 'a' );
	do_open( "coco", "rb", "Mal" );
	for(;;)
		do_menu( menus );
}


