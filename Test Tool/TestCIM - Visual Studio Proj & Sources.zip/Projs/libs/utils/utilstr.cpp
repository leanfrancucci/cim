/*
 * 		utilstr.h
 *			Utilities regarding string manipulation
 */

#include <ctype.h>

#include "utilstr.h"

int
is_string_all_digit( char *p )
{
	for( ; *p != '\0'; ++p )
		if( !isdigit( *p ) )
			return 0;
	return 1;
}

char *
str2lower( char *p )
{
	char *q;

	for( q = p ; *p != '\0'; ++p )
		*p = (char)tolower( *p );
	return q;
}


