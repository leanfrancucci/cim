/*
 * conser.c
 */

#include <windows.h>
#include <string.h>

#include "mydefs.h"
#include "conser.h"
#include "hardtest.h"
#include "rerror.h"
#include "timer.h"

#define RX_SIZE	1024
uchar rx_buffer[ RX_SIZE ];

static volatile ulong first_timeout, byte_timeout;
static void (*send_frame)( uchar *p, uint qty );
static void (*rx)( uchar byte );
static volatile int rcv_timer, timeout, received;
static uchar *prec;
static volatile int rec_qty;

static
void
rx_idle( unsigned char byte )
{
}

static
void
reset_receive( void )
{
	rcv_timer = 0;
	received = 0;
	rx = rx_idle;
}

static
void
in_rcv( unsigned char byte )
{
	debug( "%s-%s: %02.2X\n", __FILE__, __FUNCTION__, byte ); 
	rcv_timer = byte_timeout;
	*prec++ = byte;
	if( --rec_qty == 0 )
		received = 1;
}


static
void
rx_routine( uchar byte )
{
	(*rx)( byte );
}

static
void
tback( void )
{
	if( rcv_timer, --rcv_timer == 0 )
		timeout = 1;
}


/*
 * tst_send_str
 * 		Send string pointed by p through the Test Equipment
 * 		Serial Channel. 
 */

void
tst_send_str( char *p )
{
	send_frame( (uchar *)p, strlen(p) );
}


/*
 * tst_rcv_nchar:
 * 		Wait for receive "qty" bytes from the Test Equipment
 *		p points to reception buffer.
 * 		Serial Channel,
 * 		- if timer expires (express in ms. ) 
 * 			return -TESTER_TIMEOUT_CONNECTION.
 *
 * 		- if receive "qty" bytes
 * 			return RECEIVE_OK_TESTER.
 */

int
tst_rcv_nchar( char *p, int qty, int timeout_ms )
{
	if( p == NULL )
		fatal( "%s: null pointer received", __FUNCTION__ );
	if( qty > RX_SIZE )
		fatal( "%s: Quantity %u exceeds maximum [%u]", __FUNCTION__, qty, RX_SIZE );
	prec = (uchar *)p;
	rec_qty = qty;
	first_timeout = byte_timeout = timeout_ms/TIME_INTER;
	rcv_timer = first_timeout;
	rx = in_rcv;
	received = timeout = 0;
	while( !received )
	{
		if( timeout )
		{
			reset_receive();
			return -TESTER_TIMEOUT_CONNECTION;
		}
		Sleep(0);
	}
	reset_receive();
	return OK_RECEIVE_TESTER;
}


/*
 * 	init_test_timer
 * 		Receives first and remaining timeouts
 * 		Returns pointer to receive routine
 */

TIMER_CBACK
init_test_timer( ulong ftime, ulong btime )
{
	first_timeout = ftime/TIME_INTER;
	byte_timeout = btime/TIME_INTER;
	return tback;
}

/*
 * 	init_test_channel
 * 		Receives pointer to send_frame routie and returns
 * 		pointer to character receive routine
 */

RX_FUNCTION
init_test_channel( void (*sf)( uchar *p, uint qty ) )
{
	send_frame = sf;
	rx = rx_idle;
	return rx_routine;
}


