/*
 * 	imfiles.h
 */

#ifndef __IMFILES_H__
#define __IMFILES_H__

#define IMAGE_SIZE				0x10000
#define ERASED					0xff

#define wdata_imfiles(x,y)		write_imfiles((x),1,0,(y))
#define wflag_imfiles(x,y)		write_imfiles((x),1,1,(y))
#define wloc_imfiles(x,y)		write_imfiles((x),2,0,(y))

#define rdata_imfiles(x,y)		read_imfiles((x),1,0,(y))
#define rflag_imfiles(x,y)		read_imfiles((x),1,1,(y))
#define rloc_imfiles(x,y)		read_imfiles((x),2,0,(y))
	
enum
{
	EMPTY, USER_CODE, SYSTEM_CODE,
	NUM_FLAGS
};

enum
{
	OK_IMAGE, BAD_IMAGE
};

typedef struct
{
	unsigned char d;	// data
	unsigned char f;	// valid flag 0=empty; 1=usercode; 2=systemcode
} MEM_POS_T;

void init_imfiles( void );
int write_imfiles( const void *pd, int size, int pos, long offset );
int read_imfiles( void *pd, int size, int pos, long offset );

#endif
