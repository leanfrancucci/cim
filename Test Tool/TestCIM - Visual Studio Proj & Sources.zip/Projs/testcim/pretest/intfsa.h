#ifndef __INTFSA_H__
#define __INTFSA_H__

/*
 * 		intfsa.h
 */

/*
 * 	State types for intfsa.c
 */

enum
{
	IDLE, IN_SUBPROC, IN_TEST, IN_FOR, IN_FOR_SUB,	IN_ERROR,
	NUM_STATES
};

void parse( int action_num );

#endif

