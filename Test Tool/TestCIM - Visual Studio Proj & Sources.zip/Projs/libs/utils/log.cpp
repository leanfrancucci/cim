/*
 * 		log.cpp
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>

#include "log.h"
#include "utilfile.h"
#include "utildtim.h"

static FILE *flog, *fthis;
static char this_name[] = "logthis.txt";

/*
 * 	open_log
 */

void
open_log( void )
{
	flog = do_open( get_date_time("%Y%m%d%H%M%S"), "at", "Archivo de log" );
}

/*
 * 	open_this
 */

void
open_this( void )
{
	fthis = do_open( this_name, "wt", "Archivo de log de prueba" );
}

/*
 * 	log
 */

void
log( const char *fmt, ... )
{
	va_list ap;

	va_start( ap, fmt );
	
	fprintf( flog, "%s,", get_date_time("%Y%m%d%H%M%S") );
	fputc( '"', flog );
	vfprintf( flog, fmt, ap );
	fputc( '"', flog );
	fputc( '\n', flog );

	if( fthis != NULL )
	{
		fprintf( fthis, "%s,", get_date_time("%Y%m%d%H%M%S") );
		fputc( '"', fthis );
		vfprintf( fthis, fmt, ap );
		fputc( '"', fthis );
		fputc( '\n', fthis );
	}
	
	va_end( ap );
}

void
log_both( const char *fmt, ... )
{
	va_list ap;

	va_start( ap, fmt );
	vfprintf( stderr, fmt, ap );
	fputc( '\n', stderr );

	fprintf( flog, "%s,", get_date_time("%Y%m%d%H%M%S") );
	fputc( '"', flog );
	vfprintf( flog, fmt, ap );
	fputc( '"', flog );
	fputc( '\n', flog );

	if( fthis != NULL )
	{
		fprintf( fthis, "%s,", get_date_time("%Y%m%d%H%M%S") );
		fputc( '"', fthis );
		vfprintf( fthis, fmt, ap );
		fputc( '"', fthis );
		fputc( '\n', fthis );
	}
	
	va_end( ap );
}

/*
 * 	close_log
 */

void
close_log( void )
{
	fclose( flog );
}
	

/*
 * 	close_this
 */

void
close_this( void )
{
	fclose( fthis );
	fthis = NULL;
}

/*
 * 	flush_this
 */

void
flush_this( void )
{
	fflush( fthis );
}

/*
 * 	get_this_name
 */

char *
get_this_name( void )
{
	return this_name;
}

