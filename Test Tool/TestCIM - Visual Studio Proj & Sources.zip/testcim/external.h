/*
 * 		external.h
 */


