/*
 * 	rxtx485.h
 */

enum
{
	RS485_OK,
	RS485_TIMEOUT, RS485_CHECK_ERROR,
	NUM_485_ERRORS
};


void send_packet_485( uchar *p, uint data_qty );
int rcv_packet_485( uchar *p, uint lim );

