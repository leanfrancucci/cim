/*
 * 		external.h
 */

#include "options.h"

extern char lower_version[30];
extern unsigned long fsys_format_time;
extern TICKET_STR ticket;
