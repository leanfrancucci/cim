/*
 * safetst.c
 */

#include <stdio.h>
#include <ctype.h>
#include <conio.h>
#include <stdarg.h>

#include "safetst.h"
#include "safecond.h"
#include "internal.h"

#include "sbeqtst.h"

#include "cmd485.h"
#include "c485defs.h"
#include "string.h"
#include "terminal.h"
#include "md5lib.h"
#include "lang.h"
#include "external.h"

#define who_am_i()	fprintf( stderr, "%s\n", __FUNCTION__ )
#define	TEST_INTCMD_DELAY	300

char lower_version[30];
unsigned long fsys_format_time;

enum
{
	FIRST_PASSWORD, SECOND_PASSWORD
};

static char swfw_version[30];

#define ENTER_KEY	0x0D	

static const char admin_id_test[] = { '1', '1', '1', '1', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }; 
static const char admin_password0_test[] = { 0xa2, 0x42, 0x81, 0xa0, 0x3c, 0x28, 0xfa, 0x40 };
static UT_T user_and_pass;
static USER_T user_admin =
{
	{ '1', '1', '1', '1', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
	{ 0x06 },
	{ 0, 0, 0, 0, 0, 0, 0, 0 },
	{ 0, 0, 0, 0, 0, 0, 0, 0 }
};

static const char val_stat[5] = { 0xFC, 0x05, 0x11, 0x27, 0x56 };
static const char val_pwrup[5] = { 0xFC, 0x05, 0x40, 0x2B, 0x15 };
static uchar val_buffer[128];


static char printbuff[1024];
enum
{
	WHITE_ON_BLACK,		RED_ON_BLACK,		GREEN_ON_BLACK, 	YELLOW_ON_BLACK,
	BLUE_ON_BLACK,		MAGENTA_ON_BLACK,	CYAN_ON_BLACK,		BLACK_ON_GRAY,
	BLACK_ON_WHITE,		RED_ON_WHITE,		GREEN_ON_WHITE,		YELLOW_ON_WHITE,
	BLUE_ON_WHITE,		MAGENTA_ON_WHITE,	CYAN_ON_WHITE,		WHITE_ON_WHITE,
	NUM_ATTRIBS
};


static
void
color_printf( int color, const char *s, ... )
{
	va_list ap;
	va_start( ap, s );
	setrgb( color );
	vsprintf( printbuff, s, ap );
	printf( printbuff );
	setrgb( WHITE_ON_BLACK );
}

void
print_important0( void )
{
	color_printf( RED_ON_BLACK, "%s\n", lang ? 
			"IMPORTANTE: Si desea que el equipo sea actualizable remotamente,"
		   :"IMPORTANT: If you want the board to be remotely upgradeable," );
	color_printf( RED_ON_BLACK, "%s\n", lang ? 
			"            debera formatear Usuarios y Filesystem"
		   :"           you must format Users and Filesystem" );
}

void
print_important1( void )
{
	color_printf( RED_ON_BLACK, "%s\n", lang ? 
		"IMPORTANTE: Si desea que el equipo sea actualizable remotamente,"
   		:"IMPORTANT: If you want the board to be remotely upgradeable," );
	color_printf( RED_ON_BLACK, "%s", lang ? 
		"            debera actualizar via BDM a una version ":
		"           you must upgrade through BDM to version " );
	color_printf( BLUE_ON_WHITE, "%s", lower_version );
	color_printf( RED_ON_BLACK, "%s\n", lang ? 
		" o superior" : " or higher" );
}


void
check_upgrade_comp( int fatal )
{
	FILESYS_T sta;
	char c;
	ST_T stat;
	int retry;

	statusfile( DEV_SAFEBOX, FD_FW, &sta );

	if( fsys_format_time == 0 ) // agregado para debug
		fsys_format_time = 210;
	else if( ( sta.unit_size == 1 ) && ( sta.num_units = FD_SIZE ) )
	{
			color_printf( GREEN_ON_BLACK, "<<< PASS\n" );
			return;
	}

	
	color_printf( RED_ON_BLACK, "%s\n", lang ? "El Firmware es actualizable, pero la memoria debe ser formateada"
					   							: "Firmware is upgradeable, but memory must be formated" );
			
	printf( "%s\? \n", lang ? "Desea formatear (S/*)" : "Do you want to format (Y/*)" );
	printf( "%s\ \n", lang ? 
					"todo el contenido en la memoria de Usuarios y Filesytem se perdera." : 
					"Users and Filesystem data in memory will be lost." );

	while( !( c = test_key() ));
	c = tolower(c);

	if( lang )
		c == 's' ? 'y' : 'n';

	if( c == 'y' )
	{
		printf( "%s\ : \n", lang ? "Esta seguro de continuar? todos los datos se perderan (S/*)" : 
						            "Are you sure? all data will be lost (Y/*)" );
		while( !( c = test_key() ));
		c = tolower(c);
		
		if( lang )
			c == 's' ? 'y' : 'n';

		if( c == 'y' )
		{
			sbtst_clr_periph(T_VD_PLUNGER);
			printf( "%s", lang ? "Formateando Usuarios " : "Users format in progress " );
			if( usrformat( DEV_SAFEBOX ) < 0 )
			{
				sbtst_set_periph(T_VD_PLUNGER);
				do_warning_digital( 0, 0, "\nUnable to format Users", "\nNo se puede formatear Usuarios", fatal );
			}
			color_printf( GREEN_ON_BLACK, "OK\n" );
			printf( "%s", lang ? "Formateando Filesystem " : "Filesys format in progress " );
			
			blankdfs( DEV_SAFEBOX );

			for( retry = 0; retry < fsys_format_time; ++retry )
				sleep_user( 1000 );
			
			gr1_status( DEV_SAFEBOX, &stat ); 
			gr1_status( DEV_SAFEBOX, &stat ); 
			gr1_status( DEV_SAFEBOX, &stat ); 

			if( gr1_status( DEV_SAFEBOX, &stat ) < 0 )
			{
				sbtst_set_periph(T_VD_PLUNGER);
				do_warning_digital( 0, 0, "\nUnable to format Filesystem", "\nNo se puede formatear Filesystem", fatal );
			}

			color_printf( GREEN_ON_BLACK, "OK\n" );
			sbtst_set_periph(T_VD_PLUNGER);

			statusfile( DEV_SAFEBOX, FD_FW, &sta );

			if( ( sta.unit_size == 1 ) && ( sta.num_units = FD_SIZE ) )
				color_printf( GREEN_ON_BLACK, "<<< PASS\n" );

			return;
		}
	}

	print_important0();

	return; 
}

/*
 * sbtst_set_periph:
 * 	Controls the state of the out-peripheric in the SafeBoard Test Equipment
 * 		arg1 	: see peripherics definition
 * 		arg2 	: state ON/OFF
 * 		returns : SUCCESS
 */
void
sbtst_set_periph( int which )
{
#if _SAFETST_DEBUGG_
	fprintf( stderr, "%s: which %u\n", __FUNCTION__, which );
#endif
	set_pin_tst( which );
	sleep_user( TEST_INTCMD_DELAY );
}

/*
 * sbtst_clr_periph:
 * 	Controls the state of the out-peripheric in the SafeBoard Test Equipment
 * 		arg1 	: see peripherics definition
 * 		returns : SUCCESS
 */
void sbtst_clr_periph( int which )
{
#if _SAFETST_DEBUGG_
	fprintf( stderr, "%s: which %u\n", __FUNCTION__, which );
#endif
	clr_pin_tst( which );
	sleep_user( TEST_INTCMD_DELAY );
}

/*
 * sbtst_check_periph:
 * 	Verify the state of the peripheric 
 * 		arg1 	: see peripherics definition
 * 		arg2 	: verifing state ON/OFF
 * 		returns : SUCCESS if the state of the in-peripheric is equal to the
 * 					verifing en paralelo con la entrada state.
 * 				  FAIL otherwise.
 */
void
sbtst_check_periph( int type, int must_be, int fatal, char *msg_english, char *msg_spanish )
{
	int value;

#if _SAFETST_DEBUGG_
	fprintf( stderr, "%s: type %u, must_be %u\n", __FUNCTION__, which, must_be );
#endif

	if( ( value = get_lpin_tst( type ) ) != must_be )
		do_warning_digital( must_be, value, msg_english, msg_spanish, fatal );
}

/*
 * sbtst_check_privdc:
 * 	Requires the Primary VDC value and compares with the range passed in arg1, arg2
 * 		arg1 	: maximum range value
 * 		arg2 	: minimum range value
 * 		returns : SUCCESS if the signal is in the range.
 * 				  FAIL otherwise.
 */
void
sbtst_check_privdc( double min, double max, int fatal, char *msg_english, char *msg_spanish )
{
	int value;

#if _SAFETST_DEBUGG_
	who_am_i();
#endif

	value = get_apin_tst( T_PRIVDC );
	make_warning_analog( min, max, value, msg_english, msg_spanish, fatal );
}

/*
 * sbtst_check_secvdc:
 * 	Requires the Secondary VDC value and compares with the range passed in arg1, arg2
 * 		arg1 	: maximum range value
 * 		arg2 	: minimum range value
 * 		returns : SUCCESS if the signal is in the range.
 * 				  FAIL otherwise.
 */
void
sbtst_check_secvdc( double min, double max, int fatal, char *msg_english, char *msg_spanish )
{
	int value;

#if _SAFETST_DEBUGG_
	who_am_i();
#endif

	value = get_apin_tst( T_SECVDC );
	make_warning_analog( min, max, value, msg_english, msg_spanish, fatal );
}

/*
 * sbtst_check_vbatt:
 * 	Requires the Battery Voltage value and compares with the range passed in arg1, arg2
 * 		arg1 	: maximum range value
 * 		arg2 	: minimum range value
 * 		returns : SUCCESS if the signal is in the range.
 * 				  FAIL otherwise.
 */
void
sbtst_check_vbatt( double min, double max, int fatal, char *msg_english, char *msg_spanish )
{
	int value;

#if _SAFETST_DEBUGG_
	who_am_i();
#endif

	value = get_apin_tst( T_VBATT );
	make_warning_analog( min, max, value, msg_english, msg_spanish, fatal );
}


/*
 * safe_chk_grstat:	
 *  Verify the state of the Group1 Device.
 *  	arg1	: see Group1 Devices definition
 *  	arg2	: verifing state, acording to the device passed in arg1
 * 		returns : SUCCESS if the state of the device is equal to the
 * 					verifing state.
 * 				  FAIL otherwise.
 */
void
safe_chk_grstat( int which, int must_be, int fatal, char *msg_english, char *msg_spanish )
{
	ST_T stat;
	unsigned char val;

#if _SAFETST_DEBUGG_
	fprintf( stderr, "%s: which %u, must_be %u\n", __FUNCTION__, which, must_be );
#endif

	if( gr1_status( DEV_SAFEBOX, &stat ) < 0 )
	{
		do_warning_digital( 0, 0, "Safe Box don't response", "Safe Box no responde", fatal );
		return;
	}

	switch ( which )
	{
		case GR1_LOCKER0 :
			val = stat.locker0_status;
			break;
		case GR1_VD_PLUNGER :
			val = stat.plunger0_status;
			break;
		case GR1_LOCKER1 :
			val = stat.locker1_status;
			break;
		case GR1_MD_PLUNGER :
			val = stat.plunger1_status;
			break;
		case GR1_PWRSYS:
			val = ( (stat.safebox_status & PS_MASK) >> PS_SHIFTS );
			break;
		case GR1_MEMSTAT:
			val = ( (stat.safebox_status & MS_MASK) >> MS_SHIFTS );
			break;
		case GR1_SYSTAT:
			val = ( (stat.safebox_status & S_MASK) >> S_SHIFTS );
			break;
		case GR1_BATTST:
			val = (stat.safebox_status & BS_MASK);
			break;
		case GR1_STACKER0:
			val = stat.stacker0_status;
			break;
		case GR1_STACKER1:
			val = stat.stacker1_status;
			break;
		default :
			val = must_be + 1;
			break;
	}

	if( val != must_be )
	{
		do_warning_digital( 0, 0, msg_english, msg_spanish, fatal );
		return;
	}
}

/*
 * chk_rs485_response:
 * 	Send one GR1_STATUS request and wait for the SafeBoard response
 * 		arg1	: response time
 * 		arg2	: not used
 * 		returns : SUCCES if the SafeBoard response before to timer expiration
 * 				  FAIL otherwise.
 */
void
chk_rs485_response( unsigned long time, int fatal, char *msg_english, char *msg_spanish )
{
	ST_T stat;
	char c;

#if _SAFETST_DEBUGG_
	fprintf( stderr, "%s: time %lu\n", __FUNCTION__, time );
#endif
	if( gr1_status( DEV_SAFEBOX, &stat ) < 0 )
		do_warning_digital( 0, 0, msg_english, msg_spanish, fatal );

	if( is_first_pass() )
	{
		first_pass_done();
		if( version( DEV_SAFEBOX, (char *)swfw_version ) < 0 )
			do_warning_digital( 0, 0, msg_english, msg_spanish, fatal );
			
		printf( "%s\n", lang ? ">>> Comprobando compatibilidad con proceso de actualizacion remota" :
								">>> Checking compatibility with remotely upgrade process" );

		printf( "%s: ", lang ? "Version de Firmware" : "Firmware Version" );
		color_printf( BLUE_ON_WHITE, "%s\n", swfw_version );

		if( strncmp( lower_version, swfw_version, strlen(lower_version) ) > 0 )		
		{
			color_printf( RED_ON_BLACK, "%s\n", lang ? "no puede ser actualizado remotamente" : "unable to remotely upgraded" );
			printf( "%s\? : \n", lang ? "Desea continuar con el test (*/N)" : "Continue with test (*/N)" );
			while( !( c = test_key() ));
			if( tolower(c) == 'n' )
				do_warning_digital( 0, 0, "Upgrade it and restart the test", "Actualicelo y reanude el test", fatal );
			else
				print_important1();
		}
		else
			check_upgrade_comp( fatal );
	}

	set_tst_condition( GR1_PREV, CONDITION_DONE );
}

/*
 * safe_tlock_cfg:
 * 	Send TLOCK parametter configuration to the SafeBoard
 * 		arg1	: new TLOCK value
 * 		arg2	: not used
 * 		returns	: SUCCESS / FAIL acording to the SafeBoard response
 */
void
safe_tlock_cfg( int value )
{
#if _SAFETST_DEBUGG_
	fprintf( stderr, "%s: value %u\n", __FUNCTION__, value );
#endif

	tlock( DEV_SAFEBOX, value, value );
}

/*
 * safe_tunlocke_cfg:
 * 	Send TUNLOCKE parametter configuration to the SafeBoard
 * 		arg1	: new TUNLOCKE value
 * 		arg2	: not used
 * 		returns	: SUCCESS / FAIL acording to the SafeBoard response
 */
void
safe_tunlocke_cfg( int value )
{
#if _SAFETST_DEBUGG_
	fprintf( stderr, "%s: value %u\n", __FUNCTION__, value );
#endif

	tunlockenable( DEV_SAFEBOX, value );
}

/*
 * safe_unlock:
 * 	Requires LOCKER0/LOCKER1 unlock
 * 		arg1	: LOCKER0/LOCKER1
 * 		arg2	: not used
 * 		returns	: SUCCESS / FAIL acording to the SafeBoard response
 */
void
safe_unlock( int value )
{
	UBYTE match;

#if _SAFETST_DEBUGG_
	fprintf( stderr, "%s: value %u\n", __FUNCTION__, value );
#endif
	memcpy( user_and_pass.user, user_admin.user_id, NUM_UID );
	memcpy( user_and_pass.pass, user_admin.pass0, NUM_PASS );

	if( unlock( value, SINGLE, &user_and_pass, &match, &user_and_pass, &match ) < 0 )
		do_warning_digital( 0, 0, "Unlock Command Error", "Error en commando Unlock", 1 );

	if( match )
		do_warning_digital( 0, 0, "Invalid User", "Usuario Invalido", 1 );
}

/*
 * safe_set_alarm:
 * 	Requires SafeBoard ALARM activation / desactivation
 * 		arg1	: alarm device DURESS / BURGLAR 
 * 		arg2	: Alarm state ON/OFF
 * 		returns	: SUCCESS / FAIL acording to the SafeBoard response
 */
void
safe_set_alarm( int which, int onoff )
{
#if _SAFETST_DEBUGG_
	fprintf( stderr, "%s: which %u, onoff %u\n", __FUNCTION__, which, onoff );
#endif

	if( actrl( which, onoff ) < 0 )
		do_warning_digital( 0, 0, "Error Alarm Command", "Error en Comando de Alarma", 1 );
}

/*
 * safe_set_hostpwr:
 * 	Requires SafeBoard HOSTPWR activation / desactivation
 *		arg1	: not used
 * 		arg2	: Alarm state ON/OFF
 * 		returns	: SUCCESS / FAIL acording to the SafeBoard response
 */
void
safe_set_hostpwr( int onoff )
{
#if _SAFETST_DEBUGG_
	fprintf( stderr, "%s: onoff %u\n", __FUNCTION__, onoff );
#endif

	if( hctrl( DEV_SAFEBOX, onoff ) < 0 )
		do_warning_digital( 0, 0, "Error Setting Host Pwr", "Error Conmutando Host Pwr", 1 );
}

/*
 * safe_users_format:
 * 	Requires SafeBoard USERS_FORMAT
 *		arg1	: not used
 * 		arg2	: not used
 * 		returns	: SUCCESS / FAIL acording to the SafeBoard response
 */
void
safe_users_format( int fatal, char *msg_english, char *msg_spanish )
{
#if _SAFETST_DEBUGG_
	fprintf( stderr, "%s\n", __FUNCTION__ );
#endif

	if( usrformat( DEV_SAFEBOX ) < 0 )
		do_warning_digital( 0, 0, msg_english, msg_spanish, fatal );
}

/*
 * safe_blank_fylesys:
 * 	Requires SafeBoard BLANK_FYLESYS
 *		arg1	: not used
 * 		arg2	: not used
 * 		returns	: SUCCESS / FAIL acording to the SafeBoard response
 */
void
safe_blank_filesys( int fatal, char *msg_english, char *msg_spanish )
{
#if _SAFETST_DEBUGG_
	fprintf( stderr, "%s\n", __FUNCTION__ );
#endif
}

unsigned char *
encryptPassword(char *dest, char *password)
{
	unsigned char digest[16];
	int i, lenPassword;

	lenPassword = strlen(password);
	if (lenPassword > 8) lenPassword = 8;

	// Genero el digest md5
	md5_buffer(password, lenPassword, digest);

	// Me quedo con los primeros 8 digitos del password encriptado
	memcpy(dest, digest, 8);

/*	printf("MD5 digest for password |%s| = ", password);
	for (i = 0; i < 8; ++i)
		printf("%02x", dest[i] & 0xFF);
	printf("\n");
*/
	return dest;
} 


/*
 * safe_add_user:
 * 	Requires SafeBoard ADD_USER
 *		arg1	: not used
 * 		arg2	: not used
 * 		returns	: SUCCESS / FAIL acording to the SafeBoard response
 */
void
safe_add_user( int fatal, char *msg_english, char *msg_spanish )
{
	UWORD max_users, free_users;
	char passcount;
	char c;
	char passbuff[NUM_PASS];
	char encrypted_pass[NUM_PASS];
	char *pencryp;
	ushort my_devlist;
	uchar pwd_match;

#if _SAFETST_DEBUGG_
	fprintf( stderr, "%s\n", __FUNCTION__ );
#endif
	
	getusrinfo( DEV_SAFEBOX, &max_users, &free_users );

	if( free_users != max_users )
	{
		printf( "    %s\n", lang ? "La Memoria Instalada Contiene Usuarios" : "Memory Installed Contain Users" );
		printf( "    %s", lang ? "Ingrese la Clave de Administrador: " : "Please enter Administrator Password: " );

		memset( passbuff, 0, sizeof(passbuff) );
		for( passcount = 0; passcount < 4; ++passcount )
		{
			while( !( c = test_key() ));
			putchar('*');
			passbuff[passcount] = c;
		}
		while( getch()!= ENTER_KEY );

		pencryp = encrypted_pass;
		pencryp = encryptPassword( pencryp, passbuff );

		putchar('\n');
										
		if( valusr( DEV_SAFEBOX, admin_id_test, encrypted_pass, (UWORD *)&my_devlist, (UBYTE *)&pwd_match ) < 0 )
			do_warning_digital( 0, 0, "Administrator Password Validation Failed",
									  "Fallo la Validacion de la Clave Administrador", 1 );
		else
		{
			user_admin.dev_list = my_devlist;

			if( pwd_match == FIRST_PASSWORD )
				memcpy( user_admin.pass0, encrypted_pass, NUM_PASS );
			else
				memcpy( user_admin.pass1, encrypted_pass, NUM_PASS );
		}
	}
	else
	{
		set_tst_condition( USRADD_NEED_FORMAT, CONDITION_DONE );
		memcpy( user_admin.pass0, admin_password0_test, NUM_PASS );
		if( addusr( DEV_SAFEBOX, &user_admin, &user_and_pass ) < 0 )
			do_warning_digital( 0, 0, msg_english, msg_spanish, fatal );
	}
}

/*
 * safe_valtest:
 * 	Send one valid Frame to the Validator passed in arg1, through the SafeBoard protocol.
 * 	Wait the reception of that frame in the ValSimulator COM and check its integrity.
 * 	If the frame is corrupted, returns FAIL.
 * 	Response with a validator frame through the ValSimulator COM.
 * 	Wait the reception of that frame in the RS485 interface and check its integrity.
 * 	If the frame is corrupted, returns FAIL.
 * 		arg1	: VAL0 / VAL1
 * 		arg2	: not used
 * 		returns	: SUCCESS /FAIL acording to the test result.
 */
void
safe_valtest( int which_val, int fatal, char *msg_english, char *msg_spanish )
{
#if _SAFETST_DEBUGG_
	fprintf( stderr, "%s: which_val %u\n", __FUNCTION__, which_val );
#endif
	memcpy( val_buffer, val_stat, sizeof(val_stat) );

	if( valframe( which_val, sizeof(val_stat), val_buffer ) < 0 )
		do_warning_digital( 0, 0, msg_english, msg_spanish, fatal );

	if( memcmp( val_buffer, val_pwrup, sizeof(val_pwrup) ) != 0 )
		do_warning_digital( 0, 0, msg_english, msg_spanish, 1 );
}

