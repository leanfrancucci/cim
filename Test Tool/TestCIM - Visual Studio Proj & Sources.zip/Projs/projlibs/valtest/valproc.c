/*
 *	valproc.c
 *
 *		This file creates a thread for automatic answering
 *		for the validator simulation
 */

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <process.h>

#include "mytypes.h"
#include "mydefs.h"
#include "valcomm.h"
#include "valproc.h"
#include "simval.h"
#include "rerror.h"

static uchar buffer[ 1024 ];

static HANDLE val_handler;
extern volatile int terminate;

static
void
val_thread( PVOID pvoid )
{
	int qty;

	forever
	{
		while( ( qty = val_receive_packet( buffer, sizeof(buffer ) ) ) < 0 )
		;
		if( ( qty = process_answer( buffer, (uint)qty, sizeof(buffer) ) ) >= 0 )
			val_send_packet( buffer, (uint)qty );
	}
}

/*
 *	Starts a new thread for validator
 *	simulation
 */


void
start_validator( void )
{
	terminate = 0;
	val_handler = CreateThread( NULL, 1024, (LPTHREAD_START_ROUTINE)val_thread, NULL, CREATE_SUSPENDED, NULL );
 	if( val_handler == 0 )
		fatal( "%s.ERROR: Could not start timer thread", __FUNCTION__ );
}

/*
 *	resume_validator:
 *		Resumes validator thread
 */

void
resume_validator( void )
{
	ResumeThread( val_handler );
}

/*
 *	suspend_validator:
 *		Suspends the thread
 */

void
suspend_validator( void )
{
	SuspendThread( val_handler );
}

/*
 *	destroy_validator:
 *		Destroys thread
 */

void
destroy_validator( void )
{
	terminate = 1;
}

