/*
 * 	testdef.h
 */

//#define LOADER_NAME		"cproghcs08"
//#define LOADER_NAME		"load_s19"
#define DO_TESTS		"do_tests"

#define INTERNAL	"internal.h"
#define EXTERNAL	"external.h"
#define THISPROJECT	"safetst.h"


