/*
 * hc08sprg.h
 * 	This file is dependent of MCU
 */

#ifndef __HC08SPRG_H__
#define __HC08SPRG_H__

/*
 * Address of relocated interrupt vector table
 */
#define RELOC_VECT_TBL_ADDR			0xFBC0

/*
 * Start address of MCU interrupt vector table
 */
#define VECT_TBL_ADDR				0xFFC0

/*
 * End address of MCU interrupt vector table
 */
#define END_VECT_TBL_ADDR			0xFFFFL

/*
 * Number of reprogrammable memory areas
 */
#define NUM_BLOCKS					1

/*
 * Start address of reprogrammable area
 */
#define START_REPRO_AREA			0x182C

/*
 * End address of reprogrammable area
 */
#define END_REPRO_AREA				0xFFFFL

/*
 * Length of MCU erase block
 */
#define ERASE_BLK_SIZE				512

/*
 * Length of MCU write block
 */
#define WRITE_BLK_SIZE				64

/*
 * System device identification register content
 */
#define SYS_IDENT					"xxx"

/*
 * Boundaries of bootloader code
 */
#define START_BOOT_CODE				0xFC00
#define END_BOOT_CODE				0xFFAF

/*
 * Checksum user code address
 */
#define	START_CHK_CODE				0xFBBE

/*
 * User code section
 */
#define START_USR_CODE_SECT			START_REPRO_AREA
#define END_USR_CODE_SECT			START_CHK_CODE

/*
 * Data block size
 */
#define BLOCK_DATA_SIZE				512

/*
 * Total image to program
 */
#define TOTAL_IMAGE					(START_BOOT_CODE-START_USR_CODE_SECT)

/*
 * Boundaries of high page registers zone
 */
#define START_HIGH_PAGE_ADDR		0x1800
#define END_HIGH_PAGE_ADDR			0x182C

/*
 * Boundaries of first page
 */
#define START_FIRST_PAGE_ADDR		0x1080
#define END_FIRST_PAGE_ADDR			0x1800


#endif
