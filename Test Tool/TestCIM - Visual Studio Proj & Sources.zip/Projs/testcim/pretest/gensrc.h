/*
 * 		gensrc.h
 */

void open_void_function_no_args( char *func_name );
void open_int_function_no_args( char *func_name );
void close_function( void );
void open_for_loop( char *low, char *hi );
void close_for_loop( void );
void call_function( char *func_name, char *fmt, ... );
void open_void_function_2_args( char *func_name, char *arg1, char *arg2 );
void do_include( char *ifile );
void do_sys_include( char *ifile );
void write_nl( int num );
void set_define( const char *which, const char *what );
void extern_function( char *func_name );
void call_and_assign( const char *func_name, const char *var_name, const char *fmt );
void if_statement( const char *condition, const char *fmt, ... );


