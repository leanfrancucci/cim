/*
 *	simval.h
 *
 *		Here is the process of reception
 *		to give answers of validators
 */

#include "mytypes.h"

enum
{
	OK_SIMVAL,
	DONT_ANSWER
};

/*
 *	process_answer:
 *		A reception has been detected
 *		What is received is in buffer and in byte 'qty'
 *		What to respond must be put in buffer, not exceeding
 *		'lim' bytes and auntity to transmit must be returned
 *		from function.
 *		If 'process_answer' doesn't want to respond, must
 *		return e negative value
 */

int process_answer( uchar *buffer, uint qty, uint lim );