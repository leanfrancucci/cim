/*
 * 	valcomm.h
 */

#include "mytypes.h"

enum
{
	VAL_OK,
	VAL_TIMEOUT
};

/*
 * val_send_packet:
 * 		Send  packet pointed by 'p' of 'qty' bytes
 * 		acting as the Validator Equipment
 * 		Serial Channel. 
 * 		If 'qty' is 0, sends nothing
 */

void val_send_packet( uchar *p, uint qty );

/*
 *	val_receive_packet:
 *		Receives a packet that ends by timeout
 *
 *		'p' points to reception buffer.
 *		lim is maximum to put in 'p'
 *
 *		if timeout ocurrs before receiving
 *		any bytes, returns -VAL_TIMEOUT.
 *
 *		If timeout ocurrs after any byte
 *		came, then this terminate packet
 *		normally and returns byte quantity received
 */

int val_receive_packet( uchar *p, uint lim );
