/*
 * 		external.h
 */

extern char lower_version[30];
extern unsigned long fsys_format_time;
