/*
 * 		utilfile.h
 * 			Deals with utilities regarding files
 */

#ifdef __cplusplus
extern "C" {
#endif


/*
 * 	do_open
 * 		Opens a file 'name' for 'mode'
 * 		If opening fails because doesn't exists
 * 		and main mode is read, tries to open for write
 * 		maintining the rest of the mode.
 * 		If error, sends a 'perror' with 'msg' and
 * 		terminates in error
 */

FILE *do_open( const char *name, const char *mode, const char *msg );

#ifdef __cplusplus
}
#endif

