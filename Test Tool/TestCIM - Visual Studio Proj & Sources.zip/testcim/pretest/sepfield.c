/*
 * 		sepfield.cpp
 * 			Separates fields from a
 * 			line of a csv file
 */



#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <ctype.h>
#include <stdarg.h>
#include <ctype.h>

#include "sepfield.h"
#include "vars.h"
#include "procfld.h"
#include "rerror.h"



/*
 * 	Public variables
 * 		Publicized through 'vars.h"
 */

char *fields[ NUM_COLUMNS ];		/*		fields separated array						*/

/*
 * 	Static variables
 */

static char auxiliary[100];

/*
 * 	Static functions
 */

#if 0

static
void
extract_spaces( char *p )
{
	char *q;

	for( q = p ; isspace( *q ) ; ++q )
	;
	if( *q != '\0' )
		memmove( p, q, strlen(q)+1 );
	while( !isspace( *p++ ) )
	;
	*p = '\0';
}

#endif	

static
int
is_separator( int c )
{
	return c == ',' || c == ';';
}

/*
 * 		get_token:
 * 			Separates a token (comma separated)
 * 			in the position pointed by 'p'.
 * 			Token is separated in position pointed
 * 			by 'aux' and returns main pointer pointing
 * 			to next token or to a '\n' or '\0'
 * 			Takes into account quoted strings with embedded
 * 			separators as one string
 */

static
char *
get_token( char *p, char *aux )
{
	int inquote = 0;

	while( *p != '\n' && *p != '\0' )
		if( !inquote )
		{
			if( *p == '"' )
			{
				inquote = 1;
				++p;
			}
			else if( is_separator(*p) )
				break;
			else
				*aux++ = *p++;
		} else if( *p == '"' )
		{
			inquote = 0;
			++p;
		} else
			*aux++ = *p++;

	*aux = '\0';
	if( is_separator(*p) )
		return ++p;
	return p;
}

/*
 * 		Public functions
 */

/*
 * 		separate_fields:
 * 			For an input line, separe each field of
 * 			a csv file. Uses dynamic memory allocation
 * 			for each string in each field
 * 			Returns field quanity separated
 */

int
separate_fields( char *p )
{
	char *s;
	char **t;

	for( t = fields; *p != '\n' && *p != '\0' ; )
	{
		p = get_token( p, auxiliary );
//		extract_spaces( auxiliary );
		if( ( s = strdup( auxiliary ) ) == NULL )
		{
			fprintf( stderr, "No more memory for string allocation\n" );
			exit( EXIT_FAILURE );
		}
		*t++ = s;
	}
	return t - fields;
}

/*
 * 		process_fields:
 * 			For each 'pass', process the
 * 			fields already separated in "fields" array.
 *			First sweeps all fields to know if is an
 *			empty line.
 *			If line not empty, calls 'do_pass' to process the
 *			line for each 'pass'.
 *			After that, releases all dynamic memory taken by
 *			fields
 */

int
process_fields( int num, int pass )
{
	char **t;
	int i, qty;

	for( qty = 0, t = fields, i = 0 ; i < num ; ++i, ++t )
	{
		if( i == BEG_COMMENT && **t == COMMENT_CHAR )
			break;
		if( **t != '\n' && **t != '\0' )
			++qty;
	}
	if( qty != 0 )
		do_pass( pass );
	for( t = fields, i = 0 ; i < num ; ++i, ++t )
		if( *t != NULL )
			free( *t );
	return qty;
}


