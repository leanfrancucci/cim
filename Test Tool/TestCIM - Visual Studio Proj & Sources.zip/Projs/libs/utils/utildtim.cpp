/*
 * 		utildtim.cpp
 * 			Utilities regarding date and time
 */

#include <time.h>

#include "utildtim.h"

#define MAX_NAME	50

static char name[ MAX_NAME ];
static time_t this_time;
static const struct tm *ptime;

static
struct tm *
get_local_time( void )
{
	time( &this_time );
	return localtime( &this_time );
}

/*
 * 	Public functions
 */

/*
 * 	get_date_time:
 * 		Gets pointer to constant string in the format
 * 		established by format string
 */

char *
get_date_time( const char *fmt )
{
	ptime = get_local_time();
	strftime( name, MAX_NAME, fmt, ptime );
	return name;
}


