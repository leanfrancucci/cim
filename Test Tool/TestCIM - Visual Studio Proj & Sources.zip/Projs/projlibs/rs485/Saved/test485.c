/*
 * 	test485.c
 */

#include <stdio.h>

#include "cmd485.h"
#include "endians.h"
#include "serial.h"

static ST_T	gr1sta;

int
main( void )
{
	test_byte_order();
	open_com_connection( "COM1", 38400 );
		gr1_status( 0x08, &gr1sta );
	return 0;
}	

