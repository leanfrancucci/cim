#ifndef __ACTDEF_H__
#define __ACTDEF_H__
/*
 * 		actdef.h
 */

#include "intfsa.h"

typedef struct
{
	char *label;
	void (*execute)( void );
	unsigned type;
} INTER_T;

/*
 * 		Action types
 */

enum
{
	NORMAL_TYPE, PROC_TYPE, TEST_TYPE, EQUATE_TYPE, EXT_TYPE
};

enum
{
	/*	First project independent functions	*/
	BEGIN_PROC,	END_PROC, FOR_EACH,	FOR_END, BEGIN_TEST, END_TEST, SAK_USER, SET_SLEEP, EQUATE, EXT_PROC,
	/*	Project dependent functions			*/
	SBTST_SET_PERIPH, SAFE_TLOCK_CFG, SAFE_TUNLOCKE_CFG, SAFE_SET_ALARM, SAFE_SET_VALPWR, SAFE_SET_HOSTPWR, SAFE_UNLOCK,
	CHK_RS485_RESPONSE, SBTST_CHECK_PRIVDC, SAFE_CHK_GRSTAT, SBTST_CHECK_VBATT,
	SBTST_CHECK_SECVDC, SBTST_CHECK_VAL1PWR, SBTST_CHECK_VAL2PWR, SAFE_VALTEST, SBTST_CHECK_PERIPH,
	SAFE_USERS_FORMAT, SAFE_BLANK_FILESYS, SAFE_ADD_USER, SBTST_CLR_PERIPH,
	NUM_ACTIONS,
	CALL_PROC = SAK_USER
};

/*
 * 		Type definitions
 */

extern INTER_T const action_table[ NUM_ACTIONS ];
extern int const parse_matrix[ NUM_ACTIONS ][ NUM_STATES ];

#endif
