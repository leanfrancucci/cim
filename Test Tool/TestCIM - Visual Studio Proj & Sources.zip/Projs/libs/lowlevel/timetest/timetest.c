/*
 * 	timetest.c
 */

#include <windows.h>
#include <conio.h>
#include <stdio.h>

#include "timer.h"
#include "rerror.h"

#define ONE_SECOND	100

static unsigned long time_10ms;
static unsigned one_second;
static unsigned volatile seconds;

#define TARGET_RESOLUTION 1         // 1-millisecond target resolution

static
unsigned
get_timer_resolution( void )
{
	TIMECAPS tc;
	unsigned     wTimerRes;

	if (timeGetDevCaps(&tc, sizeof(TIMECAPS)) != TIMERR_NOERROR) 
		fatal( "timeGetDevCaps\n" );

	return wTimerRes = min(max(tc.wPeriodMin, TARGET_RESOLUTION), tc.wPeriodMax);
}

static
void
show_interrupts( void )
{
	while( !kbhit() )
		printf( "%6u %3u\r", time_10ms, seconds );
	getch();
	putchar( '\n' );
}

void
timer_inter( void )
{
	++time_10ms;
	if( --one_second == 0 )
	{
		one_second = ONE_SECOND;
		++seconds;
	}
}

int
main( void )
{
//	printf( "%u\n", get_timer_resolution() );
	init_timer_hard( timer_inter );
	seconds = 0;
	one_second = ONE_SECOND;
	printf( "Timer interrupt disabled\n" );
	show_interrupts();
	enable_timer_interrupts();
	printf( "Timer interrupt enabled\n" );
	show_interrupts();
	disable_timer_interrupts();
	printf( "Timer interrupt disabled\n" );
	show_interrupts();
	enable_timer_interrupts();
	printf( "Timer interrupt enabled\n" );
	show_interrupts();
}

