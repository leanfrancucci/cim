/*
 * 		action.h
 */

/*
 * 	General functions
 */

void open_global_test( void );
void call_function_test( char *name );
void close_global_test( void );
void write_includes( void );
void write_vars( void );
void define_proc( void );
void invoke_proc( void );

/*
 * 	user functions
 * 	application independent
 */

void begin_proc( void );
void end_proc( void );
void for_each( void );
void for_end( void );
void begin_test( void );
void end_test( void );
void sak_user( void );
void set_sleep( void );
void equate( void );
void ext_proc( void );

/*
 * 	user functions
 * 	application dependent
 */

void sbtst_set_periph( void );
void safe_tlock_cfg( void );
void safe_tunlocke_cfg( void );
void safe_set_alarm( void );
void safe_set_valpwr( void );
void safe_set_hostpwr( void );
void safe_unlock( void );

void chk_rs485_response( void );
void sbtst_check_privdc( void );
void safe_chk_grstat( void );
void sbtst_check_vbatt( void );
void sbtst_check_secvdc( void );
void sbtst_check_val1pwr( void );
void sbtst_check_val2pwr( void );
void safe_valtest( void );
void sbtst_check_periph( void );
void safe_users_format( void );
void safe_blank_filesys( void );
void safe_add_user( void );
void sbtst_clr_periph( void );

