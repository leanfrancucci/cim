/*
 * 	endians.c
 */

#include "mytypes.h"
#include "endians.h"

static uint byte_order;

void
byte_swap( uchar *p, int n )
{
	register uchar *q;

	if( byte_order == BIG_ENDIAN )
		return;
	for( q = &p[n-1]; p < q; ++p, --q )
	{
		*p ^= *q;
		*q ^= *p;
		*p ^= *q;
	}
}

int
test_byte_order( void )
{
   ushort word;
  
   word = 0x0001;
   return byte_order = *(uchar *)&word ? LITTLE_ENDIAN : BIG_ENDIAN;
}

