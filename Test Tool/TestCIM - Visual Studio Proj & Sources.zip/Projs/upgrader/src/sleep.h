/*
 * sleep.h
 */

#define SLEEP_BASE	10

void sleep( unsigned ms );
void init_timer( void );

