/*
 * 	options.h
 */

#define MAX_OPTION_FILE		255

typedef struct
{
	char com_name[20];
	unsigned baud;
	int bit_num;
	int parity;
	int stop_num;
	unsigned long timeout1;
	unsigned long timeout2;
} COMM_T;

typedef struct
{
	char version[20];
} VERSION_T;

typedef struct
{
	unsigned long parameter;
} PARAMETER_T;

#define COMM_T_MEMBERS	7

typedef struct
{
	COMM_T safe;
	COMM_T test;
	COMM_T val;
	VERSION_T version;
	PARAMETER_T fsys_format_time;
} OPTIONS_T;

extern OPTIONS_T options;

void read_option_file( char *opt_file );
void usage( char *name );
void evaluate_args( int argc, char **argv );
void show_help( void );

#ifdef PRINTER
#define MAX_PRINTER			255
void do_print_test( void );
#endif

/*
 * 		process_opt:
 * 			Process an option from the option file
 * 			If bad option, returns negative, else returns 0
 */

int process_opt( const char *pcomm, char *parg );

