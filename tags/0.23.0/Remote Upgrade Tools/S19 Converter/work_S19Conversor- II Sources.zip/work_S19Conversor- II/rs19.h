/*
 * rs19.h
 *
 * 		S19 manipulation routines file
 */

/*
 * read_s19:
 * 	Read .s19 file and store data into global
 * 	memory image
 */
int read_s19( char *fn );

/*
 * setup_vect_tbl:
 * 
 * 	Masquerade vector table (work on memory image)
 * 	the trick is to move any vector values from S19 file to 
 * 	special jump table located at 'RELOC_VECT_TBL'.
 */
int setup_vect_tbl( void );

/*
 * check_image:
 * 	Check if code goes to valid memory only.
 */
int	check_image( void );

/*
 * blank_image:
 * 	Find end of user code and then blank the locations
 * 	from end of user code up to end user code section.
 */
int blank_image( void );

/*
 * checksum_usrcode:
 * 	Get checksum of whole user code section and
 * 	if success then store it onto START_CHK_CODE.
 */
int checksum_usrcode( void );

/*
 * prepare_prog_area:
 * 	Prepare all commands to send to bootloader
 */
int prepare_prog_area( void );

/*
 * read_s19_boot:
 * 	Read .s19 boot file and store data into memory image
 */
int read_s19_boot( char *fn );

/*
 * image2s19:
 */
int image2s19( void );

/*
 * do_imdwr:
 *
 * 		Creates s08imdwr file.
 */
int do_imcmddwr( void );
