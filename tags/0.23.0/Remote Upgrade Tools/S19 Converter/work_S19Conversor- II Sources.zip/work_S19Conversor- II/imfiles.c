/*
 * 	imfiles.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

#include "imfiles.h"

static MEM_POS_T image_cell = { ERASED, EMPTY };
static FILE *fout;


void
init_imfiles( void )
{
	long i;

	if( ( fout = fopen( "image", "w+b" ) ) == NULL )
	{
		perror( "Can't open input file image\n" );
		exit( EXIT_FAILURE );
	}
	
	for( i = 0 ; i < IMAGE_SIZE ; ++i )
		fwrite( &image_cell, sizeof( image_cell ), 1, fout );
	if( ferror( fout ) )
	{
		perror( "Error initializing image file" );
		exit( EXIT_FAILURE );
	}
}

int
write_imfiles( const void *pd, int size, int pos, long offset )
{
	fseek( fout, ( offset * sizeof( MEM_POS_T ) ) + pos, SEEK_SET );
	fwrite( pd, size, 1, fout );
	return ferror( fout ) ? -BAD_IMAGE : OK_IMAGE;
}

int
read_imfiles( void *pd, int size, int pos, long offset )
{
	fseek( fout, ( offset * sizeof( MEM_POS_T ) ) + pos, SEEK_SET );
	fread( pd, size, 1, fout );
	return ferror( fout ) ? -BAD_IMAGE : OK_IMAGE;
}

#undef TEST_IMFILES

#ifdef TEST_IMFILES

#define BYTE_RANGE			256
#define FLAG_RANGE			NUM_FLAGS
#define ESC					0x1b

static
void
wait_key( void )
{
	int c;

	c = getch();
	if( c == ESC )
	{
		fprintf( stderr, "\n\n User aborting.....\n" );
		exit( EXIT_SUCCESS );
	}
}

static
void
hit_key( void )
{
	if( !kbhit() )
		return;
	wait_key();
	wait_key();
}	

static
void
dump_image( long count )
{
	printf( "%6ld -> %02.2X %01d\n", count, image_cell.d, image_cell.f );
	hit_key();
}	

int
main( void )
{
	long count;
	unsigned char value;

	clrscr();

	init_imfiles();

	image_cell.d = 0xaa;
	image_cell.f = 0xaa;
	wloc_imfiles( &image_cell, 0xffff );
	rloc_imfiles( &image_cell, 0xffff );
	dump_image( 0xffff );
	
	for( count = 0 ; count < IMAGE_SIZE ; ++count )
	{
		image_cell.d = (unsigned char)( count % BYTE_RANGE );
		image_cell.f = (unsigned char)( count % FLAG_RANGE );
		if( wloc_imfiles( &image_cell, count ) < 0 )
		{
			fprintf( stderr, "Error writing in position %lu\n", count );
			return EXIT_FAILURE;
		}
	}
	
		
	for( count = 0 ; count < IMAGE_SIZE; ++count )
	{
		if( rloc_imfiles( &image_cell, count ) < 0 )
		{
			fprintf( stderr, "Error reading in position %lu\n", count );
			return EXIT_FAILURE;
		}
		dump_image( count );
	}
	return EXIT_SUCCESS;
}
	
#endif
