/*
 * 	messages.h
 * 		Here the message table for
 * 		each recognized language
 */

#include "lang.h"

/*
 * 	In file options.c
 */

extern char const * const help_message[ NUM_LANG ];
extern char const * const usage_msg[ NUM_LANG ];
extern char const * const option_line_command[ NUM_LANG ];
extern char const * const no_options_file[ NUM_LANG ];
extern char const * const getting_options_from[ NUM_LANG ];
extern char const * const error_in_options_file[ NUM_LANG ];
extern char const * const msg_comm_channel[ NUM_LANG ];

/*
 *	In file testmain.c
 */

extern char const * const input_serial_number[ NUM_LANG ];
extern char const * const console_eof[ NUM_LANG ];
extern char const * const input_serial_or_terminate[ NUM_LANG ];
extern char const * const invalid_serial[ NUM_LANG ];
extern char const * const selected_serial[ NUM_LANG ];
extern char const * const failed_previous_test[ NUM_LANG ];
extern char const * const new_test_on_failed[ NUM_LANG ];
extern char const * const passed_previous_test[ NUM_LANG ];
extern char const * const new_test_on_passed[ NUM_LANG ];
extern char const * const more_tests_to_go[ NUM_LANG ];
extern char const * const test_end_msg[ NUM_LANG ];
extern char const * const want_to_print[ NUM_LANG ];
extern char const * const printed_results_msg[ NUM_LANG ];
extern char const * const install_board[ NUM_LANG ];
extern char const * const board_test_begin[ NUM_LANG ];
extern char const * const board_file[ NUM_LANG ];
extern char const * const historical_test_file[ NUM_LANG ];
extern char const * const end_of_all_tests[ NUM_LANG ];
extern char const * const begin_test_program[ NUM_LANG ];
extern char const * const abnormal_program_end[ NUM_LANG ];

/*
 *	In file internal.c
 */

extern char const * const ending_tests_in_error[ NUM_LANG ];
extern char const * const error_in_analog_test[ NUM_LANG ];
extern char const * const error_in_digital_test[ NUM_LANG ];
extern char const * const sleeping_process[ NUM_LANG ];
extern char const * const begin_test_msg[ NUM_LANG ];
extern char const * const end_test_msg[ NUM_LANG ];
extern char const * const end_test_msg_console[ NUM_LANG ];
extern char const * const redoing_test[ NUM_LANG ];


