/*
 * 	rxtx485.c
 */

#include <windows.h>
#include <stdio.h>

#include "mytypes.h"
#include "rxtx485.h"
#include "hard485.h"
#include "rerror.h"
#include "endians.h"
#include "timer.h"

#define MARK		0xf8
#define DATA_COUNT	3


/*
 * 	Static variables
 */

static void (*send_frame)( uchar *p, uint qty );
static void (*rx)( uchar byte );
static uchar *rcv_ptr;
static uint rcv_qty;
static uint volatile rcv_done;
static ulong timer;
static uint volatile rcv_timeout, rcv_timer;
static uint rcv_lim;
static uint frame_count;
static ushort data_count;
static ulong first_timeout, byte_timeout;
static uint check_rcv, check_calc;

/*
 * 	Static functions
 */

/*
 * ---	Parser functions to receive
 *  	485 frames
 */

/*
 * 		idle
 * 			Reject bytes received
 * 			Init condition
 */

static
void
idle( uchar byte )
{
}

/*
 * 	set_rcv_done:
 * 		Sets variables to indicate
 * 		receive frame is completed
 */

static
void
set_rcv_done( void )
{
	rcv_done = 1;
	rcv_timer = 0;
	rx = idle;
}

/*
 * 	set_timeout_done:
 * 		Sets variables to indicate
 * 		that a timeout condition was met
 */

static
void
set_timeout_done( void )
{
	rcv_timeout = 1;
	rx = idle;
}

/*
 * 	get_check:
 * 		Receives last frame byte
 * 		that is checksum
 */

static
void
get_check( uchar byte )
{
	debug( "%s-%s: %02.2X\n", __FILE__, __FUNCTION__, byte );
	check_rcv = byte;
	set_rcv_done();
}

/*
 * 	get_data:
 *		Here receives all data according
 *		to protocol.
 *		If no room, sets receive done and error
 *		will be informed by bad checksum
 *		If there is room, receives bytes in
 *		a quantity established in data_count.
 *		Bytes are stored in buffer pointed by rcv_ptr
 *		and frame count is incremented
 */

static
void
get_data( uchar byte )
{
	debug( "%s-%s: %02.2X\n", __FILE__, __FUNCTION__, byte );
	rcv_timer = byte_timeout;
	if( frame_count >= rcv_lim )
	{
		set_rcv_done();
		return;
	}
	check_calc += *rcv_ptr++ = (uchar)byte;
	++frame_count;
	if( --data_count == 0 )
		rx = get_check;
}

#ifdef DATA_2

static
void
get_data_second( uchar byte )
{
	debug( "%s-%s: %02.2X\n", __FILE__, __FUNCTION__, byte );
	rcv_timer = byte_timeout;
	check_calc += *rcv_ptr++ = (uchar)byte;

	data_count <<= 8;
	data_count |= byte;
	++frame_count;
	rx = data_count == 0 ? get_check : get_data;
}

#endif

/*
 * 	get_data_count:
 * 		Receives bytes and till the
 * 		third one is received.
 * 		This byte has the data count
 * 		that follows
 */

static
void
get_data_count( uchar byte )
{
	debug( "%s-%s: %02.2X\n", __FILE__, __FUNCTION__, byte );
	rcv_timer = byte_timeout;
	check_calc += *rcv_ptr++ = (uchar)byte;
	if( ++frame_count == DATA_COUNT )
	{
		data_count = byte;
#ifdef DATA_2
		rx = get_data_second;
#else
		rx = data_count == 0 ? get_check : get_data;
#endif
	}
}

/*
 * 	wait_mark:
 * 		waits till mark received
 * 		Then, initializes frame_count
 * 		and changes to 'get_data_count'
 */

static
void
wait_mark( uchar byte )
{
	debug( "%s-%s: %02.2X\n", __FILE__, __FUNCTION__, byte );
	if( byte != MARK )
	{
		rcv_timer = first_timeout;
		return;
	}
	rcv_timer = byte_timeout;
	frame_count = 0;
	check_calc = 0;
	rx = get_data_count;
}

/*
 *	rx_routine:
 *		main thread routine.
 *		Call indirectly to present routine
 */

static
void
rx_routine( uchar byte )
{
	(*rx)( byte );
}

/*
 * 	timer_routine:
 * 		Called each 10 ms by timer thread
 * 		If rcv_timer != 0, decrements it and when
 * 		reaches 0, sets communication timeout
 */


static
void
timer_routine( void )
{
	if( rcv_timer, --rcv_timer == 0 )
		set_timeout_done();
}

static
MUInt
calculate_check( uchar *p, int qty )
{
	MInt check;

	for( check = 0 ; qty-- ; )
		check += *p++;
	return (MUInt)(-check & 0xff);
}

/*
 * 	rcv_frame:
 * 		Called from this same module, has
 * 		as arguments buffer address and
 * 		byte limit to receive
 *
 * 		Initializes global variable to
 * 		receive functions parser and
 * 		sits in a tight loop waiting for
 * 		one of two flags:
 * 			rcv_done
 * 			rcv_timeout
 *		if >= 0, returns byte quantity received,
 *		excluding MARK and checksum
 *		If < 0, returns error (timeout)
 */

static
int
rcv_frame( uchar *p, uint lim )
{
	rcv_done = 0;
	rcv_qty = 0;
	rcv_ptr = p;
	rcv_timeout = 0;
	rcv_lim = lim;
	rcv_timer = first_timeout;
	rx = wait_mark;
	while( !rcv_done )
	{
		if( rcv_timeout )
			return -RS485_TIMEOUT;
		Sleep(0);						/*	Bill Gates syndrome !	*/
	}
	return frame_count;
}

/*
 * 	Public functions
 */

/*
 * 	send_packet_485:
 * 		Receives a data buffer pointed by p
 * 		and data quantity, excluding MARK and checksum
 * 		Sets MARK and checksum and sends whole buffer
 */

void
send_packet_485( uchar *p, uint data_qty )
{
	if( send_frame == NULL )
		fatal( "%s: no function for receiving", __FUNCTION__ );
	*p++ = MARK;
	*(p + data_qty) = (uchar)calculate_check( p, data_qty );
	send_frame( --p, data_qty + 2 );
}

/*
 * 	rcv_packet_485:
 * 		Receives pointer where to store frame and byte limit
 * 		There is place for MARK byte but this byte is not
 * 		stored or considered for checksum
 * 		return >=0 for data bytes excluding MARK and checksum
 * 		or < 0 for error. This errors may be TIMEOUT or CHECKSUM_ERROR
 */

int
rcv_packet_485( uchar *p, uint lim )
{
	int qty;

	if( rcv_frame == NULL )
		fatal( "%s: no function for receiving", __FUNCTION__ );
	if( ( qty = rcv_frame( p+1 , lim-2 ) ) < 0 )
		return qty;
	if( (ushort)((-(short)check_rcv) & 0xff) != (check_calc & 0xff) )
		return -RS485_CHECK_ERROR;
	return qty;
}

/*
 * 	init_safe_channel:
 * 		Receives a pointer fo a SendFrame function (sf)
 * 		in other moduule and returns a pointer to Receive Function
 * 		in this module.
 *
 * 		Call to 'test_byte_order" to solve endianism
 * 		Inits first receive function as idle.
 * 		Saves send frame function
 */

RX_FUNCTION
init_safe_channel( void (*sf)( uchar *p, uint qty ) )
{
	test_byte_order();
	rx = idle;
	send_frame = sf;
	return rx_routine;
}

/*
 * 	init_safe_timer:
 * 		Receives two ulongs for receiving frame as
 * 		first byte timeout and succesive bytes timeout
 *
 * 		Sets rcv_timer to 0, and stores copies
 * 		of arguments
 */

TIMER_CBACK
init_safe_timer( ulong ftime, ulong btime )
{
	rcv_timer  = 0;
	first_timeout = ftime/TIME_INTER;
	byte_timeout = btime/TIME_INTER;
	return timer_routine;
}


