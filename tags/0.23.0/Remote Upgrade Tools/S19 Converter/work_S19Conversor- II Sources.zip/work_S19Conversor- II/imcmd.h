/*
 * imcmd.h
 */

#define close_ims19			close_imcmd
#define flush_ims19			flush_imcmd

int init_imcmd( void );
int init_ims19( void );
void set_byte( unsigned char b );
void set_byte_s19( unsigned char b );
void set_word( unsigned short w );
void set_word_s19( unsigned short w );
void set_delim( void );
void close_imcmd( void );
void set_str_s19( const char *p );
void flush_imcmd( void );
