/*
 * 		gensrc.cpp
 */

#include <stdio.h>
#include <stdarg.h>


#include "gensrc.h"
#include "testdef.h"

static int tab = 0;

static
void
send_tabs( int tab_num )
{
	while( tab_num-- )
		fputc( '\t', stdout );
}

static
void
show_begin_bracket_nl( void )
{
	fputc( '\n', stdout );
	send_tabs( tab );
	printf( "{\n" );
}

static
void
show_end_bracket_nl( void )
{
	send_tabs( tab );
	printf( "}\n" );
}

void
open_void_function_no_args( char *func_name )
{
	printf( "\nvoid\n%s( void )", func_name );
	show_begin_bracket_nl();
	++tab;
}

void
open_int_function_no_args( char *func_name )
{
	printf( "\nint\n%s( void )", func_name );
	show_begin_bracket_nl();
	++tab;
}

void
open_void_function_2_args( char *func_name, char *arg1, char *arg2 )
{
	printf( "\nvoid\n%s( %s, %s )", func_name, arg1, arg2 );
	show_begin_bracket_nl();
	++tab;
}

void
close_function( void )
{
	--tab;
	show_end_bracket_nl();
}

void
open_for_loop( char *low, char *hi )
{
	send_tabs( tab );
	printf( "for( int i = (int)%s ; i < (int)%s ; ++i )", low, hi );
	show_begin_bracket_nl();
	++tab;
}

void
close_for_loop( void )
{
	--tab;
	show_end_bracket_nl();
}

void
call_and_assign( const char *func_name, const char *var_name, const char *fmt )
{
	va_list ap;

	va_start( ap, fmt );
	send_tabs( tab );
	printf( "%s = %s(", var_name, func_name );
	vprintf( fmt, ap );
	va_end( ap );
	printf( ");\n" );
}

void
call_function( char *func_name, char *fmt, ... )
{
	va_list ap;

	va_start( ap, fmt );
	send_tabs( tab );
	printf( "%s(", func_name );
	vprintf( fmt, ap );
	va_end( ap );
	printf( ");\n");
}

void
if_statement( const char *condition, const char *fmt, ... )
{
	va_list ap;

	va_start( ap, fmt );
	send_tabs( tab );
	printf( "if( %s )\n", condition );
	send_tabs( ++tab );
	vprintf( fmt, ap );
	fputc( '\n', stdout );
	--tab;
}


void
do_include( char *ifile )
{
	printf( "#include \"%s\"\n", ifile );
}

void
do_sys_include( char *ifile )
{
	printf( "#include <%s>\n", ifile );
}

void
write_nl( int num )
{
	while( num-- )
		fputc( '\n', stdout );
}

void
set_define( const char *which, const char *what )
{
	printf( "#define\t%s\t%s\n", which, what );
}


void
extern_function( char *name )
{
	printf( "extern void %s( double arg1, double arg2 );\n\n", name );
}


