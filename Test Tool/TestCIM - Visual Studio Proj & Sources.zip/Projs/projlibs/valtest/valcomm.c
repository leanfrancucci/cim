/*
 * 	valcomm.c
 */

#include <windows.h>

#include "mydefs.h"
#include "valcomm.h"
#include "hardval.h"
#include "rerror.h"
#include "timer.h"

static volatile ulong first_timeout, byte_timeout;
static void (*send_frame)( uchar *p, uint qty );
static void (*rx)( uchar byte );
static volatile int rcv_timer, timeout, received;
static uchar *prec;
static volatile uint rec_qty;
static uint rec_limit;
volatile int terminate;

static
void
rx_idle( unsigned char byte )
{
}

static
void
reset_receive( void )
{
	rcv_timer = 0;
	received = 0;
	rx = rx_idle;
}

static
void
in_rcv( unsigned char byte )
{
	debug( "%s-%s: %02.2X\n", __FILE__, __FUNCTION__, byte ); 
	rcv_timer = byte_timeout;
	if( rec_qty < rec_limit )
		*prec++ = byte;
	++rec_qty;
}

static
void
in_first_receive( uchar byte )
{
	debug( "%s-%s: %02.2X\n", __FILE__, __FUNCTION__, byte ); 
	(*(rx = in_rcv))( byte );
}


static
void
rx_routine( uchar byte )
{
	(*rx)( byte );
}

static
void
tback( void )
{
	if( rcv_timer, --rcv_timer == 0 )
		if( rx == in_first_receive )
			timeout = 1;
		else
			received = 1;
}


/*
 * val_send_packet:
 * 		Send  packet pointed by 'p' of 'qty' bytes
 * 		acting as the Validator Equipment
 * 		Serial Channel. 
 * 		If 'qty' is 0, sends nothing
 */

void
val_send_packet( uchar *p, uint qty )
{
	if( p == NULL )
		fatal( "%s: null pointer received", __FUNCTION__ );
	if( qty > 0 )
		send_frame( p, qty );
	else
		debug( "%s: Don't send anything because qty is zero", __FUNCTION__ );
}


/*
 *	val_receive_packet:
 *		Receives a packet that ends by timeout
 *
 *		'p' points to reception buffer.
 *		lim is maximum to put in 'p'
 *
 *		if timeout ocurrs before receiving
 *		any bytes, returns -VAL_TIMEOUT.
 *
 *		If timeout ocurrs after any byte
 *		came, then this terminate packet
 *		normally and returns byte quantity received
 */

int
val_receive_packet( uchar *p, uint lim )
{
	if( p == NULL )
		fatal( "%s: null pointer received", __FUNCTION__ );
	if( lim == 0 )
		fatal( "%s: limit to receive is zero", __FUNCTION__ );
	prec = (uchar *)p;
	rec_qty = 0;
	rec_limit = lim;
	rcv_timer = first_timeout;
	rx = in_first_receive;
	received = timeout = 0;
	while( !received )
	{
		if( timeout )
		{
			reset_receive();
			return -VAL_TIMEOUT;
		}
		if( terminate )
			ExitThread( 0 );
		Sleep(0);
	}
	reset_receive();
	return rec_qty;
}


/*
 * 	init_val_timer
 * 		Receives first and remaining timeouts
 * 		Returns pointer to receive routine
 */

TIMER_CBACK
init_val_timer( ulong ftime, ulong btime )
{
	first_timeout = ftime/TIME_INTER;
	byte_timeout = btime/TIME_INTER;
	return tback;
}

/*
 * 	init_val_channel
 * 		Receives pointer to send_frame routie and returns
 * 		pointer to character receive routine
 */

RX_FUNCTION
init_val_channel( void (*sf)( uchar *p, uint qty ) )
{
	send_frame = sf;
	rx = rx_idle;
	return rx_routine;
}


