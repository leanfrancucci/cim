/*
 * 	ctest.cpp
 * 		Main module for preprocess Excel output
 * 		obtained from Excel worksheet
 * 		This module deals with external program interface
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <ctype.h>
#include <stdarg.h>

#include "vars.h"
#include "procfld.h"
#include "sepfield.h"
#include "testdef.h"

#include "rerror.h"
#include "utilstr.h"
#include "terminal.h"
#include "getopt.h"

/*
 * 	Defines
 */

#define SEPARATOR	','

#define MAX_DIR		300
#define MAX_NAME	50
#define MAX_EXT		20
#define MAX_OUT		300
#define MAX_IN		300

#define MAX_BUFFER	1024

/*
 * 	Public variables
 * 		Publicized through 'vars.h"
 */

unsigned long line;				/*		Maintains line number for fatal information	*/

/*
 * 	Static variables
 * 	unitialized
 */

static char out_file[ MAX_OUT ];
static char in_file	[ MAX_IN ];
static char buffer	[ MAX_BUFFER ];

/*
 * 	Static variables
 * 	initialized and constant
 */

static char opts[] = "e:";


static
void
usage( char *progname )
{
	fprintf( stderr, "Usage: %s -e{EXCEL_FILE} (default cvs file) input_file output_file", progname );
	exit( EXIT_FAILURE );
}


/*
 * 		process_parameters:
 * 			Process command argument parameters
 * 			First argument is a csv file name
 * 			Second argument is output file
 *			Returns file pointer of input file and
 *			stdout is redirected to output file
 */

static
FILE *
process_parameters( int argc, char **argv )
{
	int c;
	FILE *f, *f1;
	int excel;

	excel = 0;
	while( ( c = getopt( argc, argv, opts ) ) != EOF )
	{
		switch( c )
		{
			case 'e':
				excel = 1;
				break;
			case '?':
				usage( argv[0] );
		}
	}

	if( argc - optind != 2 )
		usage( argv[0] );

	/*	Opening input file	*/

	if( excel )
	{
		fprintf( stderr, "Conversion from .xls to .csv not yet supported\n" );
		exit( EXIT_FAILURE );
	}

	strncpy( in_file, argv[ optind ], sizeof( in_file ) );
	strncpy( out_file, argv[ optind + 1 ], sizeof( out_file ) );

	if( ( f = fopen( in_file, "rt" ) ) == NULL )
	{
		perror( "Opening input file" );
		exit( EXIT_FAILURE );
	}

	if( ( f1 = fopen( out_file, "r" ) ) != NULL )		/*	Output file, exists ?	*/
	{
		fclose( f1 );
		if( !select_yes_no( "\n\tFile %s exists, overwrite?...<Y/*>: ", out_file ) )
			exit( EXIT_FAILURE );
	}
	if( freopen( out_file, "wt", stdout ) == NULL )		/*	Redirecting ...			*/
		perror( "In freopen" );
	return f;
}

/*
 * 		process_csv
 * 			Processes each 'pass' of an
 * 			input line pointed by 'p'
 */

static
void
process_csv( char *p, int pass )
{
	int num;

	num = separate_fields( p );
	process_fields( num, pass );
}

/*
 * 		Public functions
 */

/*
 * 	main:
 * 		Here starts ball rolling down ...
 * 		Process input and output files
 * 		Input files are CSV ones from Excel
 * 		Output file goes in the same directory
 * 		as input file with same name and extension cpp
 * 		It is overriden by third argument
 * 		Then it makes two passes on the input file
 * 		First pass is verification an symbol table construction
 * 		Second pass is code generation
 */

void
get_char( void )
{
	getchar();
}

int
main( int argc, char **argv )
{
	FILE *f;
	int pass;



	atexit( get_char );
	f = process_parameters( argc, argv );
	for( pass = PASS1 ; pass <= PASS2 ; ++pass )
	{
		rewind( f );
		if( pass == PASS2 )
			write_heading();
		for( line = 1L ; fgets( buffer, sizeof(buffer), f ) != NULL ; ++line )
			process_csv( buffer, pass );
	}
	generate_main_section();
	fclose( f );
	return EXIT_SUCCESS;
}


