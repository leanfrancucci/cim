/*
 * 	testmain.cpp
 */

/*
 * 	System includes
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <ctype.h>
#include <stdarg.h>
#include <conio.h>

/*
 * 	Project includes
 */


#include "terminal.h"
#include "console.h"
#include "lang.h"
#include "utilstr.h"
#include "utildtim.h"
#include "utilfile.h"
#include "log.h"
#include "options.h"
#include "hard.h"
#include "internal.h"
#include "rerror.h"
#include "messages.h"
#include "safecond.h"

/*
 * 	Defines
 */

/*
 * 	Constants
 */

#define NUM_SERIAL_NUMBER	50
#define MAX_SERIAL			(NUM_SERIAL_NUMBER+1)
#define MAX_SERIAL_FILE		40
#define MAX_HISTORY_FILE	255

enum
{
	FAIL, PASS
};

/*
 * 	Strings
 */

#define pass_string			"PASS"
#define fail_string			"FAIL"
#define sep					",\n"


/*
 * 	Enumerations
 */

enum
{
	DONT_EXISTS, EXISTS_FAIL, EXISTS_PASS
};

/*
 * 	Public variables
 */

int debug_flag;				/*	For debugging without hardware	*/
extern char option_file[ MAX_OPTION_FILE ];

/*
 * 	Extern variables
 */

extern char option_file[ MAX_OPTION_FILE ];

/*
 * 	Static variables initialized
 */

static char history_file[ MAX_HISTORY_FILE ] = "test_record.csv";
static char serial_number[ MAX_SERIAL ] = "";

/*
 * 	Static variables uninitialized
 */

static char serial_file[ MAX_SERIAL_FILE ];
static FILE *fserial, *fserhisto;

/*
 * --------- Here related to board serial numbers
 */

/*
 * 	verify_serial_number
 */

static
int
verify_serial_number( void )
{
	int num;

	num = strlen( serial_number );

	if( serial_number[ num - 1 ] == '\n' )
		serial_number[ --num ] = '\0';

	if( num == 0 )
		return 0;

	return num <= NUM_SERIAL_NUMBER && is_string_all_digit( serial_number );
}

/*
 * 	exists_serial_test:
 * 		Searchs in historic file for serial numbers
 * 		if there exists a test for this serial number
 * 		returns:
 * 			DONT_EXISTS
 * 			EXISTS_PASS
 * 			EXISTS_FAIL
 */

static
int
exists_serial_test( void )
{
	char buffer[50], *p;
	int status;

	status = DONT_EXISTS;
	fflush( fserhisto );
	fseek( fserhisto, 0L, SEEK_SET );
	while( fgets( buffer, sizeof( buffer ), fserhisto ) != NULL )
	{
		if( ( p = strtok( buffer, sep ) ) == NULL )
			continue;
		if( strcmp( p, serial_number ) != 0 )
			continue;
		if( ( p = strtok( NULL, sep ) ) == NULL )
			continue;
		if( ( p = strtok( NULL, sep ) ) == NULL )
			continue;
		status = strcmp( p, pass_string ) == 0 ? EXISTS_PASS : EXISTS_FAIL;
		if( status == EXISTS_PASS )
			return status;
	}
	return status;
}

/*
 * 	input_new_serial
 */

static
int
input_new_serial( void )
{
	int status;

	fprintf( stderr, input_serial_number[ lang ] );
	memset( serial_number, 0, sizeof( serial_number ) );
	fflush( stdin );
	if( fgets( serial_number, sizeof( serial_number ) - 1, stdin ) == NULL )
	{
		clearerr( stdin );
		log( console_eof[ lang ] );
		fprintf( stderr, input_serial_or_terminate[ lang ] );
		return 0;
	}
	if( !verify_serial_number() )
	{
		log_both( invalid_serial[ lang ] );
		return 0;
	}
	log( selected_serial[ lang ], serial_number );
	switch( exists_serial_test() )
	{
		case DONT_EXISTS:
			return 1;
		case EXISTS_FAIL:
			status = select_yes_no( failed_previous_test[ lang ] );
			log( new_test_on_failed[ lang ], status ? "A" : "No a", serial_number );
			return status;
		case EXISTS_PASS:
			status = select_yes_no( passed_previous_test[ lang ] );
			log( new_test_on_passed[ lang ], status ? "A" : "No a", serial_number );
			return status;
		default:
			return 0;
	}
}

/*
 * 	input_board_serial:
 */

static
int
input_board_serial( void )
{
	int done;
	static int first = 1;

	system( "cls" );
	do
	{
		if( !first )
			if( !select_yes_no( more_tests_to_go[ lang ] ) )
				return EOF;
		first = 0;
		done = input_new_serial();
	} while( !done );
	return 0;
}

/*
 * ----------- Initializations
 */

/*
 * 	init_all
 */

static
void
init_all( int argc, char **argv )
{
	setrgb( WHITE_ON_BLACK );
	evaluate_args( argc, argv );
	read_option_file( option_file );
	if( !debug_flag )
		init_hardware();
}

static
void
deinit_all( void )
{
	if( !debug_flag )
		deinit_hardware();
}

void
show_banner( int which )
{
	setrgb( which == FAIL ? RED_ON_BLACK : GREEN_ON_BLACK );
	system( which == FAIL ? "type fail.txt" : "type ok.txt" );
	setrgb( WHITE_ON_BLACK );
}
/*
 * --------- Tests
 */

/*
 *	close_test
 */

static
void
close_test( int bad_num )
{
	log( test_end_msg[ lang ], serial_number, bad_num ? fail_string: pass_string );
	fprintf( fserial, "%s,%s\n", get_date_time("%Y%m%d%H%M%S"), bad_num ? fail_string: pass_string );
	fclose( fserial );
	fseek( fserhisto, 0L, SEEK_END );
	fprintf( fserhisto, "%s,%s,%s\n", serial_number, get_date_time("%Y%m%d%H%M%S"), bad_num ? fail_string: pass_string );
	fflush( fserhisto );
	show_banner( bad_num ? FAIL : PASS );
#ifdef PRINTER
	if( bad_num )
	{
		if( select_yes_no( want_to_print[ lang ]) )
		{
			close_this();
			do_print_test();
			log( printed_results_msg[ lang ], serial_number );
		}
	} else
		sak();
#else
	sak();
#endif
}

/*
 * 	make_test
 */


static
void
make_test( void )
{
	int num;

	open_this();
	sprintf( serial_file, "%s.csv", serial_number );
	fserial = do_open( serial_file, "at", board_file[ lang ] );

	fprintf( stderr, install_board[ lang ] );
	sak();

	if( !debug_flag )
		run_hardware();
	log( board_test_begin[ lang ], serial_number );
	
	init_func_tst();
	num = begin_all_tests();
	if( !debug_flag )
		stop_hardware();

	close_test( num );
}

/*
 * 	close_files
 */

static
void
close_files( void )
{
	fcloseall();
}

static
void
end_program( int sig )
{
	log_both( abnormal_program_end[ lang ] );
	exit( EXIT_FAILURE );
}

/*
 * 		Public functions
 * 			main:
 */

int
main( int argc, char **argv )
{
	debugging = 0;
	atexit( (void (*)(void) )sak_flat );
	signal( SIGINT, SIG_IGN );
	signal( SIGABRT, SIG_IGN );

	set_language( ENGLISH );

	open_log();
	
	init_all( argc, argv );
	log( begin_test_program[ lang ] );

	atexit( close_files );

	fserhisto = do_open( history_file, "r+t", historical_test_file[ lang ] );

	while( input_board_serial() != EOF )
		make_test();

	deinit_all();

	fputc( '\n', stderr );
	log_both( end_of_all_tests[ lang ] );
	fputc( '\n', stderr );

	return EXIT_SUCCESS;
}

