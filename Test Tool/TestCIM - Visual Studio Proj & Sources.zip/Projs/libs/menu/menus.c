/*
 * 		menus.cpp
 * 			Menu manager
 */
 
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <ctype.h>

#include "menus.h"
#include "lang.h"
#include "console.h"

static int bchar = '1';

enum
{
	INPUT_OPTION, I_NEWLINE,
	NUM_MSGS
};


static char * const messages[ NUM_LANG ][ NUM_MSGS ] =
{
	{ "Input option",		"Input new line to terminate" },
	{ "Ingrese opcion",		"Ingrese enter para terminar" }
};

static int lasty;

static
int
show_menu( const MENU_T *p )
{
	int i, x, y;

	clr2rgb( RED_ON_BLACK );
	x = 8;
	y = 3;
	printf("\n\n\n");
	for( i = 0 ; p->menu_msg != NULL ; ++p, ++i, ++y )
	{
		gotoxy( x, y );
		printf( "%c.- %s\n", bchar+i, p->menu_msg );
	}
	lasty = y;
	return i;
}

static
int
get_option( unsigned qty )
{
	unsigned c, first;
	int x, y;

	setrgb( RED_ON_WHITE );
	y = lasty+3;
	x = 16;

	first = 0;
	gotoxy( x, y );
	printf( "%s( %c to %c ): ", messages[lang][INPUT_OPTION], bchar, bchar + qty - 1 );
	do
	{
		if( !first ) first = 1; else putchar( '\a' );
		c = tolower( getch() )  - bchar;
	}
	while( c >= qty );
	return c;
}

static
void
execute( const MENU_T *p )
{
	clr2rgb( WHITE_ON_BLACK );

	if( (*p->pfunc)() )
	{
		printf("\n\n%s: ", messages[lang][I_NEWLINE] );
		getchar();
	}
}


void
do_menu( const MENU_T *p )
{
	unsigned qty, select;

	qty = show_menu( p );
	select = get_option( qty );
	execute( &p[select] );
}

int
terminate( void )
{
	clr2rgb( WHITE_ON_BLACK );
	exit( EXIT_SUCCESS );
}

void
set_begin_char( int beg_char )
{
	bchar = beg_char;
}


