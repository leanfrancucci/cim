/*
 * 	dfdata.h
 * 		Data structures and
 * 		definitions for new file system
 *
 * 		Version 1.0 9/3/2007	ARG
 *
 * 		DelsatGroup S.A.
 * 		Eduardo Martinez
 */


/*
 * 	File information structure
 */

/*
 *	Configuration as well as status data
 */


/*
 * 	Access types
 */

enum
{
	RANDOM, QUEUE,
	NUM_ACCESS
};

/*
 * 	whence types
 */

enum
{
	FD_SEEK_SET, FD_SEEK_CUR, FD_SEEK_END,
	NUM_WHENCE
};

/*
 * 	File descriptor numbers
 */

enum
{
	DF_FIRST_DESC = 0,		/*	First descriptor number	*/
	NUM_FDS = 11
};

#define FD_FW	(NUM_FDS-1)
//#define FD_FW	0

/*
 * 	MAX_UNIT_SIZE
 * 		Is the maximum size that a record can have
 */

#define MAX_UNIT_SIZE		255

/*
 * 	FS_NO_FORMAT
 * 		When 'fs_page_errors' is equal to 'fs_num_pages', the flash
 * 		memory does not have format.
 */

#define FS_NO_FORMAT		0xFFFF


