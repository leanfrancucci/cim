/*
 * 		action.cpp
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>

#include "action.h"
#include "gensrc.h"
#include "vars.h"
#include "testdef.h"

#include "rerror.h"


/*
 * 	Definitions
 */

#define END_NAME	3

#define fun_1_value()	\
	call_function( __FUNCTION__, "%s", fields[ LOW_VALUE ] )
#define fun_2_values()	\
	call_function( __FUNCTION__, "%s, %s", fields[ LOW_VALUE ], fields[ HI_VALUE ] )
#define check_no_values()	\
	call_function( __FUNCTION__, "%s, \"%s\", \"%s\"",	\
		fields[ FATAL], fields[ ENGLISH_TEXT], fields[ SPANISH_TEXT] );
#define check_1_value()	\
	call_function( __FUNCTION__, "%s, %s, \"%s\", \"%s\"", \
		fields[ LOW_VALUE ], fields[ FATAL ], fields[ ENGLISH_TEXT ], fields[ SPANISH_TEXT] )
#define check_2_values()	\
	call_function( __FUNCTION__, "%s, %s, %s, \"%s\", \"%s\"", \
		fields[ LOW_VALUE ], fields[ HI_VALUE ], fields[ FATAL ], fields[ ENGLISH_TEXT ], fields[ SPANISH_TEXT] )

/*
 * 	Static variables
 */

static char name[ 20 ];
static char index[ 20 ];

/*
 * 	Static functions
 */

static
char *
set_name( char *id )
{
	memset( name, 0, sizeof( name ) );
	strcpy( name, id );
	name[ END_NAME ] = '\0';
	return name;
}

static
char *
set_index( char *id )
{
	memset( index, '\0', sizeof( index ) );
	strcpy( index, id + END_NAME );
	return index;
}

static
int
exists( char * const *port_table, char *port_name )
{
	while( port_table != NULL )
	{
		if( *port_table == NULL || port_name == NULL )
			return 0;
		if( strcmp( *port_table++, port_name ) == 0 )
			return 1;
	}
	return 0;
}

/*
 * 	Public functions
 */

/*
 * 	General functions
 */

void
open_global_test( void )
{
	open_int_function_no_args( DO_TESTS );
	call_function( "init_all_tests", "" );
}

void
call_function_test( char *name )
{
	call_function( name, "" );
}

void
close_global_test( void )
{
	call_function( "return", "error_status()" );
	close_function();
}

void
write_includes( void )
{
	write_nl(1);
	do_include( INTERNAL );
	do_include( EXTERNAL );
	do_include( THISPROJECT );
	do_include( "messages.h" );
	do_sys_include( "setjmp.h" );
	do_sys_include( "stdio.h" );
	write_nl(1);
}

void
write_vars( void )
{
	printf( "jmp_buf excel_buff;\n" );
	printf( "static int local_error;\n" );
	write_nl(1);
}

void
define_proc( void )
{
	open_void_function_2_args( fields[ LABEL ], "double arg1", "double arg2" );
}	

void
invoke_proc( void )
{
	call_function( fields[ OPERATION ], " %s, %s ", fields[ LOW_VALUE ], fields[ HI_VALUE ] );
}

void
begin_proc( void )
{
	open_void_function_2_args( fields[ LABEL ], "double arg1", "double arg2" );
}

void
end_proc( void )
{
	close_function();
}

/*
 * 	Application independent
 * 	user functions
 */

void
for_each( void )
{
	open_for_loop( fields[ LOW_VALUE ], fields[ HI_VALUE ] );
}

void
for_end( void )
{
	close_for_loop();
}

void
do_setjmp( void )
{
	call_and_assign( "setjmp", "local_error", "excel_buff" );
	if_statement( "local_error", "printf( \"... %%s\\n\", redoing_test[ lang ] );"  ); 
}

void
begin_test( void )
{
	open_void_function_no_args( fields[ LABEL ] );
	call_function( __FUNCTION__, "\"%s\", \"%s\", \"%s\"", fields[ LABEL ], fields[ ENGLISH_TEXT ], fields[ SPANISH_TEXT] );
	do_setjmp();
}

void
end_test( void )
{
	call_function( __FUNCTION__, "" );
	close_function();
}

void
sak_user( void )
{
	call_function( "sak_user", " \"%s\", \"%s\"", fields[ ENGLISH_TEXT ], fields[ SPANISH_TEXT ] );
}

void
set_sleep( void )
{
	call_function( "sleep_user", " (unsigned long)%s ", fields[ LOW_VALUE ] );	
}

void
equate( void )
{
	set_define( fields[ LABEL ], fields[ PORT ] );
}

void
ext_proc( void )
{
	extern_function( fields[ LABEL ] );
}

/*
 * 	From here on, project dependent functions
 */


void
sbtst_set_periph( void )
{
	fun_1_value();
}

void
sbtst_check_privdc( void )
{
	check_2_values();
}

void
chk_rs485_response( void )
{
	check_1_value();
}

void
safe_chk_grstat( void )
{
	check_2_values();
}

void
sbtst_check_vbatt( void )
{
	check_2_values();
}

void
sbtst_check_secvdc( void )
{
	check_2_values();
}

void
safe_tlock_cfg( void )
{
	fun_1_value();
}

void
safe_tunlocke_cfg( void )
{
	fun_1_value();
}

void
safe_unlock( void )
{
	fun_1_value();
}

void
safe_valtest( void )
{
	check_1_value();
}

void
safe_set_alarm( void )
{
	fun_2_values();
}

void
sbtst_check_periph( void )
{
	check_2_values();
}

void
safe_set_hostpwr( void )
{
	fun_1_value();
}

void safe_users_format( void )
{
	check_no_values();
}

void safe_blank_filesys( void )
{
	check_no_values();
}

void safe_add_user( void )
{
	check_no_values();
}

void sbtst_clr_periph( void )
{
	fun_1_value();
}


