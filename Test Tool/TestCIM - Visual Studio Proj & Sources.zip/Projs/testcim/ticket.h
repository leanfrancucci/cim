/*
 * ticket.h
 */

void print_ticket( void );
