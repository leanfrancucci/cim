/*
 *	simval.c
 *
 *		Here is the process of reception buffer
 *		to give answers of validators
 */

#include "simval.h"
#include "rerror.h"
#include <string.h>


static const char val_stat[5] = { 0xFC, 0x05, 0x11, 0x27, 0x56 };
static const char val_pwrup[5] = { 0xFC, 0x05, 0x40, 0x2B, 0x15 };

/*
 *	process_answer:
 *		A reception has been detected
 *		What is received is in buffer and in byte 'qty'
 *		What to respond must be put in buffer, not exceeding
 *		'lim' bytes and quantity to transmit must be returned
 *		from function
 *		If 'process_answer' doesn't want to respond, must
 *		return a negative value (-DONT_ANSWER)
 */
int
process_answer( uchar *buffer, uint qty, uint lim )
{
	debug( "%s-%s: received %u bytes", __FILE__, __FUNCTION__, qty );
	/*	To be filled by the application wanted	*/
	if( memcmp( val_stat, buffer, sizeof(val_stat) ) != 0 )
		return -DONT_ANSWER;

	memcpy( buffer, val_pwrup, sizeof(val_pwrup) );
	return sizeof(val_pwrup);
}
