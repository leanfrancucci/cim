/*
 * safedefs.h
 */

/*******************************
 * Safe Box Devices Definition *
 *******************************/
enum
{
	DEV_VAL0,
	DEV_VAL1,
	DEV_LOCKER0,
	DEV_PLUNGER0,
	DEV_LOCKER1,
	DEV_PLUNGER1,
	DEV_ALARM0,
	DEV_ALARM1,
	DEV_SAFEBOX,
	DEV_STACKER0,
	DEV_STACKER1,

	NUM_DEVICES
};

/****************************************
 * Safe Box GR1STATUS Answer Definition *
 ****************************************/
/*
 * GR1Status Devices & States
 */

#define PS_MASK		0x80
#define PS_SHIFTS	7
#define MS_MASK		0x18
#define MS_SHIFTS	3
#define S_MASK		0x04
#define S_SHIFTS	2
#define BS_MASK		0x03

/*** Lockers States ***/
#define	GR1_LOCKER0	0
#define	GR1_LOCKER1	2
enum {	LOCKED, UNLOCKED, LOCKING, UNLOCKING };

/*** PLungers ***/
#define	GR1_VD_PLUNGER	1
#define	GR1_MD_PLUNGER	3
enum { OPEN, CLOSE };

/*** Safe Box ***/
#define	GR1_PWRSYS	4
enum {	EXT, BACKUP };

#define	GR1_MEMSTAT	5
//enum{ BOTH_MEM_OK, SEC_MEM_FAIL, MAIN_MEM_FAIL,	BOTH_MEM_FAIL };

#define	GR1_SYSTAT	6
enum{ PRIMARY_SYS, SECONDARY_SYS };

#define	GR1_BATTST	7
enum{ BATTLOW, BATTREM, BATTOK };

/*** Stackers ***/
#define	GR1_STACKER0	8
#define	GR1_STACKER1	9
enum{ INSTALLED, REMOVED };

#define	HOST_ON		0
#define	HOST_OFF	1

/*
 * Safe Commands Definitions
 */

/* Alarm Control */
enum{ AL_ENABLE, AL_DISABLE	};

/*************************************
 * Test Equipment Devices Definition *
 *************************************/
enum
{
	/* PORT0 */
	T_VD_PLUNGER,
	T_VD_SW,
	T_VD_LOAD,
	T_MD_PLUNGER,
	T_MD_SW,
	T_MD_LOAD,
	T_STACKER1,
	T_STACKER2,

	/* PORT1 */
	T_PRIVDC = 10,
	T_SECVDC,
	T_VBATT,
	T_TP1,
	T_TP2,
	T_TP3,
	T_TP4,
	T_TP5,

	/* PORT2 */
	T_TP6 =	22,
	T_TP7,
	T_TIP_S,
	T_RING_S,
	T_TIP_O,
	T_RING_O,

	/* PORT3 */
	T_BATTERY =	30,
	T_VALSW,
	T_RS485SW,
	T_PRI_PWR,
	T_SEC_PWR,
	T_KEY_SW,
	T_VD_CURR,
	T_MD_CURR,

	/* PORT4 */
	T_TP8 = 42,
	T_TP9,
	T_TP10,
	T_TP11,
	T_TP12,
	T_TP13,

	/* PORT5 */
	T_LED0 = 50,
	T_LED1,
	T_LED2,
	T_LED3,
	T_LED4,
	T_LED5,
	T_LED6,
	T_LED7,

	/* PORT6 */
	T_DURESS_NC = 63,
	T_DURESS_NO,
	T_BURGLAR_NC,
	T_BURGLAR_NO,
	T_TP14,
};

/*
 * Test Equipment Devices States Definition
 */

/* 
 * Plungers Simulator: T_VD_PLUNGER, T_MD_PLUNGER
 */
enum{ P_OPENED,	P_CLOSED };

/*
 * Key Switch Simulator: KEY_SW
 */
enum{ OPEN_KS, CLOSE_KS	};

/* 
 * Lockers State Switch Simulator: T_VD_SW, T_MD_SW 
 */
enum{ L_LOCKED, L_UNLOCKED };

/*
 * Lockers Simulator: T_VD_LOAD, T_MD_LOAD
 */
enum{ UNCONNECTED, CONNECTED };

/*
 * Locker Current Sensor: T_VD_CURR, T_MD_CURR
 */
enum{ DRIVED, NOT_DRIVED };

/*
 * Stacker Sensor Simulator: T_STACKER1, T_STACKER2
 */ 
enum{ S_UNINSTALLED, S_INSTALLED };

/*
 * Battery Switch: T_BATTERY 
 */
enum{ BATT_CONNECTED, BATT_UNCONNECTED };

/*
 * Validator Comunication Switch: T_VALSW
 */
enum{ VALIDATOR1, VALIDATOR2 };

/*
 * CT8016 Comunication Switch: T_RS485SW
 */
enum{ COMPRIMARY, COMSECONDARY };

/*
 * Alarm State Sensor
 */
enum{ ACTIVATED, UNACTIVATED };

/*
 * Test Point I/O
 */
enum{ LOW, HIGH };




/*****************************
 * Safetst Public Functions  *
 *****************************/

/*
 * sbtst_set_periph:
 * 	Controls the state of the out-peripheric in the SafeBoard Test Equipment
 * 		arg1 	: see peripherics definition
 * 		returns : SUCCESS
 */
void sbtst_set_periph( int which );

/*
 * sbtst_clr_periph:
 * 	Controls the state of the out-peripheric in the SafeBoard Test Equipment
 * 		arg1 	: see peripherics definition
 * 		returns : SUCCESS
 */
void sbtst_clr_periph( int which );

/*
 * sbtst_set_periph:
 * 	Verify the state of the peripheric 
 * 		arg1 	: see peripherics definition
 * 		arg2 	: verifing state ON/OFF
 * 		returns : SUCCESS if the state of the in-peripheric is equal to the
 * 					verifing state.
 * 				  FAIL otherwise.
 */
void sbtst_check_periph( int type, int must_be, int fatal, char *msg_english, char *msg_spanish );


/*
 * sbtst_check_privdc:
 * 	Requires the Primary VDC value and compares with the range passed in arg1, arg2
 * 		arg1 	: maximum range value
 * 		arg2 	: minimum range value
 * 		returns : SUCCESS if the signal is in the range.
 * 				  FAIL otherwise.
 */
void sbtst_check_privdc( double min, double max, int fatal, char *msg_english, char *msg_spanish );

/*
 * sbtst_check_secvdc:
 * 	Requires the Secondary VDC value and compares with the range passed in arg1, arg2
 * 		arg1 	: maximum range value
 * 		arg2 	: minimum range value
 * 		returns : SUCCESS if the signal is in the range.
 * 				  FAIL otherwise.
 */
void sbtst_check_secvdc( double min, double max, int fatal, char *msg_english, char *msg_spanish );

/*
 * sbtst_check_vbatt:
 * 	Requires the Battery Voltage value and compares with the range passed in arg1, arg2
 * 		arg1 	: maximum range value
 * 		arg2 	: minimum range value
 * 		returns : SUCCESS if the signal is in the range.
 * 				  FAIL otherwise.
 */
void sbtst_check_vbatt( double min, double max, int fatal, char *msg_english, char *msg_spanish );


/*
 * chk_rs485_response:
 * 	Send one GR1_STATUS request and wait for the SafeBoard response
 * 		arg1	: response time
 * 		arg2	: not used
 * 		returns : SUCCES if the SafeBoard response before to timer expiration
 * 				  FAIL otherwise.
 */
void chk_rs485_response( unsigned long time, int fatal, char *msg_english, char *msg_spanish );

/*
 * safe_tlock_cfg:
 * 	Send TLOCK parametter configuration to the SafeBoard
 * 		arg1	: new TLOCK value
 * 		arg2	: not used
 * 		returns	: SUCCESS / FAIL acording to the SafeBoard response
 */
void safe_tlock_cfg( int value );

/*
 * safe_tunlocke_cfg:
 * 	Send TUNLOCKE parametter configuration to the SafeBoard
 * 		arg1	: new TUNLOCKE value
 * 		arg2	: not used
 * 		returns	: SUCCESS / FAIL acording to the SafeBoard response
 */
void safe_tunlocke_cfg( int value );

/*
 * safe_unlock:
 * 	Requires LOCKER0/LOCKER1 unlock
 * 		arg1	: LOCKER0/LOCKER1
 * 		arg2	: not used
 * 		returns	: SUCCESS / FAIL acording to the SafeBoard response
 */
void safe_unlock( int value );

/*
 * safe_set_alarm:
 * 	Requires SafeBoard ALARM activation / desactivation
 * 		arg1	: alarm device DURESS / BURGLAR 
 * 		arg2	: Alarm state ON/OFF
 * 		returns	: SUCCESS / FAIL acording to the SafeBoard response
 */
void safe_set_alarm( int which, int onoff );

/*
 * safe_set_hostpwr:
 * 	Requires SafeBoard HOSTPWR activation / desactivation
 *		arg1	: not used
 * 		arg2	: Alarm state ON/OFF
 * 		returns	: SUCCESS / FAIL acording to the SafeBoard response
 */
void safe_set_hostpwr( int onoff );

/*
 * safe_users_format:
 * 	Requires SafeBoard USERS_FORMAT
 *		arg1	: not used
 * 		arg2	: not used
 * 		returns	: SUCCESS / FAIL acording to the SafeBoard response
 */
void safe_users_format( int fatal, char *msg_english, char *msg_spanish );

/*
 * safe_blank_fylesys:
 * 	Requires SafeBoard BLANK_FYLESYS
 *		arg1	: not used
 * 		arg2	: not used
 * 		returns	: SUCCESS / FAIL acording to the SafeBoard response
 */
void safe_blank_filesys( int fatal, char *msg_english, char *msg_spanish );

/*
 * safe_add_user:
 * 	Requires SafeBoard USERS_FORMAT
 *		arg1	: not used
 * 		arg2	: not used
 * 		returns	: SUCCESS / FAIL acording to the SafeBoard response
 */
void safe_add_user( int fatal, char *msg_english, char *msg_spanish );

/*
 * safe_valtest:
 * 	Send one valid Frame to the Validator passed in arg1, through the SafeBoard protocol.
 * 	Wait the reception of that frame in the ValSimulator COM and check its integrity.
 * 	If the frame is corrupted, returns FAIL.
 * 	Response with a validator frame through the ValSimulator COM.
 * 	Wait the reception of that frame in the RS485 interface and check its integrity.
 * 	If the frame is corrupted, returns FAIL.
 * 		arg1	: VAL0 / VAL1
 * 		arg2	: not used
 * 		returns	: SUCCESS /FAIL acording to the test result.
 */
void safe_valtest( int which_val, int fatal, char *msg_english, char *msg_spanish );


