/*
 * 		utilfile.cpp
 * 			Deals with utilities regarding files
 */

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>

#include "utilfile.h"

/*
 * 	do_open
 * 		Opens a file 'name' for 'mode'
 * 		If opening fails because doesn't exists
 * 		and main mode is read, tries to open for write
 * 		maintining the rest of the mode.
 * 		If error, sends a 'perror' with 'msg' and
 * 		terminates in error
 */

FILE *
do_open( const char *name, const char *mode, const char *msg )
{
	FILE *f;
	char new_mode[4];

	if( ( f = fopen( name, mode ) ) != NULL )
		return f;
	
	if( errno != ENOENT || ( errno == ENOENT && *mode  != 'r' ) )
	{
		perror( msg );
		exit( EXIT_FAILURE );
	}
	
	memset( new_mode, 0, sizeof( new_mode ) );
	strncpy( new_mode, mode, sizeof( new_mode ) - 1 );
	*new_mode = 'w';
	
	if( ( f = fopen( name, new_mode ) ) != NULL )
		return f;

	perror( msg );
	exit( EXIT_FAILURE );
}


