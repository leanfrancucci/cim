/*
 * ticket.c
 */
#include <stdio.h>
#include <stdarg.h>
#include <time.h>
#include "ticket.h"
#include "external.h"

#define MAX_CHARS	1024

#define TEXT1_VAR	"Autobank Test OK"
#define SW_VAR		"SW00.15.00" 
#define HW_VAR		"HW03.00A0.0"
#define VAL1_VAR	"L"
#define VAL2_VAR	"R"
#define WDATE_VAR	"4508"
#define DDATE_VAR	"26/11/08"

#define TICKET_HDR  "N\r\nZT\r\nq416\r\nQ223,24\r\nD10\r\nS2\r\nON\r\n"
#define TEXT1		"A95,22,0,3,1,1,N,\"%s\"\r\n"
#define BARCODE		"B47,49,0,1,1,2,49,N,\"%s%s%c%c%s\"\r\n"
#define TEXT2		"A61,108,0,2,1,1,N,\"%s\"\r\n"
#define TEXT3		"A61,128,0,2,1,1,N,\"%s\"\r\n"
#define TEXT4		"A61,148,0,2,1,1,N,\"VAL1: %c\"\r\n"
#define DATE		"A211,168,0,2,1,1,N,\"DATE: %s\"\r\n"
#define TEXT5		"A61,168,0,2,1,1,N,\"VAL2: %c\"\r\n"
#define TICKET_TERM	"P1,1\r\n"

#define SWV_SIZE	10
static char sw_ver[SWV_SIZE+1];

static char buff[ MAX_CHARS ];

void
send_prn_str( char *str )
{
	send_printer_frame( str, strlen(str) );
}
		
void
prn_printf( const char *fmt, ... )
{
	va_list args;

	va_start( args, fmt );
	vsprintf( buff, fmt, args );
	va_end( args );
	send_prn_str( buff );
}


void
print_ticket( void )
{
	time_t tiempo;
	char date[10];
	char cdate[10];
	struct tm tm_str;
	struct tm *tmPtr;

	if( ticket.print_enable == 0 )
		return;
		
	get_swver( sw_ver, SWV_SIZE );
	
	tmPtr = &tm_str;
	tiempo = time(NULL);
	tmPtr = localtime(&tiempo);

  	strftime( cdate, 10, "%m%d%y", tmPtr );
  	strftime( date, 10, "%m/%d/%y", tmPtr );

	prn_printf( TICKET_HDR );
	prn_printf( TEXT1, TEXT1_VAR );
	prn_printf( BARCODE, sw_ver, ticket.hw_version, ticket.val1_type, ticket.val2_type, cdate );
	prn_printf( TEXT2, sw_ver );
	prn_printf( TEXT3, ticket.hw_version );
	prn_printf( TEXT4, ticket.val1_type );
	prn_printf( DATE, date );
	prn_printf( TEXT5, ticket.val2_type );
	prn_printf( TICKET_TERM );
}
