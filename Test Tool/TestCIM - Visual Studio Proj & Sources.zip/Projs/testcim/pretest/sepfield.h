/*
 * 		sepfield.h
 * 			For an input line, separe each field of
 * 			a csv file. Uses dynamic memory allocation
 * 			for each string in each field
 * 			Returns field quanity separated
 */

int separate_fields( char *p );
/*
 * 		process_fields:
 * 			For each 'pass', process the
 * 			fields already separated in "fields" array.
 *			First sweeps all fields to know if is an
 *			empty line.
 *			If line not empty, calls 'do_pass' to process the
 *			line for each 'pass'.
 *			After that, releases all dynamic memory taken by
 *			fields
 */

int process_fields( int num, int pass );

