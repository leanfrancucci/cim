/*
 * prntst.h
 */

enum
{
	OK_RECEIVE_TESTER,
	TESTER_TIMEOUT_CONNECTION
};

/*
 * prn_send_str
 * 		Send string pointed by p through the Test Equipment
 * 		Serial Channel. 
 */
void prn_send_str( char *p ); 

/*
 * prn_rcv_nchar:
 * 		Wait for receive "qty" bytes from the Test Equipment
 *		p points to reception buffer.
 * 		Serial Channel,
 * 		- if timer expires (express in ms. ) 
 * 			return -TESTER_TIMEOUT_CONNECTION.
 *
 * 		- if receive "qty" bytes
 * 			return RECEIVE_OK_TESTER.
 */


int prn_rcv_nchar( char *p, int qty, int timeout_ms );

