/*
 * 	testsrc.h
 */

int do_tests( void );
