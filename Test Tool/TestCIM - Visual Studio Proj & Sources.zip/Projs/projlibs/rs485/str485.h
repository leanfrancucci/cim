/*
 * 		str485.h
 */

#ifndef	__STR485_H__
#define __STR485_H__

#if 0
				typedef struct
				{
					uchar	dummy;
				} DUMMY_T;
#endif

/*	======================================================================================
 *	SBYTE unlock( UBYTE dev, UBYTE pwd_type, UT_T IN(user1), UBYTE OUT(match_type), ... );
 */

			typedef struct
			{
				uchar		pwd_type;
				UT_T		ut1;
				UT_T		ut2;
			} CLSV_UNLOCK;

			typedef struct
			{
				uchar		match_type0;
				uchar		match_type1;
			} SVCL_UNLOCK;


/*	======================================================================================
 *	SBYTE lock( UBYTE dev );
 */
//			typedef	DUMMY_T	CLSV_LOCK;	
//			typedef	DUMMY_T	SVCL_LOCK;	
/*	======================================================================================
 *	SBYTE actrl( UBYTE dev, UBYTE disena );
 */
			typedef	struct
			{
				uchar disena;
			} CLSV_ACTRL;	
//			typedef	DUMMY_T	SVCL_ACTRL;	
/*	======================================================================================
 *	SBYTE version( UBYTE dev, char OUT(swfw_version) );
 */
//			typedef DUMMY_T	CLSV_VERSION;
			typedef struct
			{
				char	swfw_version[ NUM_VERSION ];
			} SVCL_VERSION;
/*	======================================================================================
 *	SBYTE model( UBYTE dev, UBYTE OUT(model) );
 */
//			typedef	DUMMY_T	CLSV_MODEL;	
			typedef	struct
			{
				uchar	model;
			} SVCL_MODEL;

/*	======================================================================================
 *	SBYTE shutdown( UBYTE dev );
 */
//			typedef	DUMMY_T	CLSV_SHUTDOWN;	
//			typedef	DUMMY_T	SVCL_SHUTDOWN;	

/*	======================================================================================
 *	SBYTE gr1_status( UBYTE dev, ST_T OUT(status) );
 */
//			typedef	DUMMY_T	CLSV_GR1_STATUS;	
			typedef	struct
			{
				ST_T	status;
			} SVCL_GR1_STATUS;	
/*	======================================================================================
 *	SBYTE addusr( UBYTE dev, USER_T IN(user), SUSER_T IN(suser) );		Modified 12/1/2007	
 */
			typedef	struct
			{
				USER_T		user;
				SUSER_T		suser;
			} CLSV_ADDUSR;	
//			typedef	DUMMY_T	SVCL_ADDUSR;	
/*	======================================================================================
 *	SBYTE delusr( UBYTE dev, uchar IN(usrid), SUSER_T IN(suser) );		Modified 12/1/2007		
 */
			typedef	struct
			{
				uchar		usrid[ NUM_UID ];
				SUSER_T		suser;
			} CLSV_DELUSR;	
//			typedef	DUMMY_T	SVCL_DELUSR;	
/*	======================================================================================
 *	SBYTE editusrpass( UBYTE dev, uchar IN(usrid), uchar IN(old_pwd), uchar IN(new_pwd), UBYTE IN(edit_pass) );
 */
			typedef	struct
			{
				uchar	usrid[ NUM_UID ];
				uchar	old_pwd[ NUM_PASS ];
				uchar	new_pwd[ NUM_PASS ];
			uchar	edit_pass;
			} CLSV_EDITUSRPASS;	
//			typedef	DUMMY_T	SVCL_EDITUSRPASS;	
/*	======================================================================================
 *	SBYTE getusrdev( UBYTE dev, uchar IN(usrid), UWORD OUT(devlist) );
 */
			typedef	struct
			{
				uchar	usrid[ NUM_UID ];
			} CLSV_GETUSRDEV;	
			typedef	struct
			{	
				ushort	devlist;
			} SVCL_GETUSRDEV;	
/*	======================================================================================
 *	SBYTE setusrdev( UBYTE dev, uchar IN(usrid), UWORD devlist, SUSER_T IN(suser) );		Modified 12/1/2007	 
 */
			typedef	struct
			{
				uchar	usrid[ NUM_UID ];
				ushort	devlist;
				SUSER_T	suser;
			} CLSV_SETUSRDEV;	
//			typedef	DUMMY_T	SVCL_SETUSRDEV;	
/*	======================================================================================
 *	SBYTE valusr( UBYTE dev, uchar IN(userid), uchar IN(pwd), UWORD OUT(devlist), UBYTE OUT(pwd_match) );
 */
			typedef	struct
			{
				uchar	usrid[ NUM_UID ];
				uchar	pwd[ NUM_PASS ];
			} CLSV_VALUSR;	
			typedef	struct
			{
				ushort	devlist;
				uchar	pwd_match;
			} SVCL_VALUSR;	
/*	======================================================================================
 *	SBYTE getusrinfo( UBYTE dev, UWORD OUT(max_users), UWORD OUT(free_users) );
 */
//			typedef	DUMMY_T	CLSV_GETUSRINFO;	
			typedef	struct
			{	
				ushort	max_users;
				ushort	free_users;
			} SVCL_GETUSRINFO;	
/*	======================================================================================
 *	SBYTE usrformat( UBYTE dev, SUSER_T (IN)suser );	Modified 12/1/2007
 */
			typedef	struct
			{
				SUSER_T		suser;
			} CLSV_USRFORMAT;	
//			typedef	DUMMY_T	SVCL_USRFORMAT;	
/*	======================================================================================
 *	SBYTE blankdfs( UBYTE dev );
 */
//			typedef	DUMMY_T	CLSV_BLANKDFS;	
//			typedef	DUMMY_T	SVCL_BLANKDFS;	
/*	======================================================================================
 *	SBYTE createfile( UBYTE dev, UBYTE dfdesc, UBYTE unit_size, UBYTE access, SQUAD INOUT(num_units) );
 */
			typedef	struct
			{
				uchar	dfdesc;
				uchar	unit_size;
				uchar	access;
				long	num_units;
			} CLSV_CREATEFILE;	
			typedef	struct
			{
				long	num_units;
			} SVCL_CREATEFILE;	
/*	======================================================================================
 *	SBYTE statusfile( UBYTE dev, UBYTE dfdesc, FILESYS_T OUT(sta) );
 */
			typedef	struct
			{
				uchar	dfdesc;
			} CLSV_STATUSFILE;	
			typedef	struct
			{
				FILESYS_T	sta;
			} SVCL_STATUSFILE;	
/*	======================================================================================
 *	SBYTE readfile( UBYTE dev, UBYTE dfdesc, UBYTE num_units, uchar OUT(buff) );
 */
			typedef	struct
			{
				uchar	dfdesc;
				uchar	num_units;
			} CLSV_READFILE;	
			typedef	struct
			{
				uchar	num_units;
				uchar	buff[ LEO_BUFF ];
			} SVCL_READFILE;	
/*	======================================================================================
 *	SBYTE writefile( UBYTE dev, UBYTE df_desc, UBYTE num_units, uchar IN(buff) );
 */
			typedef	struct
			{
				uchar	dfdesc;
				uchar	num_units;
				uchar	buff[ LEO_BUFF ];
			} CLSV_WRITEFILE;	
			typedef	struct
			{
				uchar	num_units;
			} SVCL_WRITEFILE;	
/*	======================================================================================
 *	SBYTE seekfile( UBYTE df_desc, SQUAD offset, UBYTE whence );
 */
			typedef	struct
			{	
				uchar	dfdesc;
				long	offset;
				uchar	whence;
			} CLSV_SEEKFILE;	
//			typedef	DUMMY_T	SVCL_SEEKFILE;	
/*	======================================================================================
 *	SBYTE reinitfile( UBYTE dev, UBYTE dfdesc );
 */
			typedef	struct
			{	
				uchar	dfdesc;
			} CLSV_REINITFILE;	
//			typedef	DUMMY_T	SVCL_REINITFILE;	
/*	======================================================================================
 *	SBYTE getdfsinfo( UBYTE dev, DFS_INFO_T OUT(info) );
 */
//			typedef	DUMMY_T	CLSV_GETDFSINFO;	
			typedef	struct
			{	
				DFS_INFO_T	info;
			} SVCL_GETDFSINFO;	
/*	======================================================================================
 *	SBYTE tlock( UBYTE dev, UBYTE tlock0, UBYTE tlock1 );
 */
			typedef	struct
			{	
				uchar	tlock0;
				uchar	tlock1;
			} CLSV_TLOCK;	
//			typedef	DUMMY_T	SVCL_TLOCK;	
/*	======================================================================================
 *	SBYTE tunlockenable( UBYTE dev, UBYTE tlock );
 */
			typedef	struct
			{	
				uchar	tlock;
			} CLSV_TUNLOCKENABLE;	
//			typedef	DUMMY_T	SVCL_TUNLOCKENABLE;	

#if 0

/*	======================================================================================
 *	SBYTE valconfig( VALC_T IN(val0), VALC_T IN(val1) );
 */
			typedef	struct
			{	
				VALC_T	val0;
				VALC_T	val1;
			} CLSV_VALCONFIG;	
//			typedef	DUMMY_T	SVCL_VALCONFIG;	

#else


/*	======================================================================================
 *	SBYTE valconfig( UBYTE dev, VALCOMM_T IN(vals0), VALCOMM_T IN(vals1) );		Changed on 12/1/2007
 */

			typedef struct
			{
				uchar dev;
				VALCOMM_T	vals0[ NUM_VALS ];
				VALCOMM_T	vals1[ NUM_VALS ];
			} CLSV_VALCONFIG;
//			typedef	DUMMY_T	SVCL_VALCONFIG;	

#endif

/*	======================================================================================
 *	SBYTE valframe( UBYTE dev, UBYTE byte_count, uchar INOUT(buffer) );
 */
			typedef	struct
			{	
				uchar	buff[ LEO_BUFF ];
			} CLSV_VALFRAME;	

			typedef	struct
			{	
				uchar	buff[ LEO_BUFF ];
			} SVCL_VALFRAME;	

/*	======================================================================================
 *	SVCL_ERRORCODE
 */
			typedef struct
			{
				schar		error_code;
			} SVCL_ERRORCODE;	
/*	======================================================================================
 *	SBYTE actrl( UBYTE dev, UBYTE disena );
 */
			typedef	struct
			{
				uchar onoff;
			} CLSV_HCTRL;	
//			typedef	DUMMY_T	SVCL_HCTRL;
/*	======================================================================================
 *	SBYTE forceusrpass( UBYTE dev, UT_T IN(user), UWORD frames );
 */
			typedef struct
			{
				UT_T	user;
				ushort	frames;
			} CLSV_FORCEUSRPASS;
//			typedef	DUMMY_T	SVCL_FORCEUSRPASS;
/*	======================================================================================
 *	SBYTE syncnumframes( UBYTE dev );
 */
//			typedef	DUMMY_T	CLSV_SYNCNUMFRAMES;
//			typedef	DUMMY_T	SVCL_SYNCNUMFRAMES;
/*
 * 	Data union
 */

	typedef union
	{
		CLSV_UNLOCK			clsv_unlock;		
//		CLSV_LOCK			clsv_lock;
		CLSV_ACTRL			clsv_actrl;
//		CLSV_VERSION		clsv_version;
//		CLSV_MODEL			clsv_model;
//		CLSV_SHUTDOWN		clsv_shutdown;
//		CLSV_GR1_STATUS		clsv_gr1_status;
		CLSV_ADDUSR			clsv_addusr;
		CLSV_DELUSR			clsv_delusr;
		CLSV_EDITUSRPASS	clsv_editusrpass;
		CLSV_GETUSRDEV		clsv_getusrdev;
		CLSV_SETUSRDEV		clsv_setusrdev;
		CLSV_VALUSR			clsv_valusr;
//		CLSV_GETUSRINFO		clsv_getusrinfo;
		CLSV_USRFORMAT		clsv_usrformat;
//		CLSV_BLANKDFS		clsv_blankdfs;
		CLSV_CREATEFILE		clsv_createfile;
		CLSV_STATUSFILE		clsv_statusfile;
		CLSV_READFILE		clsv_readfile;
		CLSV_WRITEFILE		clsv_writefile;
		CLSV_SEEKFILE		clsv_seekfile;
		CLSV_REINITFILE		clsv_reinitfile;
//		CLSV_GETDFSINFO		clsv_getdfsinfo;
		CLSV_TLOCK			clsv_tlock;
		CLSV_TUNLOCKENABLE	clsv_tunlockenable;	
		CLSV_VALCONFIG		clsv_valconfig;
		CLSV_VALFRAME		clsv_valframe;
		CLSV_HCTRL			clsv_hctrl;
		CLSV_FORCEUSRPASS	clsv_forceusrpass;
//		CLSV_SYNCNUMFRAMES	clsv_syncnumframes;

		SVCL_UNLOCK			svcl_unlock;		
//		SVCL_LOCK			svcl_lock;	
//		SVCL_ACTRL			svcl_actrl;
		SVCL_VERSION		svcl_version;
		SVCL_MODEL			svcl_model;
//		SVCL_SHUTDOWN		svcl_shutdown;
		SVCL_GR1_STATUS		svcl_gr1_status;
//		SVCL_ADDUSR			svcl_addusr;
//		SVCL_DELUSR			svcl_delusr;
//		SVCL_EDITUSRPASS	svcl_editusrpass;
		SVCL_GETUSRDEV		svcl_getusrdev;
//		SVCL_SETUSRDEV		svcl_setusrdev;
		SVCL_VALUSR			svcl_valusr;
		SVCL_GETUSRINFO		svcl_getusrinfo;
//		SVCL_USRFORMAT		svcl_usrformat;
//		SVCL_BLANKDFS		svcl_blankdfs;
		SVCL_CREATEFILE		svcl_createfile;
		SVCL_STATUSFILE		svcl_statusfile;
		SVCL_READFILE		svcl_readfile;
		SVCL_WRITEFILE		svcl_writefile;
//		SVCL_SEEKFILE		svcl_seekfile;
//		SVCL_REINITFILE		svcl_reinitfile;
		SVCL_GETDFSINFO		svcl_getdfsinfo;
//		SVCL_TLOCK			svcl_tlock;
//		SVCL_TUNLOCKENABLE	svcl_tunlockenable;	
//		SVCL_VALCONFIG		svcl_valconfig;
		SVCL_VALFRAME		svcl_valframe;
//		SVCL_FORCEUSRPASS	svcl_forceusrpass;
//		SVCL_SYNNUMFRAMES	svcl_syncnumframes;

		SVCL_ERRORCODE		svcl_errorcode;

	} DATA_T;

#ifdef	DATA_2

typedef struct
{
	uchar	dev;
	uchar	cmd_no;
	ushort	ndata;
} DHEAD_T;

#else

typedef struct
{
	uchar	dev;
	uchar	cmd_no;
	uchar	ndata;
} DHEAD_T;

#endif

typedef struct
{
	uchar	mark;
	DHEAD_T	data_head;
	DATA_T	data;
	uchar	check;			/*	Only for structure size reasons	*/
} SBOX_T;



#endif



