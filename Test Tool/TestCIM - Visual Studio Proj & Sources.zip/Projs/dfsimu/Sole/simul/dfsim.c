/*
 * 	dfsim.c
 * 		Upper layer for addressing
 * 		dataflash
 * 		Simulation in PC
 */

#include <stdio.h>
#include <string.h>

#include "console.h"

#include "..\mytypes.h"

#include "..\vaultdef.h"
#include "..\dataflsh.h"
#include "..\dftypes.h"
#include "..\dfdata.h"
#include "..\faccess.h"
#include "..\dfrefrsh.h"

#define PAGE_SIZE_MAX	1056

typedef struct
{
	FILE *f;
	uchar buff0[ PAGE_SIZE_MAX ];
	uchar buff1[ PAGE_SIZE_MAX ];
} FL_T;

static FL_T	flash0, flash1;
static uchar buffer[ PAGE_SIZE_MAX ];
static ushort page_size[2], num_pages[2];
uint dflash_index[NUM_AVAIL_DATAFLASH];
extern char *file_flash0, *file_flash1;
extern FILE *frf;

static
FILE *
open_or_create( uint dev_no, const char *name )
{
	FILE *f;
	uint page;


	page_size[ dev_no ] = (ushort)(pdflash[ dev_no ]->page_size);
	num_pages[ dev_no ] = (ushort)(pdflash[ dev_no ]->page_count);

	if( ( f = fopen( name, "r+b" ) ) != NULL )
		return f;
	f = fopen( name, "w+b" );
	memset( buffer, 0xff, page_size[ dev_no ] );
	for( page = 0; page < num_pages[ dev_no ] ; ++page )
		fwrite( buffer, sizeof(*buffer), page_size[ dev_no ], f );
	fflush( f );
	return f;
}

/*
 * 	df_refresh
 * 		See if a page need to be refreshed
 * 		through 'must_refresh' which returns
 * 		page to be refreshed or a negative number
 * 		in case no refresh must be made
 * 		In affirmative case, calls autopage_rewrite
 */

static
void
df_refresh( MUInt device, uint page )
{
	int ref_page;

	fprintf( frf, "%04u,", page );
	if( ( ref_page = must_refresh( device, page ) ) >= 0 )
	{
		if( ref_page != page )
		{
			fprintf( frf, "%04u,%s\n", (uint)ref_page, device ? "SEC" : "MAIN" );
			dataflash_autopage_rewrite( device, ref_page );
		} else
			fprintf( frf, "%s,%s\n", "SAME", device ? "SEC" : "MAIN" );
	} else
		fprintf( frf, "%s,%s\n", "NO_REF", device ? "SEC" : "MAIN" );
	fflush( frf );
}

/*
 * 	dataflash_init:
 * 		Inits all data structures reated with this level
 * 		and calls to low level initializations
 */

void
dataflash_init( void )
{
	flash0.f = open_or_create( MAIN_DEVICE, file_flash0 );
	flash1.f = open_or_create( SECONDARY_DEVICE, file_flash1 );
}

/*
 * 	flash_query_status:
 *		This function will read the flash and determine
 *		which part is being communicated with.
 *		Returns size of flash in Mbits
 *		or 0 if flash not found in internal table
 *		If found, a global variable (pdflash) points
 *		to table entry for this device
 */

uint
dataflash_query_type( MUInt dev_no )
{
	pdflash[ dev_no ] = avail_flash + ( order_num = dflash_index[ dev_no ] );
	return pdflash[ dev_no ]->size;
}

/*
 * 	dataflash_page_size:
 * 		Returns page size of 'dev_no'
 */

uint
dataflash_page_size( MUInt dev_no )
{
	return pdflash[ dev_no ]->page_size;
}

/*
 *	dataflash_page_num:
 *		Returns num_pages of 'dev_no'
 */

uint
dataflash_page_num( MUInt dev_no )
{
	return pdflash[ dev_no ]->page_count;
}


/*
 * 	dataflash_buffer_read:
 * 		Reads 'qty' bytes directly from one
 * 		of the two RAM buffers ('which'), beginning
 * 		in 'byte_address' and writing buffer
 * 		pointed by 'prx'. If last byte of
 * 		page is hit, makes a wraparound over
 * 		the beginning of buffer
 */

void
dataflash_buffer_read( DFLASH_T *pf )
{
	FL_T *p;
	uint chunk;

	p = pf->device ? &flash1 : &flash0;

	if( ( pf->address + pf->size ) > page_size[ pf->device ] )
	{
		chunk = page_size[ pf->device ] - pf->address;
		memcpy( pf->pbuff, ( pf->wbuff ? p->buff1 : p->buff0 ) + pf->address, chunk ); 
		memcpy( pf->pbuff + chunk, ( pf->wbuff ? p->buff1 : p->buff0 ), pf->size - chunk );
	} else
		memcpy( pf->pbuff, ( pf->wbuff ? p->buff1 : p->buff0 ) + pf->address, pf->size ); 
}

/*
 * 	dataflash_main_memory_page_to_buffer_xfer:
 * 		Transfers a memory 'page_address' in buffer
 * 		'which'
 */

void
dataflash_main_memory_page_to_buffer_xfer( DFLASH_T *pf )
{
	FL_T *p;
	long pos;

	p = pf->device ? &flash1 : &flash0;
	pos = (long)(pf->base_page + pf->page) * page_size[ pf->device ];
	fseek( p->f, pos, SEEK_SET );
	fread( ( pf->wbuff ? p->buff1 : p->buff0 ), sizeof(uchar), page_size[ pf->device ], p->f );

}

/*
 * 	dataflash_main_memory_page_to_buffer_compare:
 * 		Compares internal buffer 'which' with
 * 		main memory 'page_address'.
 * 		Returns 1 if comparison is OK,
 * 		0 otherwise
 */

MUInt
dataflash_main_memory_page_to_buffer_compare( DFLASH_T *pf )
{
	FL_T *p;
	long pos;

	p = pf->device ? &flash1 : &flash0;
	pos = (long)(pf->base_page + pf->page) * page_size[ pf->device ];
	fseek( p->f, pos, SEEK_SET );
	fread( buffer, sizeof(*buffer), page_size[ pf->device ], p->f );
	return (MUInt)(memcmp( ( pf->wbuff ? p->buff1 : p->buff0 ), buffer, page_size[ pf->device ] ) == 0);
}


/*
 * 	dataflash_buffer_write:
 * 		Writes 'qty' bytes from 'prx' into
 * 		buffer 'which'. If last byte of buffer
 * 		is hit, overflows to beginning of buffer.
 * 		Buffer positions not written retain
 * 		previous information
 */

void
dataflash_buffer_write( DFLASH_T *pf )
{
	FL_T *p;
	uint chunk;

	p = pf->device ? &flash1 : &flash0;

	if( ( pf->address + pf->size) > page_size[ pf->device ] )
	{
		chunk = page_size[ pf->device ] - pf->address;
		memcpy( ( pf->wbuff ? p->buff1 : p->buff0 ) + pf->address, pf->pbuff, chunk ); 
		memcpy( ( pf->wbuff ? p->buff1 : p->buff0 ), pf->pbuff + chunk, pf->size - chunk );
	} else
		memcpy( ( pf->wbuff ? p->buff1 : p->buff0 ) + pf->address, pf->pbuff, pf->size ); 
}


/*
 * 	dataflash_buffer_to_main_memory_program:
 * 		Program with buffer 'which' contents to
 * 		main memory 'page_address' with builtin erase
 * 		if 'built_erase' != 0
 */

void
dataflash_buffer_to_main_memory_program( DFLASH_T *pf )
{
	FL_T *p;
	long pos;
	uint page;

	p = pf->device ? &flash1 : &flash0;

	page = pf->base_page + pf->page;
	pos = (long)page * page_size[ pf->device ];
	fseek( p->f, pos, SEEK_SET );
	fwrite( ( pf->wbuff ? p->buff1 : p->buff0 ), sizeof(uchar), page_size[ pf->device ], p->f );
	fflush( p->f );
	df_refresh( pf->device, page );
}


void
dataflash_power_down( void )
{
	flush_page_in_buffer();
	
	if( fclose( flash0.f ) < 0 )
		perror( "close flash0" );
	if( fclose( flash1.f ) < 0 )
		perror( "close flash1" );
}

void
dataflash_main_memory_page_read( DFLASH_T *pf )
{
	FL_T *p;
	long pos;

	p = pf->device ? &flash1 : &flash0;
	pos = (long)(pf->base_page + pf->page) * page_size[ pf->device ];
	fseek( p->f, pos, SEEK_SET );
	fread( pf->pbuff, sizeof(uchar), page_size[ pf->device ], p->f );
}

void
dataflash_main_memory_page_program_through_buffer( DFLASH_T *pf )
{
	FL_T *p;
	long pos;
	uint page;

	p = pf->device ? &flash1 : &flash0;

	page = pf->base_page + pf->page;
	memcpy( ( pf->wbuff ? p->buff1 : p->buff0 ) + pf->address, pf->pbuff, pf->size ); 
	pos = (long)page * page_size[ pf->device ];
	fseek( p->f, pos, SEEK_SET );
	fwrite( ( pf->wbuff ? p->buff1 : p->buff0 ), sizeof(uchar), page_size[ pf->device ], p->f );
	fflush( p->f );
	df_refresh( pf->device, page );
}

/*
 * 	dataflash_autopage_rewrite:
 * 		Refreshes the 'page_address' of main memory
 * 		First the contents of that page is written in
 * 		buffer 'which', then the contents of that page
 * 		are reprogrammed from buffer
 */

void
dataflash_autopage_rewrite( MUInt device, uint page )
{
}


