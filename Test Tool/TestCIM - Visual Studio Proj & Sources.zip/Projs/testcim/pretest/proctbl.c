/*
 * 	proctbl.c
 */

#include "actdef.h"
#include "action.h"

/*
 * 		Macros for table constructing
 */

#define	action(txt,type)	{#txt,txt,type}

/*
 * Table of actions for each operation
 */

INTER_T const action_table[ NUM_ACTIONS ] =
{
	/*
	 * 	Here project independent actions
	 */
	action(begin_proc,			PROC_TYPE	),
	action(end_proc,			NORMAL_TYPE	),
	action(for_each,			NORMAL_TYPE	),
	action(for_end,				NORMAL_TYPE	),
	action(begin_test,			TEST_TYPE	),
	action(end_test,			NORMAL_TYPE	),
	action(sak_user,			NORMAL_TYPE	),
	action(set_sleep,			NORMAL_TYPE	),
	action(equate,				EQUATE_TYPE	),
	action(ext_proc,			EXT_TYPE 	),

	/*
	 * Here project dependent actions
	 */

	action(sbtst_set_periph,	NORMAL_TYPE ),
	action(safe_tlock_cfg,		NORMAL_TYPE ),
	action(safe_tunlocke_cfg,	NORMAL_TYPE ),
	action(safe_set_alarm,		NORMAL_TYPE ),
	action(safe_set_hostpwr,	NORMAL_TYPE ),
	action(safe_unlock,			NORMAL_TYPE ),

	action(chk_rs485_response,	NORMAL_TYPE ),
	action(sbtst_check_privdc,	NORMAL_TYPE ),
	action(safe_chk_grstat,		NORMAL_TYPE ),
	action(sbtst_check_vbatt,	NORMAL_TYPE ),
	action(sbtst_check_secvdc,	NORMAL_TYPE ),
	action(safe_valtest,		NORMAL_TYPE ),
	action(sbtst_check_periph,	NORMAL_TYPE ),
	action(safe_users_format,	NORMAL_TYPE ),
   	action(safe_blank_filesys,	NORMAL_TYPE ),
   	action(safe_add_user,		NORMAL_TYPE ),
   	action(sbtst_clr_periph,	NORMAL_TYPE )
};

int const parse_matrix[ NUM_ACTIONS ][ NUM_STATES ] =
{
		/*	IDLE		IN_SUBPROC		IN_TEST			IN_FOR			IN_FOR_SUB		IN_ERROR	*/
	{	IN_SUBPROC,		IN_ERROR,		IN_ERROR,		IN_ERROR,		IN_ERROR,		IN_ERROR	},		/*	BEGIN_PROC			*/
	{	IN_ERROR,		IDLE,			IN_ERROR,		IN_ERROR,		IN_ERROR,		IN_ERROR	},		/*	END_PROC			*/
	{	IN_ERROR,		IN_FOR_SUB,		IN_FOR,			IN_ERROR,		IN_ERROR,		IN_ERROR	},		/*	FOR_EACH			*/
	{	IN_ERROR,		IN_ERROR,		IN_ERROR,		IN_TEST,		IN_SUBPROC,		IN_ERROR	},		/*	FOR_END				*/
	{	IN_TEST,		IN_ERROR,		IN_ERROR,		IN_ERROR,		IN_ERROR,		IN_ERROR	},		/*	BEGIN_TEST			*/
	{	IN_ERROR,		IN_ERROR,		IDLE,			IN_ERROR,		IN_ERROR,		IN_ERROR	},		/*	END_TEST			*/
	{	IN_ERROR,		IN_SUBPROC,		IN_TEST,		IN_FOR,			IN_FOR_SUB,		IN_ERROR	},		/*	SAK_USER			*/
	{	IN_ERROR,		IN_SUBPROC,		IN_TEST,		IN_FOR,			IN_FOR_SUB,		IN_ERROR	},		/*	SET_SLEEP			*/
	{	IDLE,			IN_SUBPROC,		IN_TEST,		IN_FOR,			IN_FOR_SUB,		IN_ERROR	},		/*	EQUATE				*/
	{	IDLE,			IN_ERROR,		IN_ERROR,		IN_ERROR,		IN_ERROR,		IN_ERROR	},		/*	EXT_PROC			*/

	{	IN_ERROR,		IN_SUBPROC,		IN_TEST,		IN_FOR,			IN_FOR_SUB,		IN_ERROR	},		/*	SBTST_SET_PERIPH	*/
	{	IN_ERROR,		IN_SUBPROC,		IN_TEST,		IN_FOR,			IN_FOR_SUB,		IN_ERROR	},		/*	SAFE_TLOCK_CFG		*/
	{	IN_ERROR,		IN_SUBPROC,		IN_TEST,		IN_FOR,			IN_FOR_SUB,		IN_ERROR	},		/*	SAFE_TUNLOCKE_CFG	*/
	{	IN_ERROR,		IN_SUBPROC,		IN_TEST,		IN_FOR,			IN_FOR_SUB,		IN_ERROR	},		/*	SAFE_SET_ALARM		*/
	{	IN_ERROR,		IN_SUBPROC,		IN_TEST,		IN_FOR,			IN_FOR_SUB,		IN_ERROR	},		/*	SAFE_SET_HOSTPWR	*/
	{	IN_ERROR,		IN_SUBPROC,		IN_TEST,		IN_FOR,			IN_FOR_SUB,		IN_ERROR	},		/*	SAFE_UNLOCK			*/
	{	IN_ERROR,		IN_SUBPROC,		IN_TEST,		IN_FOR,			IN_FOR_SUB,		IN_ERROR	},		/*	CHK_RS485_RESPONSE	*/
	{	IN_ERROR,		IN_SUBPROC,		IN_TEST,		IN_FOR,			IN_FOR_SUB,		IN_ERROR	},		/*	SBTST_CHECK_PRIVDC	*/
	{	IN_ERROR,		IN_SUBPROC,		IN_TEST,		IN_FOR,			IN_FOR_SUB,		IN_ERROR	},		/*	SAFE_CHK_GRSTAT		*/
	{	IN_ERROR,		IN_SUBPROC,		IN_TEST,		IN_FOR,			IN_FOR_SUB,		IN_ERROR	},		/*	SBTST_CHECK_VBATT	*/
	{	IN_ERROR,		IN_SUBPROC,		IN_TEST,		IN_FOR,			IN_FOR_SUB,		IN_ERROR	},		/*	SBTST_CHECK_SECVDC	*/
	{	IN_ERROR,		IN_SUBPROC,		IN_TEST,		IN_FOR,			IN_FOR_SUB,		IN_ERROR	},		/*	SAFE_VALTEST		*/
	{	IN_ERROR,		IN_SUBPROC,		IN_TEST,		IN_FOR,			IN_FOR_SUB,		IN_ERROR	},		/*	SBTST_CHECK_PERIPH	*/
	{	IN_ERROR,		IN_SUBPROC,		IN_TEST,		IN_FOR,			IN_FOR_SUB,		IN_ERROR	},		/*	SAFE_USERS_FORMAT	*/
	{	IN_ERROR,		IN_SUBPROC,		IN_TEST,		IN_FOR,			IN_FOR_SUB,		IN_ERROR	},		/*	SAFE_BLANK_FILESYS	*/
	{	IN_ERROR,		IN_SUBPROC,		IN_TEST,		IN_FOR,			IN_FOR_SUB,		IN_ERROR	},		/*	SAFE_ADD_USER		*/
	{	IN_ERROR,		IN_SUBPROC,		IN_TEST,		IN_FOR,			IN_FOR_SUB,		IN_ERROR	}		/*	SBTST_CLR_PERIPH	*/
};

