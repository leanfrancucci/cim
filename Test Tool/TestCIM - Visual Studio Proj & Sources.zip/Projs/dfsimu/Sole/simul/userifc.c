/*
 * 	userifc.c
 * 		User Interface
 * 		for testing
 */

#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>

#include "terminal.h"

#include "..\allinc.h"
#include "..\dfdata.h"
#include "..\dfmanage.h"
#include "..\dataflsh.h"
#include "..\users.h"
#include "..\dfilsys.h"
#include "..\dfsys.h"
#include "..\dftypes.h"
#include "userifc.h"

#define LAST_DEVICE		254
#define LAST_USER		999999999UL

#define MEGA			((ulong)KBYTE*KBYTE)
#define KBYTE			1024

static char * const init_msg[] =
{
	"INIT_OK",					/*	No errors in both flashes			*/
	"COLD_FORMATTED",			/*	Typical in first use				*/
	"RECOVERED",				/*	Errors recovered					*/
};

static char * const users_msg[] =
{
	"USER_OK",
	"ERR_USER_NOT_EXISTS",			/*	user_id doesn't exists				*/
	"ERR_USER_BAD_PASSWORD",		/*	Password presented does not match	*/
	"ERR_USER_NUM_EXCEEDED",		/*	Can't add a new user				*/
	"ERR_USER_EXISTS",				/*	user_id	exists						*/
	"ERR_FREE1",					/*	Error not exists			 		*/
	"ERR_USER_COMM_NOT_IN_EMERG",	/*	Command not allowed in emergency	*/
	"ERR_FREE2",					/*	Error not exists					*/
	"ERR_FLASH_BAD_PROGRAM",		/*	Programming does not verify			*/
	"ERR_INVALID_CONTENT",

	"ERR_DFILE_INVALID_DF",			/*	Invalid file descriptor				*/
	"ERR_DFILE_BAD_ACCESS",			/*	Bad access in create				*/
	"ERR_DFILE_NOT_ENOUGH",			/*	Not enough place for creation		*/
	"ERR_DFILE_NOT_ALLOWED",		/*	Operation not allowed				*/
	"ERR_DFILE_BAD_WHENCE",			/*	Bad whence data in seek				*/
	"ERR_DFILE_BAD_SEEK",			/*	Seeks cannot be done				*/
	"ERR_DFILE_BAD_FDESC",			/*	File descriptor out of range		*/
	"ERR_DFILE_EXISTS_FDESC",		/*	File exists for the same descriptor	*/
	"ERR_DFILE_NOT_EXISTS",			/*	File not exists						*/
	"ERR_DFILE_BAD_ORIGIN",			/*	Invocation origin not exists		*/
	"ERR_DFILE_SECTOR_ERROR",		/*	Sector error in reading				*/
	"ERR_DFILE_BAD_OFFSET",			/*	Offset out of limits				*/
	"ERR_DFILE_BAD_UNITSIZE",		/*	Record size is too long or zero		*/
	"ERR_DFILE_BAD_NUMUNITS",		/*	Record number is zero				*/
};

static char * const validate_msg[] =
{
	"PASS0_MATCH",
	"PASS1_MATCH",
	"PASS_BAD",
};

static char * const edit_msg[] =
{
	"EDIT_PASS0 <0>",
	"EDIT_PASS1 <1>",
	"BOTH_EDIT <2>"
};

static char * const part_number[] =
{
	"AT45DB161B",
	"AT45DB321B"
};

typedef struct
{
	uchar	used;
	uchar signature;
	USER_T	user;
} FUSER_T;

static FUSER_T	usert;

static USER_T user, user_new;
static USER_T userp =
{
	{ '0' }, 0, 
	{ '1', '2', '3', '4', '5', '6', '7', '8' },
	{ '8', '7', '6', '5', '4', '3', '2', '1' }
};

#define fname	"rwtest"

static uchar buff[1024];
static uchar tbuff[256];
static uint num_users;
static char *flsel = "aflsel";
static uint wthru;
static char refresh_file[] = "refresh.csv";
char *file_flash0 = "afl0";
char *file_flash1 = "afl1";

extern uint dflash_index[2];

FILE *frf;

void dataflash_power_down( void );

static
void
write_which( uint index_main, uint index_sec )
{
	FILE *f;

	if( ( f = fopen( flsel, "wb" ) ) == NULL )
	{
		perror( flsel );
		exit( EXIT_FAILURE );
	}
	fwrite( &index_main, 1, sizeof( index_main ), f );
	fwrite( &index_sec, 1, sizeof( index_sec ), f );
	fclose( f );
}

static
int
read_which( uint *pindex_main, uint *pindex_sec )
{
	FILE *f;

	if( ( f = fopen( flsel, "rb" ) ) == NULL )
		return 0;
	fread( pindex_main, 1, sizeof( *pindex_main ), f );
	fread( pindex_sec, 1, sizeof( *pindex_sec ), f );
	fclose( f );
	return 1;
}

static
void
set_dflash_index( uint index_main, uint index_sec )
{
	dflash_index[0] = index_main;
	dflash_index[1] = index_sec;
	write_which( index_main, index_sec );
}

static
long
getlong( char const *msg )
{
	uint first;
	long value;

	first = 0;
	for(;;)
	{
		printf( "Input %s :" , msg);
		if( !first ) first = 1; else putchar( '\a' );
		if( fgets( (char *)buff, sizeof( buff ), stdin ) == NULL )
			exit( EXIT_SUCCESS );
		if( sscanf( (const char *)buff, "%ld", &value ) == 1 )
			return value;
	}
}

static
uint
getint( char const *msg, uint max )
{
	uint value, first;

	first = 0;
	do
	{
		printf( "Input %s : ( 0 to %u )", msg, max );
		if( !first ) first = 1; else putchar( '\a' );
		if( fgets( (char *)buff, sizeof( buff ), stdin ) == NULL )
			exit( EXIT_SUCCESS );
		if( sscanf( (const char *)buff, "%u", &value ) != 1 )
			continue;
	} while( value > max );
	return value;
}

static
char *
get_string( char const *msg, uint max )
{
	uint first, len;

	first = 0;
	do
	{
		printf( "Input %s: <exactly %d> ", msg, max );
		if( !first ) first = 1; else putchar( '\a' );
		if( fgets( (char *)buff, sizeof( buff ), stdin ) == NULL )
			exit( EXIT_SUCCESS );
		len = strlen( (char *)buff );
		if( buff[ ( len = strlen( (const char *)buff ) ) - 1 ] == '\n' )
			buff[ --len ] = '\0';
	} while( len != max );
	return (char *)buff;
}

static
uchar *
getuser( uchar *puser )
{
	memcpy( puser, get_string( "user_id", NUM_UID ), NUM_UID );
	return puser;
}

static
void
print_user( uchar *puser )
{
	int i;

	for( i = 0 ; i < NUM_UID ; ++i, ++puser )
		putchar( *puser );
}

static
ulong
getuser_numeric( void )
{
	ulong number;

	do
	{
		printf( "Input a user_id as number <0-%lu> : ", LAST_USER );
		while( scanf( "%lu", &number ) != 1 )
		{
			fgets( (char *)buff, sizeof( buff ), stdin );
			printf( "Input a user_id as number <0-%lu> : ", NUM_UID );
		}
	} while( number > LAST_USER );
	fgets( (char *)buff, sizeof( buff ), stdin );
	return number;
}



static
uint
getint_hex( char const *msg, uint max )
{
	uint value, first;

	first = 0;
	do
	{
		printf( "Input %s : ( 0 to %X )", msg, max );
		if( !first ) first = 1; else putchar( '\a' );
		if( fgets( (char *)buff, sizeof( buff ), stdin ) == NULL )
			exit( EXIT_SUCCESS );
		if( sscanf( (const char *)buff, "%x", &value ) != 1 )
			continue;
	} while( value > max );
	return value;
}

static
uint
verify_ascii( uchar *p, uint num )
{
	while( num-- )
		if( !isgraph( *p++ ) )
			return 0;
	return 1;
}

static
void
getpass( char const *msg, uint num, uchar *p )
{
	uint status, first;

	first = 0;
	do
	{
		status = 0;
		printf( "Input %s (exactly %u characters) : ", msg, num );
		if( !first ) first = 1; else putchar( '\a' );
		if( fgets( (char *)buff, sizeof( buff ), stdin ) == NULL )
			exit( EXIT_SUCCESS );
		if( strlen( (const char *)buff ) == num + 1 )
		{
			memcpy( p, buff, num );
			status = verify_ascii( p, 8 );
		}
	} while( !status );
}

static
void
one_complement( void *p, int qty )
{
	uchar *q;

	for( q = p; qty-- ; ++q )
		*q ^= 0xff;
}

int
format_flash( void )
{
	uint status;

	printf( "Executing flash formatting.....\n" );
	status = users_format();
	printf( "\tusers_format executed: status = %s\n", init_msg[ status ] );
	printf( "Power up sequence with formatting terminated....\n" );
	change_menu( emerg + 1 );
	return 1;

}

int
set_processor( void )
{
	printf( "Executing set_processor......\n" );
	emerg = (uchar)getint( "from which processor at power up: MAIN <0> EMERGENCY <1> : ", 1 );
	printf( "Processor set to %s......\n", emerg ? "EMERGENCY" : "MAIN" );
	return 1;
}


int
power_up( void )
{
	int status;
	ushort df_exists;
	ushort df_error, page_err;

	printf( "Executing power up sequence (emerg %u).....\n", emerg );
	dfmanage_init( emerg );
	if( !emerg )
		printf( "\tFlash %u detected: capacity = %uMbit, page_size = %ubytes\n",
				MAIN_DEVICE, dataflash_query_type( MAIN_DEVICE ), dataflash_page_size( MAIN_DEVICE ) );
	printf( "\tFlash %u detected: capacity = %uMbit, page_size = %ubytes\n",
			SECONDARY_DEVICE, dataflash_query_type( SECONDARY_DEVICE ), (page_size = (ushort)dataflash_page_size( SECONDARY_DEVICE )) );
	status = users_init( &num_users );
	printf( "\tusers_init executed: status = %s, num_users = %u\n", init_msg[ status ], num_users );
	printf( "\tEffective user size = %u\n", sizeof( FUSER_T ) );
	printf( "\tUsers per page = %u\n", num_users_per_page = (ushort)(page_eff_size/sizeof( FUSER_T )) );
	page_err = (ushort)dfilesys_init( &df_exists, &df_error);
	printf( "\tdfilesys_init executed: pages in error = %u\n", page_err );
	printf( "\tfile descriptors: exists mask = %02.2X, error_mask = %02.2X\n", df_exists, df_error );

	printf( "Power up sequence terminated....\n" );
	change_menu( emerg + 1 );
	return 1;
}

int
uadd( void )
{
	int status;

	printf( "Adding a user......\n" );
	user.dev_list = (ushort)getint_hex( "Device List", 0xffff );
	getuser( user.user_id );
	getpass( "Password 0", 8, user.pass0 );
	getpass( "Password 1", 8, user.pass1 );
	status = users_add( &user );
	printf( "Adding a user terminated: status = %s\n", users_msg[ -status ]);
	return 1;
}

int
umultadd( void )
{
	int status;
	ulong from_user, to_user, user;

	printf( "Adding multiple users.......\n" );
	from_user = getuser_numeric();
	to_user = getuser_numeric();
	userp.dev_list = (ushort)getint_hex( "Device List", 0xffff );
	for( user = from_user ; user <= to_user ; ++user )
	{
		sprintf( (char *)buff, "%016.16lu\n", user );
		memcpy( userp.user_id, buff, NUM_UID );
		status = users_add( &userp );
		printf( "\tAdding user %u : status = %s\n", user, users_msg[ -status ]);
	}
	printf( "Adding a user to multiple devices terminated......\n" );
	return 1;
}

int
uerase( void )
{
	int status;
	uchar user_id[NUM_UID];

	printf( "Erasing a user......\n" );
	getuser( user_id );
	status = users_erase( user_id );
	printf( "Erasing a user terminated: status = %s\n", users_msg[ -status ]);
	return 1;
}

int
uvalidate( void )
{
	int status;
	uchar match;
	ushort dev_list;

	printf( "Validating a user......\n" );
	getuser( user.user_id );
	getpass( "Password", 8, user.pass0 );
	status = users_validation( &user, &match, &dev_list );
	if( status != 0 )
	{
		printf( "Validating a user terminated with error = %s\n", users_msg[ -status ]);
		return 1;
	}
	printf( "User device list = %X\n", dev_list );
	printf( "Validating a user terminated ok: result %s\n", validate_msg[ match ] );
	return 1;
}

int
uedit( void )
{
	uint select, i;
	int status;

	printf( "Editing a user......\n" );
	getuser( user.user_id );
	memcpy( user_new.user_id, user.user_id, NUM_UID );
	getpass( "actual password", 8, user.pass0 );
	printf( "\tValues to select:\n" );
	for( i = 0 ; i < sizeof( edit_msg )/sizeof( *edit_msg ) ; ++i )
		printf("\t\t%s\n", edit_msg[i] );
	select = getint( "selection number", sizeof( edit_msg )/sizeof( *edit_msg ) - 1 );
	switch( select )
	{
		case 0:
			getpass( "new password 0", 8, user_new.pass0 );
			break;
		case 1:
			getpass( "new password 1", 8, user_new.pass1 );
			break;
		case 2:
			getpass( "new password 0", 8, user_new.pass0 );
			getpass( "new password 1", 8, user_new.pass1 );
			break;
	}
	status = users_edit( (MUInt)select, &user, &user_new, FORCE_EDIT );
	printf( "Editing a user terminated: status = %s\n", users_msg[ -status ]);
	return 1;
}


static
void
doprint_pass( char const *msg, uchar *p, uint num )
{
	printf( "%s", msg );
	while( num-- )
		putchar( *p++ );
	putchar( ' ' );
}

int
ulist( void )
{
	uint free_count, used_count;
	DFLASH_T df;

	printf( "Listing users.........\n" );

	free_count = used_count = 0;

	df.device = (uchar)emerg;
	df.wbuff = BUFFER0;
	df.base_page = 0;
	for( df.page = 0 ; df.page < /*NUM_FLASH_PAGES_FOR_USERS*/ 1 ; ++df.page )
	{
		printf( "Page %u\n", df.page );
		df_read_page( &df );
		df.pbuff = (uchar *)&usert;
		df.size = sizeof( FUSER_T );
		for( df.address = 0 ; df.address < num_users_per_page * sizeof( FUSER_T )  ; df.address += sizeof( FUSER_T ) )
		{
			df_read_data( &df );
			if( !usert.used )
			{
				++free_count;
				continue;
			}
			++used_count;
			printf( "\tuser_id: ");
			print_user( usert.user.user_id );
			printf( " - dev_list:%4X - ",  usert.user.dev_list );
			doprint_pass( "pass0: ", usert.user.pass0, 8 );
			doprint_pass( "pass1: ", usert.user.pass1, 8 );
			putchar( '\n' );
		}
	}
	printf( "\n\tFree: %3u - Used: %3u\n", free_count, used_count );
	printf( "Listing done.......\n" );
	return 1;
}

int
power_down( void )
{
	dataflash_power_down();
	change_menu( 0 );
	emerg = 0;
	return 0;
}

int
kill_page( void )
{
	uint which_flash, page, mainbank, kill;
	DFLASH_T df;

	printf( "Kill page........\n" );
	dataflash_init();
	page_size = (ushort)dataflash_page_size( MAIN_DEVICE );
	num_users_per_page = ( page_size - sizeof( ushort ) )/sizeof( FUSER_T );
	which_flash = getint( "device: main <0>, secondary <1> : ", 1 );
	page = getint( "page : ", NUM_FLASH_PAGES_FOR_USERS-1 );
	mainbank = getint( "bank: original <0> or backup <1> bank : ", 1 );
	kill = getint( "what to do -> modify <0>, kill <1> : ", 1 );

	df.device = (uchar)which_flash;
	df.wbuff = BUFFER0;
	df.base_page = (ushort)(mainbank * NUM_FLASH_PAGES_FOR_USERS);
	df.page = (ushort)page;
	df.copy = 0;
	df.both = 0;
	df.berase = 1;

	df_read_page( &df );
	if( !kill )
	{
		df.pbuff = (uchar *)&usert;
		df.size = sizeof( FUSER_T );
		for( df.address = 0 ; df.address < num_users_per_page * sizeof( FUSER_T ) ; df.address += sizeof( FUSER_T ) )
		{
			df_read_data( &df );
			one_complement( &usert, sizeof( FUSER_T ) );
			df_write_data( &df );
		}
		df_write_page( &df );
	} else
		complement_check_and_write( &df );

	dataflash_power_down();
	printf( "Kill page terminated........" );
	return 1;
}

static
long
get_file_size( const char *name )
{
	FILE *f;
	long size;

	if( ( f = fopen( name, "rb" ) ) == NULL )
		return 0;
	fseek( f, 0L, SEEK_END );
	size = ftell( f );
	fclose( f );
	return size;
}

static
void
show_dflash( uint mem_num )
{
	printf( "\tAtmel part number = %s\n", part_number[ mem_num ] );
	printf( "\tMemory size =	%u Mbit\n", avail_flash[ mem_num ].size );
	printf( "\tSector count =	%u\n", avail_flash[ mem_num ].sector_count );
	printf( "\tPage size =	%u bytes\n", avail_flash[ mem_num ].page_size );
	printf( "\tPage count =	%u\n", avail_flash[ mem_num ].page_count );
}

static
int
select_memory( uint mem_num )
{
	long fsize0, fsize1;
	int c;

	set_dflash_index( mem_num, mem_num );
	printf( "Memory selection for both dataflash.....\n" );
	show_dflash( mem_num );
	fsize0 = get_file_size( file_flash0 );
	fsize1 = get_file_size( file_flash1 );
	if( fsize0 > 0 || fsize1 > 0 )
	{
		printf( "\tflash0 = %lu, = %lu bytes....\n", fsize0, fsize1 );
		printf( "\tRemove files? <Y/N>: " );
		while( ( c = toupper( getch() ) ) != 'Y' && c != 'N' )
			putchar( '\a' );
		printf( "%c\n", c );
		if( c == 'Y' )
		{
			printf( "\tRemoving files......\n" );
			if( remove( file_flash0 ) < 0 )
				perror( file_flash0 );
			if( remove( file_flash1 ) < 0 )
				perror( file_flash1 );
		}
	} else
		printf( "\tFiles doesn't exists...\n" );
	dataflash_query_type( 0 );
	dataflash_query_type( 1 );
	change_menu(0);
	printf( "Memory selection terminated.....\n" );
	return 1;
}

static
int
get_fd( void )
{
	char b[50];

	sprintf( b, "file descriptor <0-%u>", NUM_FDS-1 );
	return getint( b, 9 );
}

void
open_refresh( void )
{
	if( ( frf = fopen( refresh_file, "at" ) ) == NULL )
	{
		perror( "refresh.csv" );
		exit( EXIT_FAILURE );
	}
}


int
setdf0( void )
{
	return select_memory( 0 );
}

int
setdf1( void )
{
	return select_memory( 1 );
}


int
goto_menu0( void )
{
	change_menu(0);
	return 0;
}

int
set_dataflash( void )
{
	change_menu(3);
	return 0;
}

int
which_dataflash( void )
{
	printf( "Installed dataflash.........\n" );
	show_dflash( dflash_index[0] );
	printf( "Installed dataflash end.....\n" );
	return 1;
}

int
go_simulation( void )
{
	which_dataflash();
	printf( "\n\n\tInput newline to continue....." );
	getchar();
	dataflash_query_type( 0 );
	dataflash_query_type( 1 );
	open_refresh();
	return 0;
}

void
verify_dflash( void )
{
	if( read_which( &dflash_index[0], &dflash_index[1] ) == 0 )
		set_dflash_index( 0, 0 );
}

int
filesys_blanking( void )
{
	printf( "File system blanking.....\n" );
	dfilesys_blanking();
	printf( "File system blanking ends.....\n" );
	return 1;
}

static
void
show_this_dir( int fd )
{
	FILESYS_T fsta;
	int status;

	printf( "\tfd = %2u : ", fd );  
	if( ( status = dfilesys_status_file( fd, &fsta ) ) != DFILE_OK )
	{
		printf( "\t\t%s\n", users_msg[ -status ] );
		return;
	}
	printf( "type = %s, unit_size = %u, num_units = %lu\n",
		( fsta.file_type == RANDOM ? "RANDOM" : "QUEUE" ),
		fsta.unit_size, fsta.num_units );
	if( fsta.file_type == QUEUE )
		printf( "\t\tin_index = %lu, out_index %lu, num_elems %u\n", fsta.in_index, fsta.out_index, fsta.num_elems );
	printf( "\t\tposition = %lu\n", fsta.position );
}

static
void
show_whole_dir( void )
{
	int fd;

	for( fd = DF_FIRST_DESC ; fd < NUM_FDS ; ++fd ) 
		show_this_dir( fd );
}


int
show_dir( void )
{
	printf( "Showing directory.....\n" );
	show_whole_dir();
	printf( "Showing directory ended.....\n" );
	return 1;
}

static int get_fd( void );
int
do_create_file( void )
{
	long num_units;
	int access, unit_size, fd;
	int status;

	printf( "File creation.....\n" );
	show_whole_dir();
	do
	{
		fd = get_fd();
		do
			unit_size = getint( "unit size <1, 255> : ", 255 );
		while( unit_size == 0 );

		access = getint( "access <0-RANDOM, 1-QUEUE> : ", 1 );
		num_units = getlong( "File size in units <0:all remaining space> : " );
		if( num_units == 0L )
			num_units = -1L;
	} while( getint( "are you sure ? <0:NO - 1:YES> : ", 1 ) == 0 ); 

	if( ( status = dfilesys_create_file( fd, unit_size, access, &num_units ) ) != DFILE_OK )
	{
		printf( "\t\t%s\n", users_msg[ -status ] );
		if( -status == ERR_DFILE_NOT_ENOUGH )
			printf( "\t\tSpace remaining is for %lu units\n", num_units );
	}else
		printf( "\tSpace allocated %lu units\n", num_units );
	printf( "File creation ended.....\n" );
	return 1;

}

int
show_sys_info( void )
{
	DFS_INFO_T *p;

	printf( "Showing space information.....\n" );
	p = dfilesys_get_information();
	printf( "\tRemaining file system space = %lu bytes\n", p->dfs_size );

	printf( "Showing space information ended.....\n" );
	return 1;

}

static
void
show_this_file_status( int fd )
{
	FILESYS_T fsta;
	int status;

	if( ( status = dfilesys_status_file( fd, &fsta ) ) != DFILE_OK )
		printf( "%s\n", users_msg[ -status ] );
	else
	{
		printf( "\tfile_type = %s\n", fsta.file_type == RANDOM ? "RANDOM" : "QUEUE" );
		printf( "\tunit_size = %u, num_units = %lu\n", fsta.unit_size, fsta.num_units );
		if( fsta.file_type == QUEUE )
			printf( "\tin_index = %lu, out_index %lu\n", fsta.in_index, fsta.out_index );
		printf( "\tposition = %lu\n", fsta.position );
	}
}


int
show_file_status( void )
{
	unsigned fd;

	printf( "Showing file status.....\n" );
	show_whole_dir();
	fd = get_fd();
	show_this_file_status( fd );

	printf( "Showing file status ended.....\n" );
	return 1;
}

int
do_read_file( void )
{
	int fd;

	printf( "Reading file.....\n" );
	show_whole_dir();
	fd = get_fd();

	
	printf( "Reading file ended.....\n" );
	return 1;
}

int
do_write_file( void )
{
	int fd, status;
	FILESYS_T sta;
	FILE *f;
	uint num_items, num_read, num_bytes;

	printf( "Writing file.....\n" );
	if( ( f = fopen( fname, "rb" ) ) == NULL )
	{
		perror( "fname" );
		return 1;
	}

	show_whole_dir();
	fd = get_fd();

	do
	{
		num_items = getint( "num items to write", 250 );
		dfilesys_status_file( fd, &sta );
		if( ( num_bytes = num_items * sta.unit_size ) > LEO_BUFFER )
			printf( "Comm buffer exceeded, expected maximum %u bytes, current %u\n", LEO_BUFFER, num_bytes );
	} while( num_bytes > LEO_BUFFER );


	printf( "\tPosition informed by file sistem %ld\n", (long)sta.position * sta.unit_size );
	fseek( f, (long)sta.position * sta.unit_size, SEEK_SET );


	if( ( num_read = fread( buff, sta.unit_size , num_items, f ) ) < 0 )
	{
		perror( fname );
		return 1;
	}
	printf( "\tnum_elems read %u\n", num_read );

	if( ( status = dfilesys_write_file( fd, num_read, buff ) ) < 0 )
		printf( "dfilesys_write_file: %s\n", users_msg[ -status ] );
	else
		printf( "\tnum_elems written %u\n", status );
	printf( "Writing file ended.....\n" );
	return 1;
}

int
do_write_whole_file( void )
{
	int fd, status;
	FILESYS_T sta;
	FILE *f;
	uint num_items, num_read;
	ulong count, num_to_write;

	printf( "Writing whole file.....\n" );
	if( ( f = fopen( fname, "rb" ) ) == NULL )
	{
		perror( "fname" );
		return 1;
	}

	show_whole_dir();
	fd = get_fd();
	fseek( f, 0L, SEEK_SET );
	dfilesys_status_file( fd, &sta );

	num_to_write = getlong( "num elements to write <maximum=0>" );
	if( num_to_write == 0 )
		num_to_write = 	100000000000UL;

	num_items = 1;

	count = 0;
	for( count = 0 ; count < num_to_write ; ++count )
	{
		if( ( num_read = fread( buff, sta.unit_size , num_items, f ) ) < 0 )
		{
			perror( fname );
			return 1;
		}
//		printf( "\t%ld: %u\r", count++, num_read );

		if( ( status = dfilesys_write_file( fd, num_read, buff ) ) < 0 )
		{
			printf( "dfilesys_write_file: %s\n", users_msg[ -status ] );
			return 1;
		}
		printf( "\t%ld: %u\n", count, status );
		if( status == 0 )
			break;
	}
	printf( "Writing whole file ended.....\n" );

	return 1;
}

int
do_read_whole_file( void )
{
	int fd, status;
	FILESYS_T sta;
	FILE *f;
	uint num_items;
	ulong count, num_to_read;

	printf( "Reading whole file.....\n" );
	if( ( f = fopen( "salida", "wb" ) ) == NULL )
	{
		perror( "salida" );
		return 1;
	}

	show_whole_dir();
	fd = get_fd();
	fseek( f, 0L, SEEK_SET );
	dfilesys_status_file( fd, &sta );

	num_to_read = getlong( "num elements to read <maximum=0>" );
	if( num_to_read == 0 )
		num_to_read = 100000000000UL;

	num_items = 1;

	for( count = 0; count < num_to_read ; ++count )
	{
		if( ( status = dfilesys_read_file( fd, num_items, buff ) ) < 0 )
		{
			printf( "dfilesys_read_file: %s\n", users_msg[ -status ] );
			break;
		}
		printf( "\t%8ld: %d units\n", count, status );
		if( status == 0 )
			break;
		if( fwrite( buff, sta.unit_size , num_items, f ) < 0 )
		{
			perror( "salida" );
			return 1;
		}
	}
	printf( "\nReading whole file ended.....\n" );
	fclose( f );

	return 1;
}


int
do_seek_file( void )
{
	int fd, status;
	long offset;
	uint whence;

	printf( "Seeking file.....\n" );
	show_whole_dir();
	fd = get_fd();
	offset = getlong( "offset " );
	whence = getint( "whence <0=SEEK_SET,1=SEEK_CUR,2=SEEK_END>", 2 );
	if( ( status = dfilesys_seek( fd, offset, whence ) ) != DFILE_OK )
		printf( "\t\t%s\n", users_msg[ -status ] );
	show_this_file_status( fd );
	printf( "Seeking file ended.....\n" );
	return 1;
}


int
goto_file( void )
{
	if( emerg )
	{
		printf( "Can't address file in emergency....\n" );
		return 1;
	}
	change_menu(4);
	return 0;
}

int
do_user_menu( void )
{
	change_menu(1);
	return 0;
}

int
create_test_file( void )
{
	ulong size, count;
	int c, next;
	FILE *f;

	printf( "Creating test file......\n" );

	remove( fname );
	if( ( f = fopen( fname, "wb" ) ) == NULL )
	{
		perror( fname );
		return 1;
	}

	size = getlong( "file size in Kbytes" );

	for( count = 0, next = -1, c = '0' ; count < (size * KBYTE) ; ++count, ++c )
	{
		if( next > 0 )
		{
			fputc( next, f );
			next = -1;
			--c;
		}
		if( c == '9'+1 )
			c = 'A';
		else if( c == 'Z'+1 )
			c = 'a';
		else if( c == 'z'+1 )
		{
			c = '0';
			next = '\n';
		}
		if( next < 0 )
			fputc( c, f );
	}
	fclose( f );

	printf( "Creating test file ended......\n" );
	return 1;
}

int
cache_use( void )
{
	printf( "Use of page cache........\n" );
	wthru = getint( "value: <0>->cached, <1>->write trough", 1 );
	printf( "\tSelection %s\n", wthru ? "WRITE TROUGH" : "CACHED" );
	printf( "End of page cache........\n" );
	return 1;
}

int
get_dev_list( void )
{
	ushort dev_list;
	int status;
	uchar user_id[NUM_UID];

	printf( "Get device list......\n" );
	getuser( user_id );
	status = users_get_devlist( user_id, &dev_list );
	if( status < 0 )
		printf( "\tError in function = %s\n", users_msg[ -status ] );
	printf( "Device list = %04.4X\n", dev_list );
	printf( "Get device list terminated.....\n" );
	return 1;
}

int
set_dev_list( void )
{
	uchar user_id[NUM_UID];
	uint dev_list;
	int status;

	printf( "Set device list......\n" );
	getuser( user_id );
	dev_list = getint_hex( "Input device list...", 0xffff );
	status = users_set_devlist( user_id, dev_list );
	if( status < 0 )
		printf( "\tError in function = %s\n", users_msg[ -status ] );
	printf( "Set device list terminated.....\n" );
	return 1;
}

int
erase_refresh( void )
{
	if( !select_yes_no( "Are you sure to erase refresh file \"%s\"?", refresh_file ) )
		return 1;
	fclose( frf );
	remove( refresh_file );
	printf( "Refresh file \"%s\" removed and recreated\n", refresh_file );
	open_refresh();
	return 1;
}

