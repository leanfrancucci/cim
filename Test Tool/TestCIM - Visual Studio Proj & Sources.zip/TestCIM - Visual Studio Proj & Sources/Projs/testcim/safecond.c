/*
 * safecond.c
 */

#include "safecond.h"
#include "safetst.h"
#include "internal.h"
#include "ticket.h"
#include "cmd485.h"
#include "c485defs.h"
#include "string.h"
#include <stdio.h>
#include <stdarg.h>
#include "lang.h"

#define	TEST_INTCMD_DELAY	500
static ITEST_T func_str;

static char first_pass;

static uchar conditions[2];

//#define _LOG_CONDS_
#ifdef _LOG_CONDS_
#define condprintf(x,y)	printf(x, y)
#else
#define condprintf(x,y)
#endif

void
set_tst_condition( uchar who, uchar value )
{
	conditions[who] = value;
}

void
pwr_down_end( void )
{
	sbtst_set_periph(T_VD_PLUNGER);
	sleep_user(500);
	sbtst_set_periph(T_BATTERY);
	sleep_user(1500);
	sbtst_clr_periph(T_RS485SW);
	sleep_user(500);
	sbtst_clr_periph(T_SEC_PWR);
	sleep_user(500);
	sbtst_clr_periph(T_PRI_PWR);
	sleep_user(3000);
	sbtst_clr_periph(T_BATTERY);

	conditions[GR1_PREV] = CONDITION_RESET;
	conditions[USRADD_NEED_FORMAT] = CONDITION_RESET;
}

void
check_conditions( void )
{
	ST_T stat;

	condprintf("%s","\n");
	if( conditions[USRADD_NEED_FORMAT] == CONDITION_DONE )
	{
		sbtst_clr_periph(T_RS485SW);
		sleep_user( (unsigned long)TEST_INTCMD_DELAY );
		sbtst_clr_periph(T_SEC_PWR);
		sleep_user( (unsigned long)TEST_INTCMD_DELAY );
		sbtst_set_periph(T_PRI_PWR);
		sleep_user( (unsigned long)FAIL_PWRON_DELAY );
		if( (conditions[GR1_PREV]!=CONDITION_DONE) || 
			(gr1_status( DEV_SAFEBOX, &stat ) < 0) )
		{
			condprintf( "%s\n", lang ? "ERROR: Sin Respuesta desde Safe"
		   					 : "ERROR: Safe don't response" );
			pwr_down_end();
			return;
		}

		sbtst_clr_periph(T_VD_PLUNGER);
		sleep_user( (unsigned long)CMD_TIME );

		condprintf( "%s\n", lang ? "Formateando Memoria de Usuarios" : "Users Memory Format" );
		if(	usrformat( DEV_SAFEBOX ) < 0 )
		{
			condprintf( "%s\n", lang ? "ERROR: No se pudo Formatear" 
									 : "ERROR: Unable to Format" );
			pwr_down_end();
			return;
		}
		condprintf( "%s\n", lang ? "Formato Completado" 
								 : "Format Done" );
		pwr_down_end();
	}
	else
	{
		condprintf( "%s\n", lang ? "No es necesario Formatear Memoria de Usuarios" 
								 : "Users Memory don't need Format" );
		pwr_down_end();
	}
}

static
void
end_fail_tests( void )
{
	condprintf("%s","\n");
	condprintf("%s","\n");
	condprintf( "%s\n", lang ? "Finalizando Prueba FALLIDA por favor espere ..."
		   					 : "Ending FAILED Test please wait ..." );
	condprintf("%s","\n");
	sbtst_clr_periph(T_LED0);
	sbtst_clr_periph(T_LED1);
	sbtst_clr_periph(T_LED2);
	sbtst_clr_periph(T_LED3);
	sbtst_clr_periph(T_LED4);
	sbtst_clr_periph(T_LED5);
	sbtst_clr_periph(T_LED6);
	sbtst_clr_periph(T_LED7);
	check_conditions();
	condprintf("%s","\n");
}

void
end_normal_tests( void )
{
	first_pass = 1;
	condprintf("%s","\n");
	condprintf("%s","\n");
	condprintf( "%s\n", lang ? "Finalizando Prueba SATISFACTORIA por favor espere ..."
		   					 : "Ending SUCCES Test please wait ..." );
	condprintf("%s","\n");
	sbtst_set_periph(T_LED7);
	check_conditions();
	print_ticket();
	condprintf("%s","\n");
}

void
init_func_tst( void )
{
	first_pass = 1;
	func_str.on_begin_all_tests = NULL;
	func_str.on_end_all_tests_pass = &end_normal_tests;
	func_str.on_end_all_tests_fail = &end_fail_tests;
	func_str.on_begin_one_test = NULL;
	func_str.on_end_one_test_pass = NULL;
	func_str.on_end_one_test_fail = NULL;

	set_func_tests( &func_str );
}

int
is_first_pass( void )
{
	return first_pass;
}

void
first_pass_done( void )
{
	first_pass = 0;
}
