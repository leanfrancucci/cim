/*
 * 	dffatpc.c
 * 		Data Flash fatal errors
 * 		Simulation in PC
 */

#include <stdio.h>
#include <stdlib.h>

#include "..\dffatal.h"


MUInt
dataflash_fatal( MUInt error_code )
{
	fprintf( stderr, "%s: %u\n", __FUNCTION__, error_code );
	getchar();
	exit( EXIT_FAILURE );
}

