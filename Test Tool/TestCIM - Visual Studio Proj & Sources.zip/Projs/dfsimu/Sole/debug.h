/*
 * 	debug.h
 */

#ifdef SIM_DEBUG
#define STATIC
#else
#define STATIC static
#endif
