/*
 *	hardval.h
 */

#include "mytypes.h"

typedef void (*RX_FUNCTION)( uchar byte );
typedef void (*TIMER_CBACK)( void );


/*
 * 	init_val_timer
 * 		Receives first and remaining timeouts
 * 		Returns pointer to receive routine
 */

TIMER_CBACK init_val_timer( ulong ftime, ulong btime );

/*
 * 	init_val_channel
 * 		Receives pointer to send_frame routie and returns
 * 		pointer to character receive routine
 */

RX_FUNCTION init_val_channel( void (*sf)( uchar *p, uint qty ) );


