
#include "internal.h"
#include "external.h"
#include "safetst.h"
#include "messages.h"
#include <setjmp.h>
#include <stdio.h>

jmp_buf excel_buff;
static int local_error;

#define	CONTINUE	0
#define	FATAL	1
#define	PWRON_DELAY	3000
#define	INITIAL_DELAY	10000
#define	RS485_RESP_TIME	5000
#define	BATT_CONNECT_TIME	2000
#define	PWR_FAIL_TIME	1000
#define	PRI_UNCON_FROMSEC_TIME	10000
#define	PWROFF_DELAY	2000
#define	ALARM_DELAY	200
#define	KEYS_DELAY	600
#define	UNLOCK_DELAY	1000
#define	UNLOCK_SEC_DELAY	3000
#define	PLUNGERS_DELAY	200
#define	VALSW_DELAY	1000
#define	HOST_OFF_DELAY	3000
#define	HOST_ON_DELAY	3000
#define	VDC_MIN	110
#define	VDC_MAX	125
#define	VDC_OFF_MIN	0
#define	VDC_OFF_MAX	50
#define	VBATTCHRG_MIN	134
#define	VBATTCHRG_MAX	150
#define	TLOCK_VALUE	10
#define	TUNLOCKE_VALUE	10

void
verify_pri_power_supply( void )
{
	begin_test("verify_pri_power_supply", "Primary Power Supply", "Fuente de Alimentacion Primaria");
	local_error = setjmp(excel_buff);
	if( local_error )
		printf( "... %s\n", redoing_test[ lang ] );
	sbtst_clr_periph(T_LED0);
	sbtst_clr_periph(T_LED1);
	sbtst_clr_periph(T_LED2);
	sbtst_clr_periph(T_LED3);
	sbtst_clr_periph(T_LED4);
	sbtst_clr_periph(T_LED5);
	sbtst_clr_periph(T_LED6);
	sbtst_clr_periph(T_LED7);
	sbtst_set_periph(T_BATTERY);
	sbtst_clr_periph(T_PRI_PWR);
	sbtst_clr_periph(T_SEC_PWR);
	sbtst_clr_periph(T_RS485SW );
	sbtst_clr_periph(T_VALSW);
	sleep_user( (unsigned long)INITIAL_DELAY );
	sbtst_set_periph(T_LED0);
	sbtst_set_periph(T_PRI_PWR);
	sbtst_clr_periph(T_SEC_PWR);
	sleep_user( (unsigned long)PWRON_DELAY );
	sbtst_check_privdc(VDC_MIN, VDC_MAX, FATAL, "Check Primary Power Supply", "Revisar Fuente de alimentacion Primaria");
	end_test();
}

void
verify_pri_RS485( void )
{
	begin_test("verify_pri_RS485", "Primary RS485 Interface", "Interfaz RS485 Primaria");
	local_error = setjmp(excel_buff);
	if( local_error )
		printf( "... %s\n", redoing_test[ lang ] );
	sleep_user( (unsigned long)INITIAL_DELAY );
	chk_rs485_response(RS485_RESP_TIME, FATAL, "Check Primary RS485 Interface", "Revisar Interfaz RS485 Primaria");
	end_test();
}

void
verify_memories( void )
{
	begin_test("verify_memories", " Memories Primary Access ", "Acceso a Memorias desde Primario");
	local_error = setjmp(excel_buff);
	if( local_error )
		printf( "... %s\n", redoing_test[ lang ] );
	safe_chk_grstat(GR1_MEMSTAT, BOTH_MEM_OK, FATAL, "Check Memories Primary Acces", "Revisar Acceso a Memorias desde Primario");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacaci�n de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacaci�n de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacaci�n de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacaci�n de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacaci�n de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacaci�n de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacaci�n de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacaci�n de MCU");
	end_test();
}

void
check_battchrg( void )
{
	begin_test("check_battchrg", "Battery Charger", "Cargador de Bateria");
	local_error = setjmp(excel_buff);
	if( local_error )
		printf( "... %s\n", redoing_test[ lang ] );
	safe_chk_grstat(GR1_BATTST, BATTREM, FATAL, "Check Battery can't be removed", "Revisar la Bateria no puede ser removida");
	safe_chk_grstat(GR1_PWRSYS, EXT, FATAL, "Check Power State Detection", "Revisar deteccion de estado de alimentacion");
	sbtst_clr_periph(T_BATTERY);
	sleep_user( (unsigned long)BATT_CONNECT_TIME );
	safe_chk_grstat(GR1_BATTST, BATTOK, FATAL, "Check Battery can't be connected or too low", "Revisar la Bateria no puede ser conectada o es demasiado baja");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacaci�n de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacaci�n de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacaci�n de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacaci�n de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacaci�n de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacaci�n de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacaci�n de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacaci�n de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacaci�n de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacaci�n de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacaci�n de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacaci�n de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacaci�n de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacaci�n de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacaci�n de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacaci�n de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacaci�n de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacaci�n de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacaci�n de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacaci�n de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacaci�n de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacaci�n de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacaci�n de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacaci�n de MCU");
	safe_chk_grstat(GR1_PWRSYS, EXT, FATAL, "Check Power State Detection can't be EXTERNAL state", "Revisar deteccion de estado de alimentacion no puede ser EXTERNA");
	sbtst_check_vbatt(VBATTCHRG_MIN, VBATTCHRG_MAX, FATAL, "Check Battery Charger", "Revisar Cargador de Baterias");
	end_test();
}

void
check_backup_pwr( void )
{
	begin_test("check_backup_pwr", "Power Control Switch", "Switch de control de Alimentacion");
	local_error = setjmp(excel_buff);
	if( local_error )
		printf( "... %s\n", redoing_test[ lang ] );
	sbtst_clr_periph(T_PRI_PWR);
	sleep_user( (unsigned long)PWR_FAIL_TIME );
	safe_chk_grstat(GR1_BATTST, BATTOK, FATAL, "Check Battery can't be connected", "Revisar la Bateria no puede ser conectada o es demasiado baja");
	safe_chk_grstat(GR1_PWRSYS, BACKUP, FATAL, "Check Power State Detection can't be BACKUP state", "Revisar deteccion de estado de alimentacion no puede ser BACKUP");
	sbtst_check_privdc(VDC_MIN, VDC_MAX, FATAL, "Check Power Switch MOSFET", "Revisar Switch de conmutacion MOSFET");
	sbtst_set_periph(T_PRI_PWR);
	sleep_user( (unsigned long)PWRON_DELAY );
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacacion de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacacion de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacacion de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacacion de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacacion de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacacion de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacacion de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacacion de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacacion de MCU");
	safe_chk_grstat(GR1_BATTST, BATTOK, FATAL, "Check Battery can't be connected or too low", "Revisar la Bateria no puede ser conectada o es demasiado baja");
	safe_chk_grstat(GR1_PWRSYS, EXT, FATAL, "Check Power State Detection can't be EXTERNAL state", "Revisar deteccion de estado de alimentacion no puede ser EXTERNA");
	end_test();
}

void
verify_sec_power_supply( void )
{
	begin_test("verify_sec_power_supply", "Secondary Power Supply", "Fuente de Alimentacion Secundaria");
	local_error = setjmp(excel_buff);
	if( local_error )
		printf( "... %s\n", redoing_test[ lang ] );
	sbtst_set_periph(T_LED1);
	sbtst_set_periph(T_PRI_PWR);
	sbtst_set_periph(T_SEC_PWR);
	sleep_user( (unsigned long)PWRON_DELAY );
	sbtst_check_secvdc(VDC_MIN, VDC_MAX, FATAL, "Check Secondary Power Supply", "Revisar Fuente de alimentacion Secundaria");
	safe_chk_grstat(GR1_PWRSYS, BACKUP, FATAL, "Check Forced VNET FAIL detection", "Revisar deteccion forzada de VNET_FAIL");
	sbtst_clr_periph(T_BATTERY);
	sleep_user( (unsigned long)PRI_UNCON_FROMSEC_TIME );
	sbtst_check_privdc(VDC_OFF_MIN, VDC_OFF_MAX, FATAL, "Check Forced Primary Shut Down", "Revisar Apagado Forzado de Primario");
	sbtst_clr_periph(T_PRI_PWR);
	sbtst_clr_periph(T_SEC_PWR);
	sleep_user( (unsigned long)PWROFF_DELAY );
	end_test();
}

void
periph_setup( void )
{
	begin_test("periph_setup", "Setting Up External Devices", "Configurando Dispositivos Externos");
	local_error = setjmp(excel_buff);
	if( local_error )
		printf( "... %s\n", redoing_test[ lang ] );
	sbtst_set_periph(T_LED2);
	sbtst_set_periph(T_VD_LOAD);
	sbtst_set_periph(T_MD_LOAD);
	sbtst_clr_periph(T_VD_SW);
	sbtst_clr_periph(T_MD_SW);
	sbtst_set_periph(T_VD_PLUNGER);
	sbtst_set_periph(T_MD_PLUNGER);
	sbtst_set_periph(T_KEY_SW);
	sbtst_set_periph(T_STACKER1);
	sbtst_set_periph(T_STACKER2);
	sbtst_clr_periph(T_VALSW);
	sbtst_set_periph(T_PRI_PWR);
	sleep_user( (unsigned long)INITIAL_DELAY );
	chk_rs485_response(RS485_RESP_TIME, FATAL, "Check Primary RS485 Interface", "Reveisar Interfaz RS485 Primaria");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacacion de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacacion de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacacion de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacacion de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacacion de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacacion de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacacion de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacacion de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacacion de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacacion de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacacion de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacacion de MCU");
	safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, FATAL, "Check MCU Identifier", "Revisar Identificacacion de MCU");
	safe_chk_grstat(GR1_LOCKER0, LOCKED, FATAL, "Check Validated Door Locker State Detection can't be LOCKED", "Revisar Deteccion de Estado Cerradura de la Puerta Validada no puede ser LOCKED");
	safe_chk_grstat(GR1_LOCKER1, LOCKED, FATAL, "Check Not Validated Door Locker State Detection can't be LOCKED", "Revisar Deteccion de Estado Cerradura de la Puerta No Validada no puede ser LOCKED");
	safe_chk_grstat(GR1_VD_PLUNGER, CLOSE, FATAL, "Check Validated Door Plunger State Detection can't be CLOSED", "Revisar Deteccion de Estado Sensor de la Puerta Validada no puede ser CERRADO");
	safe_chk_grstat(GR1_MD_PLUNGER, CLOSE, FATAL, "Check Not Validated Door Plunger State Detection can't be CLOSED", "Revisar Deteccion de Estado Sensor de la Puerta No Validada no puede ser CERRADO");
	safe_chk_grstat(GR1_STACKER0, INSTALLED, FATAL, "Check Validator 1 Plunger State Detection can't be INSTALLED", "Revisar Deteccion de Estado Sensor de Validador 1 no puede ser INSTALADO");
	safe_chk_grstat(GR1_STACKER1, INSTALLED, FATAL, "Check Validator 2 Plunger State Detection can't be INSTALLED", "Revisar Deteccion de Estado Sensor de Validador 2 no puede ser INSTALADO");
	end_test();
}

void
test_users( void )
{
	begin_test("test_users", "Test User's Creation", "Creacion de Usuario de Test");
	local_error = setjmp(excel_buff);
	if( local_error )
		printf( "... %s\n", redoing_test[ lang ] );
	safe_add_user(FATAL, "Check Memories Acces can't add Test User", "Revisar Acceso a Memorias no se puede agregar Usuario de Test");
	end_test();
}

void
test_vdlocker( void )
{
	begin_test("test_vdlocker", "Validated Door Locker", "Cerradura Puerta Validada");
	local_error = setjmp(excel_buff);
	if( local_error )
		printf( "... %s\n", redoing_test[ lang ] );
	sbtst_set_periph(T_LED3);
	safe_tlock_cfg(TLOCK_VALUE);
	safe_tunlocke_cfg(TUNLOCKE_VALUE);
	safe_unlock(DEV_LOCKER0);
	safe_chk_grstat(GR1_LOCKER0, UNLOCKING, FATAL, "Check Key Switch Detection ", "Revisar deteccion de KEY SWITCH");
	sbtst_check_periph(T_VD_CURR, NOT_DRIVED, FATAL, "Check Locker Driver Circuit may be short-circuited", "Revisar Accionamiento de Cerradura puede estar cortocircuitado");
	sbtst_clr_periph(T_KEY_SW);
	sleep_user( (unsigned long)KEYS_DELAY );
	sbtst_set_periph(T_KEY_SW);
	sleep_user( (unsigned long)UNLOCK_DELAY );
	sbtst_check_periph(T_VD_CURR, DRIVED, FATAL, "Check Key Switch Detection or Check Locker Driver Circuit may be open and can't be feeded", "Revisar deteccion de KEY SWITCH or Accionamiento de Cerradura puede estar cortocircuitado puede estar abierto y no puede alimentarse");
	safe_chk_grstat(GR1_LOCKER0, UNLOCKING, FATAL, "Check Key Switch Detection or Check Locker Driver Circuit may be open and can't be feeded", "Revisar deteccion de KEY SWITCH or Accionamiento de Cerradura puede estar cortocircuitado puede estar abierto y no puede alimentarse");
	sbtst_set_periph(T_VD_SW);
	sleep_user( (unsigned long)UNLOCK_DELAY );
	safe_chk_grstat(GR1_LOCKER0, UNLOCKED, FATAL, "Check Locker State Detection", "Revisar Deteccion de Estado de la Cerradura");
	safe_chk_grstat(GR1_LOCKER0, LOCKING, FATAL, "Check Locker State Detection", "Revisar Deteccion de Estado de la Cerradura");
	sbtst_check_periph(T_VD_CURR, NOT_DRIVED, FATAL, "Check Locker Driver Circuit may be short-circuited", "Revisar Accionamiento de Cerradura puede estar cortocircuitado");
	sbtst_clr_periph(T_VD_SW);
	sleep_user( (unsigned long)UNLOCK_DELAY );
	safe_chk_grstat(GR1_LOCKER0, LOCKED, FATAL, "Check Locker State Detection", "Revisar Deteccion de Estado de la Cerradura");
	end_test();
}

void
test_mdlocker( void )
{
	begin_test("test_mdlocker", "Not Validated Door Locker", "Cerradura Puerta No Validada");
	local_error = setjmp(excel_buff);
	if( local_error )
		printf( "... %s\n", redoing_test[ lang ] );
	safe_tlock_cfg(TLOCK_VALUE);
	safe_tunlocke_cfg(TUNLOCKE_VALUE);
	safe_unlock(DEV_LOCKER1);
	safe_chk_grstat(GR1_LOCKER1, UNLOCKING, FATAL, "Check Key Switch Detection ", "Revisar deteccion de KEY SWITCH");
	sbtst_check_periph(T_MD_CURR, NOT_DRIVED, FATAL, "Check Locker Driver Circuit may be short-circuited", "Revisar Accionamiento de Cerradura puede estar cortocircuitado");
	sbtst_clr_periph(T_KEY_SW);
	sleep_user( (unsigned long)KEYS_DELAY );
	sbtst_set_periph(T_KEY_SW);
	sleep_user( (unsigned long)UNLOCK_DELAY );
	sbtst_check_periph(T_MD_CURR, DRIVED, FATAL, "Check Key Switch Detection or Check Locker Driver Circuit may be open and can't be feeded", "Revisar deteccion de KEY SWITCH or Accionamiento de Cerradura puede estar cortocircuitado puede estar abierto y no puede alimentarse");
	safe_chk_grstat(GR1_LOCKER1, UNLOCKING, FATAL, "Check Key Switch Detection or Check Locker Driver Circuit may be open and can't be feeded", "Revisar deteccion de KEY SWITCH or Accionamiento de Cerradura puede estar cortocircuitado puede estar abierto y no puede alimentarse");
	sbtst_clr_periph(T_MD_PLUNGER);
	sleep_user( (unsigned long)UNLOCK_DELAY );
	safe_chk_grstat(GR1_LOCKER1, UNLOCKED, FATAL, "Check Not Validated Door Plunger State Detection", "Revisar Deteccion de Estado Sensor de la Puerta No Validada");
	safe_chk_grstat(GR1_LOCKER1, UNLOCKED, FATAL, "Check Not Validated Door Plunger State Detection", "Revisar Deteccion de Estado Sensor de la Puerta No Validada");
	safe_chk_grstat(GR1_LOCKER1, LOCKING, FATAL, "Check Not Validated Door Plunger State Detection", "Revisar Deteccion de Estado Sensor de la Puerta No Validada");
	sbtst_check_periph(T_MD_CURR, NOT_DRIVED, FATAL, "Check Locker Driver Circuit may be short-circuited", "Revisar Accionamiento de Cerradura puede estar cortocircuitado");
	sbtst_set_periph(T_MD_PLUNGER);
	sleep_user( (unsigned long)UNLOCK_DELAY );
	safe_chk_grstat(GR1_LOCKER1, LOCKING, FATAL, "Check Not Validated Door Plunger State Detection", "Revisar Deteccion de Estado Sensor de la Puerta No Validada");
	safe_chk_grstat(GR1_LOCKER1, LOCKED, FATAL, "Check Not Validated Door Plunger State Detection", "Revisar Deteccion de Estado Sensor de la Puerta No Validada");
	end_test();
}

void
test_plungers( void )
{
	begin_test("test_plungers", "Plungers", "Sensores de Puerta");
	local_error = setjmp(excel_buff);
	if( local_error )
		printf( "... %s\n", redoing_test[ lang ] );
	sbtst_clr_periph(T_VD_PLUNGER);
	sleep_user( (unsigned long)PLUNGERS_DELAY );
	safe_chk_grstat(GR1_VD_PLUNGER, OPEN, FATAL, "Check Validated Door Plunger State Detection can't be OPENED", "Revisar Deteccion de Estado Sensor de la Puerta Validada no puede ser ABIERTO");
	sbtst_set_periph(T_VD_PLUNGER);
	sleep_user( (unsigned long)PLUNGERS_DELAY );
	safe_chk_grstat(GR1_VD_PLUNGER, CLOSE, FATAL, "Check Validated Door Plunger State Detection can't be CLOSED", "Revisar Deteccion de Estado Sensor de la Puerta Validada no puede ser CERRADO");
	sbtst_clr_periph(T_MD_PLUNGER);
	sleep_user( (unsigned long)PLUNGERS_DELAY );
	safe_chk_grstat(GR1_MD_PLUNGER, CLOSE, FATAL, "Check Not Validated Door Plunger State Detection can't be CLOSED", "Revisar Deteccion de Estado Sensor de la Puerta No Validada no puede ser CERRADO");
	safe_chk_grstat(GR1_MD_PLUNGER, CLOSE, FATAL, "Check Not Validated Door Plunger State Detection can't be CLOSED", "Revisar Deteccion de Estado Sensor de la Puerta No Validada no puede ser CERRADO");
	safe_chk_grstat(GR1_MD_PLUNGER, OPEN, FATAL, "Check Not Validated Door Plunger State Detection can't be OPENED", "Revisar Deteccion de Estado Sensor de la Puerta No Validada no puede ser ABIERTO");
	sbtst_set_periph(T_MD_PLUNGER);
	sleep_user( (unsigned long)PLUNGERS_DELAY );
	safe_chk_grstat(GR1_MD_PLUNGER, OPEN, FATAL, "Check Not Validated Door Plunger State Detection can't be OPENED", "Revisar Deteccion de Estado Sensor de la Puerta No Validada no puede ser ABIERTO");
	safe_chk_grstat(GR1_MD_PLUNGER, CLOSE, FATAL, "Check Not Validated Door Plunger State Detection can't be CLOSED", "Revisar Deteccion de Estado Sensor de la Puerta No Validada no puede ser CERRADO");
	safe_chk_grstat(GR1_MD_PLUNGER, CLOSE, FATAL, "Check Not Validated Door Plunger State Detection can't be CLOSED", "Revisar Deteccion de Estado Sensor de la Puerta No Validada no puede ser CERRADO");
	sbtst_clr_periph(T_STACKER1);
	sleep_user( (unsigned long)PLUNGERS_DELAY );
	safe_chk_grstat(GR1_STACKER0, REMOVED, FATAL, "Check Validator 1 Plunger State Detection can't be REMOVED", "Revisar Deteccion de Estado Sensor de Validador 1 no puede ser REMOVIDO");
	sbtst_set_periph(T_STACKER1);
	sleep_user( (unsigned long)PLUNGERS_DELAY );
	safe_chk_grstat(GR1_STACKER0, INSTALLED, FATAL, "Check Validator 1 Plunger State Detection can't be INSTALLED", "Revisar Deteccion de Estado Sensor de Validador 1 no puede ser INSTALADO");
	sbtst_clr_periph(T_STACKER2);
	sleep_user( (unsigned long)PLUNGERS_DELAY );
	safe_chk_grstat(GR1_STACKER1, REMOVED, FATAL, "Check Validator 2 Plunger State Detection can't be REMOVED", "Revisar Deteccion de Estado Sensor de Validador 2 no puede ser REMOVIDO");
	sbtst_set_periph(T_STACKER2);
	sleep_user( (unsigned long)PLUNGERS_DELAY );
	safe_chk_grstat(GR1_STACKER1, INSTALLED, FATAL, "Check Validator 2 Plunger State Detection can't be INSTALLED", "Revisar Deteccion de Estado Sensor de Validador 2 no puede ser INSTALADO");
	end_test();
}

void
test_validators( void )
{
	begin_test("test_validators", "Validators", "Validadores");
	local_error = setjmp(excel_buff);
	if( local_error )
		printf( "... %s\n", redoing_test[ lang ] );
	sbtst_set_periph(T_LED4);
	safe_valtest(DEV_VAL0, FATAL, "Check Validator 1 Comunication Interface", "Revisar Interfaz Validador 1");
	sbtst_set_periph(T_VALSW);
	sleep_user( (unsigned long)VALSW_DELAY );
	safe_valtest(DEV_VAL1, FATAL, "Check Validator 2 Comunication Interface", "Revisar Interfaz Validador 2");
	sbtst_clr_periph(T_VALSW);
	end_test();
}

void
test_alarms( void )
{
	begin_test("test_alarms", "Alarms", "Alarmas");
	local_error = setjmp(excel_buff);
	if( local_error )
		printf( "... %s\n", redoing_test[ lang ] );
	sbtst_check_periph(T_DURESS_NC, ACTIVATED, FATAL, "Check Duress Alarm NC can't be Activated", "Revisar Contacto NC Alarma Silenciosa");
	safe_set_alarm(DEV_ALARM1, AL_ENABLE);
	sleep_user( (unsigned long)ALARM_DELAY );
	sbtst_check_periph(T_DURESS_NO, ACTIVATED, FATAL, "Check Duress Alarm NO can't be Activated", "Revisar Contacto NO Alarma Silenciosa");
	safe_set_alarm(DEV_ALARM1, AL_DISABLE);
	sleep_user( (unsigned long)ALARM_DELAY );
	sbtst_check_periph(T_DURESS_NC, ACTIVATED, FATAL, "Check Duress Alarm NC can't be Activated", "Revisar Contacto NC Alarma Silenciosa");
	sbtst_check_periph(T_BURGLAR_NC, ACTIVATED, FATAL, "Check Burglar Alarm NC can't be Activated", "Revisar Contacto NC Alarma Sonora");
	safe_set_alarm(DEV_ALARM0, AL_ENABLE);
	sleep_user( (unsigned long)ALARM_DELAY );
	sbtst_check_periph(T_BURGLAR_NO, ACTIVATED, FATAL, "Check Burglar Alarm NO can't be Activated", "Revisar Contacto NO Alarma Sonora");
	safe_set_alarm(DEV_ALARM0, AL_DISABLE);
	sleep_user( (unsigned long)ALARM_DELAY );
	sbtst_check_periph(T_BURGLAR_NC, ACTIVATED, FATAL, "Check Burglar Alarm NC can't be Activated", "Revisar Contacto NC Alarma Sonora");
	end_test();
}

void
test_host_pwr( void )
{
	begin_test("test_host_pwr", "CT8016 Power Control", "Control de Alimentacion CT8016");
	local_error = setjmp(excel_buff);
	if( local_error )
		printf( "... %s\n", redoing_test[ lang ] );
	sleep_user( (unsigned long)HOST_OFF_DELAY );
	sbtst_check_privdc(VDC_MIN, VDC_MAX, FATAL, "Check CT8016 Power Control can't be powered on", "Revisar Control de Alimentacion CT8016 no puede ser encendido");
	safe_set_hostpwr(HOST_OFF);
	sleep_user( (unsigned long)HOST_OFF_DELAY );
	sbtst_check_privdc(VDC_OFF_MIN, VDC_OFF_MAX, FATAL, "Check CT8016 Power Control can't be powered off", "Revisar Control de Alimentacion CT8016 no puede ser apagado");
	safe_set_hostpwr(HOST_ON);
	sleep_user( (unsigned long)HOST_ON_DELAY );
	sbtst_check_privdc(VDC_MIN, VDC_MAX, FATAL, "Check CT8016 Power Control can't be powered on", "Revisar Control de Alimentacion CT8016 no puede ser encendido");
	end_test();
}

void
verify_sec_RS485( void )
{
	begin_test("verify_sec_RS485", "Secondary RS485 Interface", "Interfaz RS485 Secundaria");
	local_error = setjmp(excel_buff);
	if( local_error )
		printf( "... %s\n", redoing_test[ lang ] );
	sbtst_set_periph(T_LED5);
	sbtst_set_periph(T_RS485SW);
	sbtst_clr_periph(T_PRI_PWR);
	sbtst_set_periph(T_SEC_PWR);
	sleep_user( (unsigned long)PWROFF_DELAY );
	chk_rs485_response(RS485_RESP_TIME, FATAL, "Check Secondary RS485 Interface", "Revisar Interfaz RS485 Secundaria");
	end_test();
}

void
verify_sec_memory( void )
{
	begin_test("verify_sec_memory", "Backup Memory Secondary Access", "Acceso Secundario a Memoria de Backup");
	local_error = setjmp(excel_buff);
	if( local_error )
		printf( "... %s\n", redoing_test[ lang ] );
	safe_chk_grstat(GR1_MEMSTAT, BOTH_MEM_OK, FATAL, "Check Backup Memory Secondary Access", "Revisar Acceso Secundario a Memoria de Backup");
	end_test();
}

void
test_vdlocker_sec( void )
{
	begin_test("test_vdlocker_sec", "Validated Door Locker Secondary Access", "Acceso Secundario a Cerradura Puerta Validada");
	local_error = setjmp(excel_buff);
	if( local_error )
		printf( "... %s\n", redoing_test[ lang ] );
	sbtst_set_periph(T_LED6);
	sbtst_check_periph(T_VD_CURR, NOT_DRIVED, FATAL, "Check Secondary Locker Driver Circuit may be short-circuited", "Revisar Acceso Secundario a Cerradura Puerta Validada puede estar cortocircuitada");
	safe_unlock(DEV_LOCKER0);
	sleep_user( (unsigned long)UNLOCK_DELAY );
	sbtst_check_periph(T_VD_CURR, DRIVED, FATAL, "Check Secondary Locker Driver Circuit can't be feeded", "Revisar Acceso Secundario a Cerradura Puerta Validada no puede ser alimentada");
	sleep_user( (unsigned long)UNLOCK_SEC_DELAY );
	sbtst_clr_periph(T_SEC_PWR);
	sleep_user( (unsigned long)PWROFF_DELAY );
	end_test();
}

int
do_tests( void )
{
	init_all_tests();
	verify_pri_power_supply();
	verify_pri_RS485();
	verify_memories();
	check_battchrg();
	check_backup_pwr();
	verify_sec_power_supply();
	periph_setup();
	test_users();
	test_vdlocker();
	test_mdlocker();
	test_plungers();
	test_validators();
	test_alarms();
	test_host_pwr();
	verify_sec_RS485();
	verify_sec_memory();
	test_vdlocker_sec();
	return(error_status());
}



