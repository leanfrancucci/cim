/*
 * rs19.c
 *
 * 		S19 manipulation routines file
 */

#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define DEBUG

#ifdef DEBUG
#include <time.h>
#endif

#include "hc08sprg.h"
#include "imfiles.h"
#include "imcmd.h"

#define MAX_BUFF_SIZE		512
#define MAX_ADDRESS_LEN		8

#define ADDR_LEN_16bit		4
#define ADDR_LEN_24bit		6
#define ADDR_LEN_32bit		8

#define get_percen()		(100*written/TOTAL_IMAGE)
#define get_s19percen()		(100*(i-START_REPRO_AREA)/(END_REPRO_AREA-START_REPRO_AREA))
	 

#define LOG_FILE 			"reclog"
#define BIN_FILE 			"binlog"
#define S08IMDWR			"s08imdwr"



/* 
 * Bootloader commands
 */

#define WR_DATA				'W'
#define RD_DATA				'R'
#define IDENT				'I'
#define QUIT				'Q'
#define ERASE				'E'
#define ACK					0xFC

enum
{
	IDLE_IM, IN_ACC_IM, NUM_STATES_IM
};

static char line_buff[ MAX_BUFF_SIZE ];
static char afmt[ MAX_ADDRESS_LEN ];

static MEM_POS_T image, im;

#ifdef DEBUG
static FILE *flog, *fim, *fbin;
static time_t t;
#endif

static
int
add_quit_cmd( void )
{
	set_byte( QUIT );
	return 0;
}

static
int
add_term_rec( void )
{
	set_str_s19( "S9030000FC" );
	return 0;
}

static
unsigned char
calc_s19_chk( long a, int len )
{
	unsigned short sum;
	long addr;
	int i;
	unsigned char d;

	sum = ( len + 3 );
	sum += ( a >> 8 ) & 0xFF;
	sum += a & 0xFF;

	for( i = len, addr = a; i--; ++addr )
	{
		rdata_imfiles( &d, addr );
		sum += d;
	}

	sum = ~sum;
	
	return (unsigned char)sum;
}

/*
 * erase_blk:
 * 	Prepare a command ERASE to erase single block
 * 	around given address.
 */
static
int 
erase_blk( long a )
{
#ifdef DEBUG
	fprintf( flog, "\nerase_blk: 0x%04lX\n", a );
#endif

	if( a >= END_REPRO_AREA + 1 )
		return -1;

	/* issue command */
	set_byte( ERASE );
	
	/* and parameter */
	set_word( a );

	return 0;
}

/*
 * prg_blk:
 * 	Prepare a command WRITE to program single block
 */
static
int 
prg_blk( long a, int len )
{
	long addr;
	int i;
	unsigned char d;
	
	if( len < 0 || len >= 0x100 || a >= END_REPRO_AREA + 1 ) 
		return -1;

	/* issue command */
	set_byte( WR_DATA );

	/* and parameters */
	set_word( a );
	set_byte( len );

	/* data */
#ifdef DEBUG
	fprintf( flog, "\nprg_blk: 0x%04lX-0x%04lX\n", a, a + len - 1 );
	fprintf( flog, "block len: 0x%02X | ", len );
#endif

	for( i = len, addr = a; i--; ++addr )
	{
		rdata_imfiles( &d, addr );
		set_byte( d );
#ifdef DEBUG
		fprintf( flog, "%02x", d );
		fputc( d, fbin );
#endif
	}

	return 0;
}

/*
 * prepare_rec:
 * 	Prepare a 's1' record.
 */
static
int 
prepare_rec( long a, int len )
{
	long addr;
	int i;
	unsigned char d;
	
	if( len < 0 || len >= 0x100 || a >= END_REPRO_AREA + 1 ) 
		return -1;

	/* issue "s1" register */
	set_str_s19( "S1" );

	/* and parameters */
	set_byte_s19( len + 3 );
	set_word_s19( a );

	/* data */
#ifdef DEBUG
	fprintf( flog, "\nrecord: 0x%04lX-0x%04lX\n", a, a + len - 1 );
	fprintf( flog, "record len: 0x%02X | ", len );
#endif

	for( i = len, addr = a; i--; ++addr )
	{
		rdata_imfiles( &d, addr );
		set_byte_s19( d );
#ifdef DEBUG
		fprintf( flog, "%02x", d );
#endif
	}

	set_byte_s19( calc_s19_chk( a, len ) );

	set_str_s19( "\n" );

	return 0;
}

/*
 * find_eaddr:
 * 	Determine end address of user code section.
 */
static
long
find_eaddr( long start )
{
	unsigned char flag;
	long end;
	
	for( end = END_USR_CODE_SECT; end > start; --end )
	{
		if( rflag_imfiles( &flag, end ) == OK_IMAGE && flag == EMPTY )
			continue;
		break;
	}
	return end;
}
	
/*
 * find_saddr:
 * 	Determine start address of user code section.
 */
static
long
find_saddr( void )
{
	unsigned char flag;
	long start;
	
	for( start = START_USR_CODE_SECT; start < END_USR_CODE_SECT; ++start )
	{
		if( rflag_imfiles( &flag, start ) == OK_IMAGE && flag == EMPTY )
			continue;
		break;
	}	
	return start;
}

/*
 * umin:
 * 	Helper compare of unsigned 
 */
static 
long
umin( long a, long b )
{
	return a < b ? a : b;
}

/*
 * process_record:
 */
static 
int
process_record( unsigned char addr_len, unsigned char line, char *pc )
{
	unsigned short len, sum, b;
	int u;
	long addr = 0;
#ifdef DEBUG 
	char *p;
#endif
	
	/* prepare len & addr scan format */
	sprintf( afmt, "%%2x%%%dx", addr_len );

	/* scan len & address */
	if( sscanf( pc, afmt, &len, &addr ) != 2 || len >= 0x100 )
	{
		fprintf( stderr, "S-record parse error at line %d\n", line );
		return -1;
	}

	/* verify upper boundary of flash memory */
	if( addr >= 0x10000 )
	{
		fprintf( stderr, "Address out of range at line %d\n", line );
		return -1;
	}

	/* skip len & address */
	pc += addr_len + 2;

	/* init checksum with address & length field */
	for( sum = len, u = 0; u < 4; u++ )
		sum += ( addr >> ( u*8 ) ) & 0xff;

	/* length & address processed in record */
	len -= addr_len/2 + 1;
	
#ifdef DEBUG 
	fprintf( flog, "|rec nr: %03i | Length : %03d | Address : %04X|\n", line - 1, len, addr );
#endif

#ifdef DEBUG
	fprintf( flog, "|D : " );
	for( p = pc, u = len*2; u--; p++ )
		fprintf( flog, "%c", *p );
	fprintf( flog, "|\n\n" );
#endif

	/* scan data field and store onto binary image */
	for( u = 0; u < len; u++ )
	{
		if( sscanf( pc, "%2x", &b ) != 1 || b >= 0x100 )
		{
			fprintf( stderr, "S-record data parse error at line %d\n", line );
			return -1;
		}
		
		/* next data byte */
		pc += 2;

		/* store data byte and mark with a flag this location */
		image.d = b;
		image.f = USER_CODE;
		wloc_imfiles( &image, addr + u );
		
		sum += b;
	}

	/* calculate and verify checksum */
	if( sscanf( pc, "%2x", &b ) != 1 || b >= 0x100 || ( ( sum + b ) & 0xff ) != 0xff )
	{
		fprintf( stderr, "S-record checksum error at line %d\n", line );
		return -1;
	}

	return 0;
}

/*
 * read_s19:
 * 	Read .s19 file and store data into 	memory image
 */
int
read_s19( char *fn )
{
	FILE *f;
	char c, *pc;
	unsigned alen;
	int line = 0, terminate = 0;

	if( (f = *fn ? fopen( fn, "rb" ) : stdin ) == NULL )
	{
		fprintf( stderr, "Can't open input file %s\n", fn );
		return -1;
	}

#ifdef DEBUG
	time( &t );
	
	if( ( flog = fopen( LOG_FILE, "w+b" ) ) == NULL )
	{
		fprintf( stderr, "Can't open input file %s\n", LOG_FILE );
		return -1;
	}
	fprintf( flog, "Records from s19 file - %s\n\n", ctime( &t ) );

	if( ( fbin = fopen( BIN_FILE, "w+b" ) ) == NULL )
	{
		fprintf( stderr, "Can't open input file %s\n", BIN_FILE );
		return -1;
	}
#endif
	
	/* Initialize image */
	init_imfiles();

	while( !terminate && ( pc = fgets( line_buff, sizeof( line_buff ), f ) ) != NULL )
	{
		line++;

		/* S-records only */
		if( *pc++ != 'S' )
			continue;

		/* record type */
		switch( c = *pc++ )
		{
			case '0':		/* S0 is skipped */
				continue;
			case '1':		/* S1 is accepted */
				alen = ADDR_LEN_16bit;
				break;
			case '2':		/* S2 is accepted */
				alen = ADDR_LEN_24bit;
				break;
			case '3':		/* S3 is accepted */
				alen = ADDR_LEN_32bit;
				break;
			case '9':		/* S9 terminates */
			case '8':		/* S8 terminates */
			case '7':		/* S7 terminates */
				terminate = 1;
				continue;
			default:		/* others are reported and skipped */
				fprintf( stderr, "Skipping S%c record at line %d", c, line );
				continue;
		}
		if( process_record( alen, line, pc ) < 0 )
			return -1;
	}

	fclose( f );
	return 0;
}

/*
 * setup_vect_tbl:
 * 
 * 	Masquerade vector table (work on memory image)
 * 	the trick is to move any vector values from S19 file to 
 * 	special jump table located at 'RELOC_VECT_TBL'.
 */
int
setup_vect_tbl( void )
{
	long dest, src;
	unsigned char data, flag0, flag1;
	int i, any_hit = 0;

	/* start of jump table */
	dest = RELOC_VECT_TBL_ADDR;

	/* and jump-table next */
	for( src = VECT_TBL_ADDR; src < END_VECT_TBL_ADDR; src += 2 )
	{
		rdata_imfiles( &data, src );
		wdata_imfiles( &data, dest++ );
		rdata_imfiles( &data, src + 1 );
		wdata_imfiles( &data, dest++ );
		
		/* is the vector valid ? */
		rflag_imfiles( &flag0, src );
		rflag_imfiles( &flag1, src + 1 );
		if( flag0 != EMPTY && flag1 != EMPTY )
			any_hit = 1;

		/* original vector (from s19 image) is no longer valid */
		flag0 = flag1 = EMPTY;
		wflag_imfiles( &flag0, src );
		wflag_imfiles( &flag1, src + 1 );
	}
	/*
	 * write the whole system area, but only if at least one
	 * vector was valid in the S19 
	 */
	if( any_hit )
		for( flag0 = SYSTEM_CODE, i = 0; i < dest - RELOC_VECT_TBL_ADDR; i++ )
			wflag_imfiles( &flag0, RELOC_VECT_TBL_ADDR + i );
	else
		fprintf( stderr, "The image s19 has not allocated any vector\n" );
	
	return 0;
}

/*
 * check_image:
 * 	Check if code goes to valid memory only.
 */
int	
check_image( void )
{
	long addr;
	unsigned char flag;
	
	/* verify valid memory */
	
	for( addr = 0; addr < END_REPRO_AREA + 1; addr++ )
		if( ( rflag_imfiles( &flag, addr ) == OK_IMAGE ) && flag == USER_CODE )
			if( !( ( addr >=  START_REPRO_AREA ) && ( addr < END_REPRO_AREA ) ) )
			{
				/* location at address a won't fit any memory block! */
				fprintf( stderr, "\nS19 image will not fit into available memory (at address 0x%04X)!\n", addr );
				return -1;
			}
	
	/* verify memory protected */

	for( addr = START_BOOT_CODE; addr < END_REPRO_AREA + 1; addr++ )
		if( ( rflag_imfiles( &flag, addr ) == OK_IMAGE ) && flag == USER_CODE )
		{
			fprintf( stderr, "\nS19 image is allocated onto protected memory sector (at address 0x%04X)!\n", addr );
			return -1;
		}
	
	/* verify user code checksum sector */

	if( ( rflag_imfiles( &flag, START_CHK_CODE ) == OK_IMAGE ) && flag == USER_CODE || 
		( rflag_imfiles( &flag, START_CHK_CODE + 1 ) == OK_IMAGE ) && flag == USER_CODE )
	{
		fprintf( stderr, "\nS19 image is overlaped with ckecksum code sector\n" );
		return -1;
	}

	/* verify user code within first page */

	for( addr = START_FIRST_PAGE_ADDR; addr < END_FIRST_PAGE_ADDR; addr++ )
		if( ( rflag_imfiles( &flag, addr ) == OK_IMAGE ) && flag == USER_CODE )
		{
			fprintf( stderr, "\nS19 image is allocated onto first page and will not download (at address 0x%04X)!\n", addr );
		}

	/* verify user code within high page registers */

	for( addr = START_HIGH_PAGE_ADDR; addr < END_HIGH_PAGE_ADDR; addr++ )
		if( ( rflag_imfiles( &flag, addr ) == OK_IMAGE ) && flag == USER_CODE )
		{
			fprintf( stderr, "\nS19 image is allocated onto high page registers zone and will not download (at address 0x%04X)!\n", addr );
		}

	return 0;
}

/*
 * blank_image:
 * 	Find end of user code and then blank the locations
 * 	from end of user code up to end user code section.
 */
int
blank_image( void )
{
	long addr;
	unsigned char flag;

	image.f = USER_CODE;
	image.d = 0x0;

	for( addr = START_USR_CODE_SECT; addr < END_USR_CODE_SECT; addr++ )
	{
		if( ( rflag_imfiles( &flag, addr ) == OK_IMAGE ) && flag != EMPTY )
			continue;
		wloc_imfiles( &image, addr );
	}

#if 0
	image.f = USER_CODE;
	image.d = 0xFF;

	for( addr = START_CHK_CODE + 2; addr < RELOC_VECT_TBL_ADDR; addr++ )
		wloc_imfiles( &image, addr );
#endif
	return 0;
}

/*
 * checksum_usrcode:
 * 	Get checksum of whole user code section and
 * 	if success then store it from START_CHK_CODE address
 * 	MSB first.
 */
int
checksum_usrcode( void )
{
	unsigned short check;
	unsigned char data;
	long addr;

	for( check = 0, addr = START_USR_CODE_SECT; addr < END_USR_CODE_SECT; ++addr )
	{
		rdata_imfiles( &data, addr );
		check += data;
	}	
	check = ~check;
	
	image.f = USER_CODE;
	image.d = ( check >> 8 ) & 0xFF;
	wloc_imfiles( &image, START_CHK_CODE );
	
	image.d = check & 0xFF;
	wloc_imfiles( &image, START_CHK_CODE + 1 );

#ifdef DEBUG
	rdata_imfiles( &data, START_CHK_CODE );
	check = (data << 8 ) & 0xFF00;

	rdata_imfiles( &data, START_CHK_CODE + 1 );
	check |= (data & 0x00FF);
	
	fprintf( flog, "Code checksum : 0x%04X\n", check );
	printf( "User code checksum : 0x%04X\n", check );
#endif
	
	return 0;
}

/*
 * prepare_prog_area:
 * 	Prepare all commands to send to bootloader
 */
int
prepare_prog_area( void )
{
	long i, er, wr, er_next, wr_end, wr_next, addr, s;
	long wr_one, written = 0;
	unsigned char flag;

	if( init_imcmd() < 0 )
		return -1;
	
#ifdef DEBUG
	addr = find_eaddr( ( s = find_saddr() ) );
	fprintf( flog, "User code area: 0x%04lX-0x%04lX\n", s , addr );
	fprintf( flog, "Programmed area: 0x%04X\n", TOTAL_IMAGE );

	printf( "User code boundaries: 0x%04lX-0x%04lX\n", s , addr );
	printf( "Programmed area boundaries: 0x%04X-0x%04X = 0x%04X\n\n",START_USR_CODE_SECT, START_BOOT_CODE - 1, TOTAL_IMAGE );
#endif

	/*
	 * take start address as it is, but do further 
	 * steps to erase block boundaries 
	 */
	for( er = START_USR_CODE_SECT; er < START_BOOT_CODE; er = er_next )
	{
		/* start of next erase block */
		er_next = ( er + ERASE_BLK_SIZE	) & ~( ERASE_BLK_SIZE - 1 );

		if( er_next == 0xfc00 )
			er_next = 0xfc00;
		
		/* anything to program in this erase block ? */
		wr = wr_end = er;
		for( i = er; i < er_next; i++ )
			if( rflag_imfiles( &flag, i ) == OK_IMAGE && flag != EMPTY ) /* valid byte */
			{
				if( rflag_imfiles( &flag, wr ) == OK_IMAGE && flag == EMPTY )
					wr = i;
				wr_end = i + 1;
			}

		/* never pass after end */
		if( wr_end > START_BOOT_CODE )
			wr_end = START_BOOT_CODE;

		/*
		 * 'wr' is now pointing to first valid byte (within current erase block)
		 * 'wr_end' is now pointing after last valid byte (within current erase block)
		 */
		if( wr < wr_end )
		{
			printf( "\rMemory programming: E 0x%04X %d%", wr, get_percen() );
			fflush( stdout ); 
#ifdef DEBUG
			fprintf( flog, "\n" );
#endif
			/* use the first valid-byte address */
			if( erase_blk( wr ) < 0 )
			{
				printf( "\n" );
				fprintf( stderr, "Can't erase block at address 0x%04X\n", wr );
				return -1;
			}

			for(/* original wr */; wr < wr_end; wr = wr_next )
			{
				/* start of next write block */
				wr_next = ( wr + WRITE_BLK_SIZE ) & ~( WRITE_BLK_SIZE - 1 );
				
#ifdef DEBUG
				fprintf( flog, "\n" );
#endif

				wr_one = umin( wr_end, wr_next ) - wr;
				if( prg_blk( wr, wr_one ) < 0 ) 
				{
					printf( "\n" );
					fprintf( stderr, "Can't program block at address 0x%04X\n", wr );
					return -1;
				}

				/* 
				 * the percentage-counting algorithm is not perfect, in some
				 * cases there might be more than 100% achieved (if S19 file 
				 * has holes within erblks = rare case)
				 */
				if( ( written += wr_one ) > TOTAL_IMAGE )
					written = TOTAL_IMAGE;

				printf( "\rMemory programming: W 0x%04lX %d%", wr, get_percen() );
				fflush( stdout );
			}
		}
	}

#ifdef DEBUG
	fprintf( flog, "\n\nquit\n" );
#endif
	printf( "\n\n" );
	add_quit_cmd();
	close_imcmd();
		
	return 0;
}

/*
 * read_s19_boot:
 * 	Read .s19 boot file and store data into memory image
 */
int
read_s19_boot( char *fn )
{
	FILE *f;
	char c, *pc;
	unsigned alen;
	int line = 0, terminate = 0;

	if( ( f = *fn ? fopen( fn, "rb" ) : stdin ) == NULL )
	{
		fprintf( stderr, "Can't open input file %s\n", fn );
		return -1;
	}

#ifdef DEBUG
	fprintf( flog, "\n\nRecords from s19 boot file\n\n" );
#endif
	
	while( !terminate && ( pc = fgets( line_buff, sizeof( line_buff ), f ) ) != NULL )
	{
		line++;

		/* S-records only */
		if( *pc++ != 'S' )
			continue;

		/* record type */
		switch( c = *pc++ )
		{
			case '0':		/* S0 is skipped */
				continue;
			case '1':		/* S1 is accepted */
				alen = ADDR_LEN_16bit;
				break;
			case '2':		/* S2 is accepted */
				alen = ADDR_LEN_24bit;
				break;
			case '3':		/* S3 is accepted */
				alen = ADDR_LEN_32bit;
				break;
			case '9':		/* S9 terminates */
			case '8':		/* S8 terminates */
			case '7':		/* S7 terminates */
				terminate = 1;
				continue;
			default:		/* others are reported and skipped */
				fprintf( stderr, "Skipping S%c record at line %d", c, line );
				continue;
		}
		if( process_record( alen, line, pc ) < 0 )
			return -1;
	}

	fclose( f );
	return 0;
}

/*
 * do_imdwr:
 *
 * 		Creates s08imdwr file.
 */
int
do_imcmddwr( void )
{
	FILE *fs08imdwr, *fimcmd;
	int data;
	unsigned short check;

	if( ( fs08imdwr = fopen( S08IMDWR, "w+b" ) ) == NULL )
	{
		fprintf( stderr, "Can't open image and command file s08imdwr\n" );
		return -1;
	}

	if( ( fimcmd = fopen( "hcs08im", "r+b" ) ) == NULL )
	{
		fprintf( stderr, "Can't open image and command file hcs08im\n" );
		fclose( fs08imdwr );
		return -1;
	}

	fseek( fs08imdwr, 0, SEEK_SET );
	fseek( fimcmd, 0, SEEK_SET );

	check = data = 0x0;
	fputc( (unsigned char)data, fs08imdwr );
	fputc( (unsigned char)data, fs08imdwr );

	if( ferror( fs08imdwr ) )
	{
		fprintf( stderr, "Can't write %s file\n", S08IMDWR );
	   	return -1;
	}

	for( ;; )
	{
		if( ( data = fgetc( fimcmd ) ) == EOF )
			break;

		check += (unsigned char)data;

		if( fputc( (unsigned char)data, fs08imdwr ) == EOF )
		{
			fprintf( stderr, "Can't write %s file\n", S08IMDWR );
			return -1;
		}
	}

	check = ~check;

	data = (unsigned char)(( check >> 8 ) & 0xFF);

	fseek( fs08imdwr, 0, SEEK_SET );
	fputc( (unsigned char)data, fs08imdwr );
	
	data = (unsigned char)( check & 0xFF );
	fputc( (unsigned char)data, fs08imdwr );

	fclose( fimcmd );
	fclose( fs08imdwr );

	return 0;
}


/*
 * image2s19:
 */
int
image2s19( void )
{
	long i, wr;
	unsigned char flag, imstate;

	if( init_ims19() < 0 )
		return -1;
	
	printf( "\nFinal S19 Building:   0x%04lX 0%", START_REPRO_AREA );
	imstate = IDLE_IM;
	
	
	for( i = START_REPRO_AREA; i <= END_REPRO_AREA; i++ )
	{

		switch( imstate )
		{
			case IDLE_IM:
				if( rflag_imfiles( &flag, i ) == OK_IMAGE && flag != EMPTY )
				{
					imstate = IN_ACC_IM;
					wr = 1;
				}
				break;
			case IN_ACC_IM:
				if( rflag_imfiles( &flag, i ) == OK_IMAGE && flag == EMPTY )
				{
					prepare_rec( i - wr, wr );
					flush_ims19();
					fflush( flog );
					imstate = IDLE_IM;
				}
				else if( wr >= WRITE_BLK_SIZE )
				{
					prepare_rec( i - wr, wr );
					flush_ims19();
					fflush( flog );
					wr = 1;
				}
				else
				{
					if( i == END_REPRO_AREA )
					{
						prepare_rec( i - wr, wr + 1 );
						flush_ims19();
						fflush( flog );
					}
					++wr;
				}
				break;
		}

		printf( "\rFinal S19 Building:   0x%04lX %d%", i, get_s19percen() );
	}
		
	add_term_rec();
	printf( "\n\n" );
		
#ifdef DEBUG
	fclose( flog );
	fclose( fbin );
#endif
	close_ims19();
	
	return 0;
}
