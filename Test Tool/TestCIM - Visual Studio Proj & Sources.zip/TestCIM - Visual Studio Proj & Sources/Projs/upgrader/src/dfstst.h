/*
 * dfstst.h
 */

int tst_create_file( int fd );

int tst_write_file( int fd );

int tst_read_file( int fd );

int tst_seek_file( int fd );

int chk_grstatus( void );
