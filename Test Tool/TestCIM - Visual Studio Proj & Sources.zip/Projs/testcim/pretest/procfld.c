/*
 * 		procfld.cpp
 * 			Process fields in each pass
 */

/*
 * 	System includes
 */

#include <stdio.h>
#include <string.h>

/*
 * 	Project includes
 */

#include "procfld.h"
#include "vars.h"
#include "intfsa.h"
#include "action.h"
#include "actdef.h"

#include "rerror.h"

/*
 * 	Enumerations
 */

/*
 * 	Macros
 */

#define MAX_PROC_SYMBOLS	100
#define MAX_TEST_SYMBOLS	100


/*
 * 		Static variables
 */

/*
 * 		Procedures symbol table
 */

static char *proc_symbols[ MAX_PROC_SYMBOLS ];
static int num_proc_symbols;

/*
 * 		Test symbol table
 */

static char *test_symbols[ MAX_TEST_SYMBOLS ];
static int num_test_symbols;

/*
 * 		Static functions
 */

static
char **
search_symbol( char **table, char *symbol )
{
	for( ; *table != NULL ; ++table )
		if( strcmp( *table, symbol ) == 0 )
			return table;
	return NULL;
}
	
static
int
add_proc_symbol( char *new_proc_symbol )
{
	if( num_proc_symbols >= MAX_PROC_SYMBOLS )
		fatal( "Procedure table exhausted");
	proc_symbols[ num_proc_symbols++ ] = strdup( new_proc_symbol );
	return num_proc_symbols;
}

static
int
add_test_symbol( char *new_test_symbol )
{
	if( num_test_symbols >= MAX_TEST_SYMBOLS )
		fatal( "Test table exhausted");
	test_symbols[ num_test_symbols++ ] = strdup( new_test_symbol );
	return num_test_symbols;
}

static
const INTER_T *
search_action( char *operation )
{
	const INTER_T *p;

	for( p = action_table; p < action_table + NUM_ACTIONS ; ++p )
	{
		if( p->label == NULL )
			continue;
		if( strcmp( p->label, operation ) == 0 )
			return p;
	}
	return NULL;
}

static
const INTER_T *
do_pass1( const INTER_T *p )
{
	if( p == NULL )
	{
		parse( CALL_PROC ); 
		return p;
	}

	if( *fields[ LABEL ] == '\0' )
	{
		if( p->type != NORMAL_TYPE )
			fatal( "Instruction does need a label in line %u", line );
	} else if( p->type == PROC_TYPE || p->type == EXT_TYPE ) 
		add_proc_symbol( fields[ LABEL ] );
	else if( p->type == TEST_TYPE )
		add_test_symbol( fields[ LABEL ] );
	else if( p->type != EQUATE_TYPE )
		fatal( "Instruction doesn't need a label in line %u", line );
	parse( p - action_table );
	return p;
}

static
const INTER_T *
do_pass2( const INTER_T *p )
{
	if( p != NULL )
		(*p->execute)();
	else if( strcmp( fields[ OPERATION ], action_table[ BEGIN_PROC ].label ) == 0 )
		define_proc();
	else if( strcmp( fields[ OPERATION ], action_table[ EXT_PROC ].label ) == 0 )
		ext_proc();
	else
		invoke_proc();
	return p;
}

static
const INTER_T *
verify_operation( void )
{
	const INTER_T *p;

	if
	(
		( p = search_action( fields[ OPERATION ] ) ) == NULL  &&
		search_symbol( proc_symbols, fields[ OPERATION ] ) == NULL
	)
		fatal( "Action '%s' not recognized in line %u", fields[ OPERATION ], line );
	return p;
}

/*
 *		Public functions
 */

void
do_pass( int pass )
{
	const INTER_T *p;

	p = verify_operation();
	pass == PASS1 ? do_pass1( p ) : do_pass2( p );
}


void
generate_main_section( void )
{
	int i;
	char **p;

	open_global_test();
	for( i = 0, p = test_symbols ; i < num_test_symbols ; ++p, ++i )
		call_function_test( *p );
	close_global_test();
}

void
write_heading( void )
{
	write_includes();
	write_vars();
}

