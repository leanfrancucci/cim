/*
 * 	userifc.h
 * 		User Interface
 * 		for testing
 */

#include "mytypes.h"

int power_up( void );
int format_flash( void );
int set_processor( void );
int ureinit( void );
int uadd( void );
int umultadd( void );
int uerase( void );
int uvalidate( void );
int uedit( void );
int ulist( void );
int power_down( void );
int kill_page( void );
int setdf1( void );
int setdf0( void );
int setdf1( void );
int setdf2( void );
int setdf3( void );
int setdf4( void );
int setdf5( void );
int setdf6( void );
int goto_menu0( void );
int set_dataflash( void );
int go_simulation( void );
int which_dataflash( void );
void verify_dflash( void );
int filesys_blanking( void );
int show_dir( void );
int do_create_file( void );
int show_sys_info( void );
int show_file_status( void );
int do_read_file( void );
int do_write_file( void );
int do_write_whole_file( void );
int do_read_whole_file( void );
int do_seek_file( void );
int do_reinit_file( void );
int do_reopen( void );
int do_reclose( void );


#if 0
int file_format( void );
int file_write( void );
int file_read( void );
int file_info( void );
int file_sync( void );
int file_whole( void );
int read_whole( void );
#endif

int goto_file( void );
int do_user_menu( void );
int create_test_file( void );

int cache_use( void );
int get_dev_list( void );
int set_dev_list( void );
int erase_refresh( void );

void open_refresh( void );
long getlong( char const *msg );

