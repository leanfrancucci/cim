/*
 *	valproc.h
 *
 *		This file creates a thread for automatic answering
 *		for the validator simulation
 */

#include "mytypes.h"

/*
 *	Starts a new thread for validator
 *	simulation
 */

void start_validator( void );

/*
 *	resume_validator:
 *		Resumes validator thread
 */

void resume_validator( void );

/*
 *	suspend_validator:
 *		Suspends the thread
 */

void suspend_validator( void );

/*
 *	destroy_validator:
 *		Destroys thread
 */

void destroy_validator( void );
