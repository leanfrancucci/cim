/*
 * sbeqtst.c
 */

#include "conser.h"
#include "sbeqtst.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
//#include "sleep.h"

char cmdbuff[20];
char rcvbuff[50];

int
get_lpin_tst( char number )
{
	char *i;
	int val;

	sprintf(cmdbuff, "getb %0d\r\n", number );
	tst_send_str( cmdbuff );
	tst_rcv_nchar( rcvbuff, 1000, 1000 );
	if( (i = strstr( rcvbuff, "PIN") ) == NULL )
		return -1;
	i += 7; 
	val = *i - '0';

	return val;
}

int
get_apin_tst( char number )
{
	char *i;
	char *j;
	char valbuff[5];
	int val;
	
	memset(valbuff,'\0',sizeof(valbuff));
	memset(rcvbuff,'\0',sizeof(rcvbuff));
	sprintf(cmdbuff, "geta %0d\r\n", number );
	tst_send_str( cmdbuff );
	tst_rcv_nchar( rcvbuff, 1000, 1000 );

	if( ( i = strstr( rcvbuff, "): " ) ) == NULL )
		return -1;

	j = valbuff;
	i += 3;

	while( *i != 'V' )
	{
		if(*i != '.')
		{
			*j = *i;
			++j;
		}
		++i;
	}

	val = atoi(valbuff);
	return val;
}

void
set_pin_tst( char who )
{
	if( (who >= 0) && ( who <= 9 ) )
		sprintf(cmdbuff, "\nsetb 0%u\n", who );
	else
		sprintf(cmdbuff, "\nsetb %u\n", who );

	tst_send_str(cmdbuff);
}

void
clr_pin_tst( char who )
{
	if( (who >= 0) && ( who <= 9 ) )
		sprintf(cmdbuff, "\nclrb 0%u\n", who );
	else
		sprintf(cmdbuff, "\nclrb %u\n", who );

	tst_send_str(cmdbuff);
}
