/*
 * 	proctbl.h
 * 		Table of test procedures
 */

/*
 * 		Type definitions
 */

typedef struct
{
	char *label;
	void (*execute)( void );
	unsigned type;
} INTER_T;

extern INTER_T const action_table[ NUM_ACTIONS ];
