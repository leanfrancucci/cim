/*
 * 	low485.c
 */

#include <stdio.h>
#include <string.h>

#include "mytypes.h"
#include "low485.h"
#include "cscmds.h"

static const uchar response[] = { 0xf8, 0x08, SBOX_SUCCESS, 0x09, 0x00, 0x01, 0x00, 0x01, 0x01, 0x01, 0x01, 0x00, 0x00, 0xcd };
static const uchar nack[] = { 0xf8, 0x08, SBOX_NACK, 0x00, 0xda };
static const uchar bad[] = { 0xf8, 0x08, SBOX_FAILURE, 0x01, 0xff, 0xdc };

#define NUM_RESPS	3


void
send_frame_485( uchar *p, uint qty )
{
	while( qty-- )
		printf( "%02.2X ", *p++ );
	printf( "\n" );
}

uint
rcv_frame_485( uchar *p, uint lim )
{
	static uint count = 0;
	const uchar *q;

	if( count >= NUM_RESPS )
		count = 0;
	switch( count )
	{
		case 0:
			q = response;
			lim = sizeof( response );
			break;
		case 1:
			q = nack;
			lim = sizeof( nack );
			break;
		case 2:
			q = bad;
			lim = sizeof( bad );
			break;
	}
	++count;
	memcpy( p, q, lim );
	return lim;
}

