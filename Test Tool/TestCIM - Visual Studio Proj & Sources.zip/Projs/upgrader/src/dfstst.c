/*
 * dfstst.c
 */

#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <conio.h>
#include "upgrade.h"
#include "safedefs.h"
#include "fserr.h"
#include "datafs.h"
#include "vaultdef.h"
#include "..\..\include\console.h"
#include "..\..\projlibs\include\cmd485.h"
#include "..\..\projlibs\include\c485defs.h"
#include "time.h"
#include "dfdata.h"
#include "dfstst.h"
#include "mytypes.h"

#define LAST_DEVICE		254
#define LAST_USER		999999999UL

#define MEGA			((ulong)KBYTE*KBYTE)
#define KBYTE			1024

#define fname	"wtest"
#define outfile	"rtest"

#define	MAXIMUM_NUM	0xFFFFFFFF
#define MEM_STAT_MASK	0x18
#define MAX_WRITE_SIZE		250

static uchar buff[1024];
static uchar readbuff[1024];


static
long
file_get_size( FILE *f )
{
	long size;

	fseek( f, 0, SEEK_END );
	size = ftell( f );
	fseek( f, 0, SEEK_SET );
	return size;
}

int
chk_grstatus( void )
{
	ST_T stat;

	while( 1 )
	{
		if( gr1_status( DEV_SAFEBOX, &stat ) < 0 )
		{
			printf( "\nSafe Board don't response, please check connections\n" );
			return -1;
		}
		if( ((stat.safebox_status & MEM_STAT_MASK) ^ 0x00) == 0 )
			return 0;
		printf( "Mem Status Error: %x\r", stat.safebox_status );
	}
	return 0;
}

int
tst_create_file( int fd )
{
	long num_units;
	int access, unit_size;
	int status;

	printf( "File creation.....\n" );
	unit_size = 1;
	access = 0;
	num_units = 65535;

	if( ( status = createfile( DEV_SAFEBOX, fd, unit_size, access, &num_units ) ) != DFILE_OK )
	{
		printf( "\t\t%s\n", users_msg[ -status ] );
		if( -status == ERR_DFILE_NOT_ENOUGH )
			printf( "\t\tSpace remaining is for %lu units\n", num_units );
	}else
		printf( "\tSpace allocated %lu units\n", num_units );
	printf( "File creation ended.....\n" );
	if( chk_grstatus() < 0 )
		return -1;
	return 1;

}


int
tst_do_write_file( int fd, FILE *f, FILESYS_T *sta, uint qty )
{
	int status;
	uint num_read, num_bytes;

	num_bytes = qty * sta->unit_size;

	if( ( num_read = fread( readbuff, sta->unit_size , qty, f ) ) < 0 )
	{
		printf("Error reading source file\n");
		return -1;
	}

	if( ( status = writefile( DEV_SAFEBOX, fd, num_read, readbuff, num_bytes ) ) < 0 )
	{
		printf( "writefile: %s\n", users_msg[ -status ] );
		return -1;
	}

	if( status == 0 )
		return -1;

	return 0;
}


int
tst_write_file( int fd )
{
	FILE *f; 
	FILESYS_T sta;
	unsigned long size, rest;
	long num_writes, count;

	if( ( f = fopen( fname, "rb" ) ) == NULL )
	{
		perror( "pfn" );
		return -1;
	}

	size = file_get_size( f );

	num_writes = size / MAX_WRITE_SIZE; 
	rest = size - (num_writes * MAX_WRITE_SIZE);

	statusfile( DEV_SAFEBOX, fd, &sta );
	
	if( sta.unit_size != 1 )
	{
		printf( "\nError unit size must be 1 byte\n" );
		return -1;
	}
	
	if( sta.num_units < size )
	{
		printf( "\nError Sources file is bigger than FD Nro %d\n", fd );
		return -1;
	}

	for( count = 0; count < num_writes; ++count )
	{
		printf("Write - FD %d - write count %d\r", fd, count);
		if( tst_do_write_file( fd, f, &sta, MAX_WRITE_SIZE ) < 0 )
		{
			printf( "\nError Writing FS, Upgrade Aborted\n" );
			return -1;
		}
//		if( chk_grstatus() < 0 )
//			return -1;
	}
	if( rest && ( tst_do_write_file( fd, f, &sta, rest ) < 0 ) )
	{
		printf( "\nError Writing FS, Upgrade Aborted\n" );
		return -1;
	}
	
	if( rest > 0 )
		printf("Write - FD %d - write count %d\r", fd, count);

	if( chk_grstatus() < 0 )
		return -1;

	printf("\n");

	fclose( f );
	
	return 1;
}


int
tst_read_file( int fd )
{
	int status;
	FILESYS_T sta;
	FILE *f;
	uint num_items;
	ulong count, num_reads;
	unsigned long rest;

	if( ( f = fopen( outfile, "wb" ) ) == NULL )
	{
		perror( "salida" );
		return 1;
	}

	fseek( f, 0L, SEEK_SET );
	statusfile( DEV_SAFEBOX, fd, &sta );

	num_reads = 65535 / MAX_READ_SIZE; 
	rest = 65535 - (num_reads * MAX_READ_SIZE);

	num_items = MAX_READ_SIZE;

	for( count = 0; count < num_reads ; ++count )
	{
		printf( "Read - FD %d - read count %d\r", fd, count );
//		if( chk_grstatus() < 0 )
//			return -1;
		if( ( status = readfile( DEV_SAFEBOX, fd, num_items, buff ) ) < 0 )
		{
			printf( "read_file: %s\n", users_msg[ -status ] );
			break;
		}
		if( status == 0 )
			break;
		if( fwrite( buff, sta.unit_size , num_items, f ) < 0 )
		{
			perror( "salida" );
			return 1;
		}
	}

	if( rest && ( readfile( DEV_SAFEBOX, fd, num_items, buff )  < 0 ) )
	{
		return -1;
	}
	if( rest > 0)
		printf( "Read - FD %d - read count %d\r", fd, count );
	
	if( chk_grstatus() < 0 )
		return -1;

	printf("\n");

	fclose( f );

	return 1;
}

int
tst_seek_file( int fd )
{
	int status;
	long offset;
	uint whence;

	printf( "Seek - FD %d\n", fd );
	offset = 0; 
	whence = 0;
	if( ( status = seekfile( DEV_SAFEBOX, fd, offset, whence ) ) != DFILE_OK )
		printf( "\t\t%s\n", users_msg[ -status ] );
	return 1;
}
