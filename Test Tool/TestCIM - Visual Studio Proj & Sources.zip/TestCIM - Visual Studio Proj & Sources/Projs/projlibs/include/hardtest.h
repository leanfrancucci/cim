/*
 *	hardtest.h
 */

#include "mytypes.h"

typedef void (*RX_FUNCTION)( unsigned char byte );
typedef void (*TIMER_CBACK)( void );

/*
 * 	init_test_timer
 * 		Receives first and remaining timeouts
 * 		Returns pointer to receive routine
 */

TIMER_CBACK init_test_timer( ulong ftime, ulong btime );

/*
 * 	init_test_channel
 * 		Receives pointer to send_frame routie and returns
 * 		pointer to character receive routine
 */

RX_FUNCTION init_test_channel( void (*sf)( uchar *p, uint qty ) );

