/*
 * fserr.h
 */

extern char * const users_msg[];
