/*
 * 	spipc.c
 * 		SPI implementation of
 * 		Hardware Abstraction Layer
 * 		Simulation in PC
 */

#include <stdio.h>

#include "..\mytypes.h"

#include "..\spihal.h"


void
spihal_init( void )
{
	fprintf( stderr, "%s\n", __FUNCTION__ );
}

void
spi_select_channel( MUInt dev_no )
{
	fprintf( stderr, "%s: %u\n", __FUNCTION__, dev_no );
}

void
spi_deselect_channel( MUInt dev_no )
{
	fprintf( stderr, "%s: %u\n", __FUNCTION__, dev_no );
}

void
spi_send_byte( MUInt byte )
{
	fprintf( stderr, "%s: %02.2X\n", __FUNCTION__, byte );
}

MUInt
spi_get_byte( void )
{
	fprintf( stderr, "%s\n", __FUNCTION__ );
	return 0xaa;
}


