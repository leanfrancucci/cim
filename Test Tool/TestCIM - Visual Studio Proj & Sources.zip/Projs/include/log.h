/*
 * 		log.h
 */

#ifdef __cplusplus
extern "C" {
#endif


void open_log( void );
void open_this( void );
void log( const char *fmt, ... );
void log_both( const char *fmt, ... );
void close_log( void );
void close_this( void );
char *get_this_name( void );
void flush_this( void );

#ifdef __cplusplus
}
#endif
