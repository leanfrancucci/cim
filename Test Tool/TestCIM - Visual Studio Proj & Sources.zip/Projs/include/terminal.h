/*
 * 		terminal.h
 * 			Platform independent calls
 * 			to terminal actions
 * 			Code platform dependent
 * 				Version 1.0
 * 				EAM 2/5/07
 */
#ifdef __cplusplus
extern "C" {
#endif

void sak_flat( void );
void sak( void );
int test_key( void );

/*
 * 		select_yes_no:
 * 			Prints rpompt command and awaits only an input char
 * 			for Yes or anything else for no
 * 			Pronts character selected, returns if yes selected
 */

int select_yes_no( const char *fmt, ... );

#ifdef __cplusplus
}
#endif

