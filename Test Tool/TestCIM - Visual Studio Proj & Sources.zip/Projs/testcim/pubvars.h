/*
 * 		pubvars.h
 * 			Public variables
 */

#include <setjmp.h>

extern int debug_flag;
extern int global_errors;

