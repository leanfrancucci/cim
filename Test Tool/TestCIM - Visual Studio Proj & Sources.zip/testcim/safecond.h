/*
 * safecond.h
 */

#include "mytypes.h"

enum 
{
	GR1_PREV,
	USRADD_NEED_FORMAT
};

#define CONDITION_DONE 1
#define CONDITION_RESET 0

#define FAIL_PWRON_DELAY	10000
#define FAIL_PWROFF_DELAY	2000	
#define CMD_TIME			1000

void set_tst_condition( uchar who, uchar value );
void init_func_tst( void );

void end_normal_tests( void );
