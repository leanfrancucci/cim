/*
 * main.c
 */

#include <stdio.h>
#include <conio.h>
#include <stdlib.h>


#include "rs19.h"

#define SWVERSION	"1.0"
#define PROGNAME	"boot"										/* Program name <= 9  chars */
#define PROGDEC		"S19 File conversor for HC(S)08" 			/* Description  <= 41 chars */
#define PROGDEC2	"Serial BootLoader file and merged S19" 	/* More Description  <= 64 chars */

void set_banner( void );
void get_vargs( int argc, char *argv[] );

static char codefile[16], bootfile[16]; 

int
main( int argc, char *argv[] )
{

	set_banner();
	get_vargs(argc, argv);

	if( codefile[0] )
	{
		if( read_s19( codefile ) < 0 )
			exit( 2 );

		if( setup_vect_tbl() < 0 )
			exit( 3 );

		if( check_image() < 0 )
			exit( 4 );

		if( blank_image() < 0 )
			exit( 5 );

		if( checksum_usrcode() < 0 )
			exit( 6 );

		if( prepare_prog_area() < 0 )
			exit( 7 );

		if( do_imcmddwr() < 0 )
			exit( 10 );


		if( bootfile[0] )
		{
			if( read_s19_boot( bootfile ) < 0 )
				exit( 8 );

			if( image2s19() < 0 )
				exit( 9 );
		}	
		printf( "\nSuccess\n");
	}else
		fprintf(stderr, "\nCode File Needed !!\n");
	return 0;
}


void 
get_vargs( int argc, char *argv[] )
{
	int i;
	if( argc < 3 )
	{
		fprintf(stderr, "Wrong number of arguments\n");
		fprintf(stderr, "Usage: %s -c <codefile> [-b <bootfile>]\n",PROGNAME);
		exit( 1 );
	}else{
		printf("Input Files:\r\n");

		for( i=1; i< argc; i=i+2)
			if( argv[i][0] == '-' )
				switch(argv[i][1])	
				{
					case 'c':
						sprintf(codefile,"%s",argv[i+1]);
						printf( "\t\tCODE FILE:%s\r\n",argv[i+1]);
						break;
					case 'b':
						sprintf(bootfile,"%s",argv[i+1]);
						printf( "\t\tBOOT FILE:%s\r\n",argv[i+1]);
						break;
				}
		printf( "\n\n");
	}
}

void 
set_banner( void )
{
	clrscr();
	window(5, 5, 80, 10);
	textcolor(BLACK);
	textbackground(LIGHTGRAY);
	cprintf(" ----------------------------------------------------------------------- \r\n");
	cprintf("|%9s - %-41s -  Version: %3s  |\r\n", PROGNAME, PROGDEC, SWVERSION);
	cprintf("| - %-65s - |\r\n",PROGDEC2);
	cprintf(" ----------------------------------------------------------------------- \r\n");
	printf("\r\n");
}
