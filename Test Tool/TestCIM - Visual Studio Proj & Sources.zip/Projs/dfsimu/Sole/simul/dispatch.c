
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#include "menus.h"

#include "userifc.h"


static const MENU_T menu0[] =
{
	{	"power up",			power_up		},
	{	"set processor",	set_processor	},
	{	"set_dataflash",	set_dataflash	},
	{	"which dataflash",	which_dataflash	},
	{	"erase refresh file",erase_refresh	},
//	{	"cache use",		cache_use		},
	{	"kill page",		kill_page		},
	{	"Exit to system",	terminate		},
	NULL
};


static const MENU_T menu1[] =
{
	{	"power down",		power_down		},
	{	"format flash",		format_flash	},
	{	"user add",			uadd			},
	{	"multiple user add",umultadd		},
	{	"user erase",		uerase			},
	{	"user validate",	uvalidate		},
	{	"user edit",		uedit			},
	{	"user list",		ulist			},
	{	"get devices",		get_dev_list	},
	{	"set_devices",		set_dev_list	},
	{	"To file menu",		goto_file		},
//	{	"Exit to system",	terminate		},
	NULL
};

static const MENU_T menu2[] =
{
	{	"power down",		power_down		},
	{	"format flash",		format_flash	},
	{	"user validate",	uvalidate		},
	{	"user list",		ulist			},
	{	"Exit to system",	terminate		},
	NULL
};

static const MENU_T menu3[] =
{
	{	"AT45DB161B",		setdf0			},
	{	"AT45DB321B",		setdf1			},
	{	"No selection",		goto_menu0		},
	NULL
};


static const MENU_T menu4[] =
{
	{	"power down",		power_down		},
	{	"File sys blank",	filesys_blanking},
	{	"Create file",		do_create_file	},
	{	"Read file", 		do_read_file	},
	{	"Write file",		do_write_file	},
	{	"Seek_file",		do_seek_file	},
	{	"Show dir",			show_dir		},
	{	"Show sys info",	show_sys_info	},
	{	"Show file status",	show_file_status},
	{	"Create test file",	create_test_file},
	{	"Write whole file",	do_write_whole_file },
	{	"Read whole file",	do_read_whole_file	},
	{	"To user menu",		do_user_menu	},
	NULL
};

static MENU_T const *this_menu;

static MENU_T const *all_menu[] =
{
	menu0, menu1, menu2, menu3, menu4
};

void
change_menu( uint menu_no )
{
	if( menu_no >= sizeof( all_menu )/sizeof( *all_menu ) )
		return;
	this_menu = all_menu[ menu_no ];
}



int
main( void )
{
	this_menu = menu0;
	set_begin_char( 'a' );
	verify_dflash();
	go_simulation();
	for(;;)
		do_menu( this_menu );
}



