#ifndef	__ALLINC_H__
#define __ALLINC_H__

/*
 * 	allinc.h
 * 		For including common
 * 		include files in the right
 * 		order
 */

#include "mytypes.h"
#include "vaultdef.h"
#include "dffatal.h"
#include "dfvars.h"

#endif


