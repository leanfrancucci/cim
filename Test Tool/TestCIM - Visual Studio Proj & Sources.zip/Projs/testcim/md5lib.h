#ifndef _MD5_LIB
#define _MD5_LIB

/**
 *	Libreria recortada para manejo de conversion de passwords MD5
 */


/**/
void *md5_buffer (const char *buffer, size_t len, void *resblock);

#endif
