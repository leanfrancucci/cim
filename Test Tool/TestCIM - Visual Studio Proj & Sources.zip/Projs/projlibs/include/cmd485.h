/*
 * 	cmd485.h
 */

#include "mytypes.h"
#include "rpctypes.h"
#include "c485defs.h"

#define CMD_COMM_ERROR	-32768

/*
 * 	unlock:
 * 		Supports one or two users. type says
 * 		how many users.
 * 		In case of two users validation, there
 * 		is another argument of type ptr to UT_T
 * 		Function returns < 0 in case of error
 */

SBYTE unlock( UBYTE dev, UBYTE pwd_type, UT_T IN(user1), UBYTE OUT(match_type1), UT_T IN(user2), UBYTE OUT(match_type2) );

/*
 * 	lock:
 * 		Blocks SafeLock lock
 */

SBYTE lock( UBYTE dev );

/*
 * 	actrl:
 * 		Enables/disables an alarm
 */

SBYTE actrl( UBYTE dev, UBYTE disena );

/*
 *	version:
 *		Gets hardware and firmware version
 */

SBYTE version( UBYTE dev, char OUT(swfw_version) );

/*
 * 	model:
 * 		Gets the SafeBox model
 */

SBYTE model( UBYTE dev, UBYTE OUT(model) );

/*
 * 	shutdown:
 * 		Enables interruption of backup power
 */

SBYTE shutdown( UBYTE dev );

/*
 * 	gr1_status:
 * 		Gets state of group1
 */

SBYTE gr1_status( UBYTE dev, ST_T OUT(pstatus) );

/*
 * 	addusr:
 * 		For adding user from data in 'user'
 * 		(validated from 'suser')	Added on 12/1/2007
 * 		Returns USERS_OK in case of succcess or a negative number
 * 		in error case
 */

SBYTE addusr( UBYTE dev, USER_T IN(user), SUSER_T IN(suser) );		/*	Modified 12/1/2007	*/
/*	SBYTE addusr( UBYTE dev, USER_T IN(user) );	*/

/*
 * 	delusr:
 * 		Eliminates 'user_id' if exists
 * 		*puser_id is truncated to NUM_UID bytes.
 * 		(Must be validated by a super user)		Added on 12/1/2007
 * 		Returns USERS_OK in case of succcess or a negative number
 * 		in error case
 * 		Changed argument for user_id from version 2.2 and up
 */

SBYTE delusr( UBYTE dev, uchar IN(usrid), SUSER_T IN(suser) );		/*	Modified 12/1/2007	*/
/*	SBYTE delusr( UBYTE dev, uchar IN(usrid) );	*/

/*
 * 	editusrpass:
 * 		Edits user information stored under 'user_id' of '*pold'.
 * 		Presents for logging one of the passwords in 'pass0'.
 * 		(Password in pass1 is don't care).
 * 		Only passwords may be edited; 'edit_pass' says which one or both
 * 		Returns USERS_OK in case of succcess or a negative number
 * 		in error case
 *
 */

SBYTE editusrpass( UBYTE dev, uchar IN(usrid), uchar IN(old_pwd), uchar IN(new_pwd), MUInt edit_pass );

/*
 * 	getusrdev:
 * 		This call returns '*p_dev_list' related with 'user_id'
 * 		in case 'user_id' exists
 * 		*puser_id is truncated to NUM_UID bytes.
 * 		Returns USERS_OK in case of succcess or a negative number
 * 		in error case
 * 		Changed argument for user_id from version 2.2
 */

SBYTE getusrdev( UBYTE dev, uchar IN(usrid), UWORD OUT(devlist) );

/*
 * 	users_set_devlist:
 * 		This calls set 'dev_list' for 'user_id' in case
 * 		'user_id' exists.
 * 		*puser_id is truncated to NUM_UID bytes.
 * 		'dev_list' is truncated to 16 bits.
 * 		(A super user must validate this command)		Added on 12/1/2007
 * 		Returns USERS_OK in case of succcess or a negative number
 * 		in error case
 * 		Changed argument for user_id from version 2.2
 */

SBYTE setusrdev( UBYTE dev, uchar IN(usrid), UWORD devlist, SUSER_T IN(suser) );	/*	Modified 12/1/2007	 */
/*	SBYTE setusrdev( UBYTE dev, uchar IN(usrid), UWORD devlist );	*/

/*
 * 	valusr:
 * 		Validates one user
 * 			In case of two users validation
 * 			this function must be called twice
 * 			as for example in case both must be ok:
 *				user_validation( &user0 ) == USER_OK && user_validation( &user1 ) == USER_OK;
 *			or in case one user must be validated
 *				user_validation( &user0 ) == USER_OK || user_validation( &user1 ) == USER_OK;
 *			Significance of arguments and return values same as 'users_pass_edit'
 *			Returns:
 *				USERS_OK if pass0 of '*p' matches with any one of the two passwords
 *				for user_id in '*p' or negative in error case.
 *				In success case:
 *					Returns in '*pass_match' which of both passwords matched.
 *					In '*pdev_list' returns the actual dev_list
 */

SBYTE valusr( UBYTE dev, uchar IN(userid), uchar IN(pwd), UWORD OUT(devlist), UBYTE OUT(pwd_match) );

/*
 * 	getusrinfo:
 * 		Returns information about maximum user number
 * 		and free space remaining for users only
 * 		if corresponding pointer is not NULL
 */

SBYTE getusrinfo( UBYTE dev, UWORD OUT(max_users), UWORD OUT(free_users) );

/*
 * 	usrformat:
 * 		Formats unconditionally the users 
 * 		flash pages.
 * 		(Must be validated by a super user)		Added on 12/1/2007
 * 		If 'emerg' != 0, then only
 * 		there are transactions with SECONDARY_DEVICE
 * 		and also only this device is formatted
 * 		Must be called after 'users_init'
 */
#if 0
SBYTE usrformat( UBYTE dev, SUSER_T IN(suser) );		/* Modified 12/1/2007 */
#else
SBYTE usrformat( UBYTE dev );
#endif

/*
 * 	blankdfs:
 * 		The entire filesystem is destroyed.
 * 		All files are removed
 * 		No input or output
 */

SBYTE blankdfs( UBYTE dev );

/*
 * 	dfilesys_create_file:
 * 		Creates a new file in file system
 * 		Inputs:
 * 			'df_desc' = file descriptor number to be created
 * 			'unit_size' (probably an structure size)
 * 			'*pnum_units' is the number of units that the file must hold.
 * 			In case '*pnum_units' is negative, then all the space remaining
 * 				is allocated for the file and the number of units allocated is returned by
 * 				reference in '*pnum_units"
 * 			'access' is the type of access that the file sustain for reading and writing.
 * 		Conditions
 * 			File contents are initialized to zero (C style)
 * 				Random files: position is reset to 0
 * 				Queue files: input and output index as well as
 * 					queue count are zeroed.
 * 		Returns:
 * 			From function: DFILE_OK or negative on error
 * 			By reference in '*pnum_units' the actual num_units allocated in case
 * 			of no error; *pnum_units as output may be greater as *pnum_units as input:
 * 			this comes from the fact that an integer number of pages is associated to a file.
 * 		Important note: if file system remaining space is less that on '*pnum_units' then
 * 			file DFILE_NOT_ENOUGH error is returned and in '*pnum_units' number of data units
 * 			that could be allocated is returned. File is not created.
 * 		Errors:
 * 			-ERR_DFILE_BAD_ACCESS:		Bad 'access' code
 * 			-ERR_DFILE_NOT_ENOUGH:		See important note
 * 			-ERR_DFILE_BAD_FDESC:		File descriptor not allowed
 * 			-ERR_DFILE_EXISTS_FDESC:	Exists file created with same file descriptor
 */

SBYTE createfile( UBYTE dev, UBYTE dfdesc, UBYTE unit_size, UBYTE access, SQUAD INOUT(pnum_units) );

/*
 * 	statusfile:
 * 		Return status of file.
 * 		Inputs:
 * 			File decriptor 'df_desc'
 * 		Returns:
 * 			Status returned in structure pointed by 'psta'
 * 			Function returns DFILE_OK on success or negative in case of error
 * 		Errors:
 * 			-ERR_DFILE_BAD_FDESC:	Descriptor out of range
 * 			-ERR_DFILE_NOT_EXISTS:	File not created
 */

SBYTE statusfile( UBYTE dev, UBYTE dfdesc, FILESYS_T OUT(sta) );

/*
 * 	readfile:
 * 		Reads from a file according to its access mode in creation.
 * 		Conditions
 * 			Random file, reads from its current position.
 * 			Queue file, reads from its logical position. (More about that in
 * 				dfilsys_seek).
 * 		Inputs
 * 			'df_desc' is the file descriptor
 * 			'num_units' carry the units quantity to be read
 * 		Outputs:
 * 			Function returns number of units actually read if >= 0 or negative
 * 				in error case
 * 			If no error, 'pbuff' contains data.
 * 			In case of -DFILE_SECTOR_ERROR, 'pbuff' contains data that
 * 				was read but without guarantee of corrctness
 *
 * 		If value returned (being positive) is less that 'num_units'
 * 		(including 0) represents that:
 * 			Random file: end of file has been reached.
 * 			Queue file: trying to read from a logical position
 * 				that is beyond the input pointer or the queue has
 * 				lesser units than requiered or the queue is empty 
 * 		Errors:
 * 			-ERR_DFILE_BAD_FDESC:		Descriptor out of range
 * 			-ERR_DFILE_BAD_NUMUNITS:	num_units is 0
 * 			-ERR_DFILE_NOT_EXISTS:		File not created
 * 			-ERR_DFILE_SECTOR_ERROR:	There was a sector error
 */

SBYTE readfile( UBYTE dev, UBYTE dfdesc, UBYTE num_units, uchar OUT(buff) );

/*
 * 	writefile:
 * 		Writes in a file according to its access mode in creation.
 * 		Doesn't allows to write randomly in a QUEUE file reopened as random
 * 		Inputs:
 * 			'num_units' quantity to be written is passed
 * 			'pbuff' contains data to be written.
 *		Conditions:
 * 			Random file, writes into its current position.
 * 			Queue file, writes into input index. If queue is full
 * 				overwrites older registers
 * 		Function returns number of units actually written if >= 0 or negative
 * 			in error case.
 *
 * 		If value returned (being positive) is less that 'num_units'
 * 		represents that:
 * 			Random file: end of file has been reached.
 * 			Queue file: only in case 'num_units' exceeds total queue size
 * 		Errors:
 * 			-ERR_DFILE_BAD_FDESC:		Descriptor out of range
 * 			-ERR_DFILE_BAD_NUMUNITS:	num_units is 0
 * 			-ERR_DFILE_NOT_EXISTS:		File not created
 * 			-ERR_DFILE_NOT_ALLOWED:		A write intent over a QUEUE file reopened as RANDOM
 *
 * 		Note: num_units is in terms of size of data object. 
 * 			From here is needed the byte_count
 */

SBYTE writefile( UBYTE dev, UBYTE df_desc, UBYTE num_units, uchar IN(buff), UBYTE byte_count );

/*
 *	 seekfile:
 *	 	Only used for files created as random or for files
 *	 	created for queue use in case reopened as random.
 *	 	Inputs:
 *	 		'df_desc' is file handler
 *	 		'offset' is desplacement from 'whence' point measure in terms
 *	 			of object units.
 *	 		'whence' specifies frow where 'offset' is measured
 *	 			Note: arguments are very similar to that of 'seek' Unix system call
 *	 	Important note: in case of QUEUE files, this seek only serves for reading
 *	 		and not for writing.
 *	 		QUEUE files are written as normal queues, i.e. using an input pointer
 *	 		regardless of the position reached by this call.
 *	 		In read case, the position is relative to the beginning of queue, i.e.
 *	 		the position is logical within the queue and not physical as is in
 *	 		the case of RANDOM VALC_Tfiles
 *	 		The seek in QUEUE files is valid for read. Each subsequent read advances
 *	 		position in num_items efectively read.
 *	 		In case a QUEUE file write is done, next position for read is reset to
 *	 		first position, i.e. to beginning of queue
 *	 	Outputs:
 *	 		Function returns DFILE_OK on succcess or negative in error case
 * 		Errors:
 * 			-ERR_DFILE_BAD_FDESC:		Descriptor out of range
 * 			-ERR_DFILE_NOT_EXISTS:		File not created
 * 			-ERR_DFILE_NOT_ALLOWED:		Seek on a QUEUE file not reopened as RANDOM
 * 			-ERR_DFILE_BAD_WHENCE:		whence code incorrect
 * 			-ERR_DFILE_BAD_SEEK:		Seek before beginning of file or past end of file
 *											Seek not done
 *
 */

SBYTE seekfile( UBYTE dev, UBYTE df_desc, SQUAD offset, UBYTE whence );

/*
 * 	reinitfile:
 * 		This call reinits a file to its empty condition
 * 		Input:
 * 			'df_desc' file descriptor
 * 		Conditions:
 * 			Random file: all of its contents are zeroed and position
 * 				is reset to 0
 * 			Queue file: input and output index are zeroed and
 * 				also queue count
 * 		Output:
 * 			Function returns DFILE_OK on success or negative in error case
 * 		Errors:
 * 			-ERR_DFILE_BAD_FDESC:		Descriptor out of range
 * 			-ERR_DFILE_NOT_EXISTS:		File not created
 */

SBYTE reinitfile( UBYTE dev, UBYTE dfdesc );

/*
 * 	getdfsinfo:
 * 		Returns the bit field of file descriptors used,
 * 		bit field of file descriptors in error, file system 
 * 		pages in error and file system size.
 * 		Note: Must be called after 'dfilesys_init' function.
 *
 * 		If NULL, error.
 */

SBYTE getdfsinfo( UBYTE dev, DFS_INFO_T OUT(info) );

/*
 * 	tlock:
 * 		Changes blocking time
 */

SBYTE tlock( UBYTE dev, UBYTE tlock0, UBYTE tlock1 );

/*
 * 	tunlockenable
 */

SBYTE tunlockenable( UBYTE dev, UBYTE tlock );

/*
 * 	valconfig
 */

SBYTE valconfig( UBYTE dev, VALCOMM_T IN(vals0), VALCOMM_T IN(vals1) );		/*	Changed on 12/1/2007	*/
/*	SBYTE valconfig( UBYTE dev, VALC_T IN(val0), VALC_T IN(val1) );	*/

/*
 * 	valframe
 * 		Sends a frame to CIM in order to resend to validator 'dev'
 * 		Whichever responds validator to CIM is echoed transparently
 */

SBYTE valframe( UBYTE dev, UBYTE byte_count, uchar INOUT(buffer) );

/*
 * 	hctrl:
 * 		ON/OFF Host Power
 */

SBYTE hctrl( UBYTE dev, UBYTE onoff );

/*
 * 	forcereset:
 * 		Request Foreced MCU Reset
 */

SBYTE forcereset( UBYTE dev );

/*
 * forceusrpass:
 *		Request forced change of the user password
 *		checks frames counter.
 */
SBYTE forceusrpass( UBYTE dev, UT_T IN(user), UWORD frames );

/*
 * syncnumframes:
 *		Clears frame counter.
 */
SBYTE syncnumframes( UBYTE dev );
