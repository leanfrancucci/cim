/*
 * 		internal.h
 * 			functions for embedded actions
 *
 */

typedef struct
{
	void (*on_begin_all_tests)( void );
	void (*on_end_all_tests_pass)( void );
	void (*on_end_all_tests_fail)( void );
	void (*on_begin_one_test)( const char *test );
	void (*on_end_one_test_pass)( void );
	void (*on_end_one_test_fail)( void );
	void (*on_exit)( void );
} ITEST_T;

/*
 * 	Public functions
 */

/*
 * 	warning functions
 */

void do_warning( int fatal );
void do_warning_analog( double min, double max, double value, const char *msg_english, const char *msg_spanish, int fatal );
void make_warning_analog( double min, double max, double val, const char *msg_english, const char *msg_spanish, int fatal );
void do_warning_digital( int must_be, int bit, const char *msg_english, const char *msg_spanish, int fatal );

/*
 * 	------	Operational functions
 */

/*
 * 	sak_user:
 * 		Show prompt and waits for key entry
 */

void sak_user( const char *prompt_english, const char *prompt_spanish );

/*
 * 	sleep_user:
 * 		Waits 'msecs' milliseconds to
 * 		continue
 */

void sleep_user( unsigned long msecs );

/*
 * 	----- Information calls
 */

/*
 * 	begin_test:
 * 		Receives what test to be done
 */
void begin_test( const char *test, const char *msg_english, const char *msg_spanish );
/*
 * 	end_test:
 * 		Finalizes last test
 */

void end_test( void );

/*
 * 	------- Internal calls
 */

/*
 * 	init_all_tests:
 * 		Called before executing Excel program
 */

void init_all_tests( void );

/*
 * 	error_status:
 * 		Returns number of non fatal errors
 * 		reported
 * 		If 0, then test PASS
 */

int error_status( void );

/*
 * 	begin_all_tests
 * 		Wrapper for do_tests in order
 * 		to setjmp it
 */

int begin_all_tests( void );

/*
 *	set_func_tests
 *		Sets callback functions
 *		for each begin and end of tests
 *		Variable ITEST must be maintained
 *		outside this file, that is, by caller
 */

void set_func_tests( ITEST_T *p );
