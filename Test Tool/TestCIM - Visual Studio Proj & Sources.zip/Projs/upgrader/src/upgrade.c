/*
 * upgrade.c
 */

#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <conio.h>
#include "upgrade.h"
#include "safedefs.h"
#include "fserr.h"
#include "datafs.h"
#include "vaultdef.h"
#include "..\..\include\console.h"
#include "..\..\projlibs\include\cmd485.h"
#include "..\..\projlibs\include\c485defs.h"
#include "time.h"
#include "dfdata.h"

#define KBYTE			1024
#define MEGA			((ulong)KBYTE*KBYTE)
#define BETA_OFFSET		8
#define VERSION_OFFSET	2

static uchar readbuff[1024];
static uchar swfw_version[30];
static ulong total,progress;
static time_t tp;

static char printbuff[1024];

static
void
color_printf( int color, const char *s, ... )
{
	va_list ap;
	va_start( ap, s );
	setrgb( color );
	vsprintf( printbuff, s, ap );
	printf( printbuff );
	setrgb( WHITE_ON_BLACK );
}

static
char *
get_tstversion( void )
{
	int v1,v2,sv1,sv2,ssv1,ssv2,h1,h2,sh1,sh2;
	static char ver_buff[VERSION_STR_SIZE];

	printf( "\nTest File SW Version: [XX.XX.bb]: " );
	v1 = getch();
	if( v1 == '\r' )
	{
		printf( "\n\nVersion: SWFF.FF.bbHWFF.FF\n\n" );
		return DEFAULT_VERSION;
	}

	putch(v1);
	v2 = getch();
	putch(v2);
	putchar('.');
	sv1 = getch();
	putch(sv1);
	sv2 = getch();
	putch(sv2);
	putchar('.');
	ssv1 = getch();
	putch(ssv1);
	ssv2 = getch();
	putch(ssv2);

	printf( "\nTest File HW Version: [XX.XX]: " );
	h1 = getch();
	putch(h1);
	h2 = getch();
	putch(h2);
	putchar('.');
	sh1 = getch();
	putch(sh1);
	sh2 = getch();
	putch(sh2);

	printf( "\n\nVersion: SW%c%c.%c%c.%c%cHW%c%c.%c%c\n",v1,v2,sv1,sv2,ssv1,ssv2,h1,h2,sh1,sh2);
	sprintf( ver_buff, "SW%c%c.%c%c.%c%cHW%c%c.%c%c",v1,v2,sv1,sv2,ssv1,ssv2,h1,h2,sh1,sh2);

	return ver_buff;
}

static
char *
getstring( char const *msg )
{
	uint first, len;

	first = 0;
	printf( "Input %s: ", msg );
	if( !first ) first = 1; else putchar( '\a' );
	if( fgets( (char *)readbuff, sizeof( readbuff ), stdin ) == NULL )
		exit( EXIT_SUCCESS );
	len = strlen( (char *)readbuff );
	if( readbuff[ ( len = strlen( (const char *)readbuff ) ) - 1 ] == '\n' )
		readbuff[ --len ] = '\0';
	return (char *)readbuff;
}

static
long
file_get_size( FILE *f )
{
	long size;

	fseek( f, 0, SEEK_END );
	size = ftell( f );
	fseek( f, 0, SEEK_SET );
	return size;
}

static
void
init_show_progress( ulong size )
{
	total = size;
	progress = 0;
	time(&tp);
	printf( "\n%s\n",ctime(&tp) );
}

static
void
finish_show_progress( void )
{
	progress = 0;
	time(&tp);
	printf( "\n\n%s\n",ctime(&tp) );
}

static
void
show_progress( char *txt, int add )
{
	progress += add;
	printf("%s%u%c\r", txt, ( progress *100 ) / total, 0x25 );
}

static
int
read_file( FILE *f, FILESYS_T *sta, uint qty )
{
	int status;

	if( ( status = readfile( DEV_SAFEBOX, FD_FW, qty, readbuff ) ) < 0 )
	{
		color_printf( RED_ON_BLACK, "read_file: %s\n", users_msg[ -status ] ); 
		return -1;
	}

	show_progress( "Uploading File... ", qty );

	if( status == 0 )
		return -1;
	
	if( fwrite( readbuff, sta->unit_size , qty, f ) < 0 )
	{
		color_printf( RED_ON_BLACK, "Error Writing Target File" );
		return -1;
	}

	return 0;
}

static
int
write_file( FILE *f, FILESYS_T *sta, uint qty )
{
	int status;
	uint num_read, num_bytes;

	num_bytes = qty * sta->unit_size;

	if( ( num_read = fread( readbuff, sta->unit_size , qty, f ) ) < 0 )
	{
		printf("Error reading source file\n");
		return -1;
	}

	if( ( status = writefile( DEV_SAFEBOX, FD_FW, num_read, readbuff, num_bytes ) ) < 0 )
	{
		printf( "writefile: %s\n", users_msg[ -status ] );
		return -1;
	}

	if( status == 0 )
		return -1;

	show_progress( "Downloading File... ", qty );

	return 0;
}

static	
int
do_upgrade( char *pfn )
{
	FILE *f; 
	FILESYS_T sta;
	unsigned long size, rest;
	long num_writes, count;

	if( ( f = fopen( pfn, "rb" ) ) == NULL )
	{
		perror( "pfn" );
		return -1;
	}

	size = file_get_size( f );

	num_writes = size / MAX_WRITE_SIZE; 
	rest = size - (num_writes * MAX_WRITE_SIZE);

	printf( "\nFile size: %u bytes\n", size );

	statusfile( DEV_SAFEBOX, FD_FW, &sta );
	printf( "\nFD Nro %d DFlash FS size: %u units, %u bytes each unit\n", FD_FW, sta.num_units, sta.unit_size );
	
	if( sta.unit_size != 1 )
	{
		color_printf( RED_ON_BLACK, "\nError unit size must be 1 byte\n" );
		return -1;
	}
	
	if( sta.num_units < size )
	{
		color_printf( RED_ON_BLACK, "\nError Sources file is bigger than FD Nro %d\n", FD_FW );
		return -1;
	}

	color_printf( RED_ON_BLACK, "\nThe content in FD Nro %d will be lost\n", FD_FW );
	printf( "Press Y to continue " );
	if( tolower(getchar()) != 'y' )
		return -1;
	getchar();

	printf( "\nBlanking File... " );
	reinitfile( DEV_SAFEBOX, FD_FW );

	color_printf( GREEN_ON_BLACK, "OK\n\n" );

	init_show_progress( size );

	for( count = num_writes; count; --count )
		if( write_file( f, &sta, MAX_WRITE_SIZE ) < 0 )
		{
			color_printf( RED_ON_BLACK, "\nError Writing FS, Upgrade Aborted\n" );
			return -1;
		}

	if( rest && ( write_file( f, &sta, rest ) < 0 ) )
	{
		color_printf( RED_ON_BLACK, "\nError Writing FS, Upgrade Aborted\n" );
		return -1;
	}

	finish_show_progress();

	fclose( f );
	
	color_printf( GREEN_ON_BLACK, "\nDownload OK\n" );

	return 0;
}

static
int
is_beta( uchar *p )
{
	if( ( *(p+BETA_OFFSET) != '0' ) ||  *(p+BETA_OFFSET+1) != '0' )
		return 1;
	return 0;
}

/*
 *	is_qmajq:
 *	p = board, q = file
 *	if p>=q -> 0, p<q -> 1
 */
static
int
is_qmajq( uchar *p, uchar *q )
{
	char *s;
	static uchar cbuff[15];
	ulong qnum,pnum;

	cbuff[0] = *(p+VERSION_OFFSET);
	cbuff[1] = *(p+VERSION_OFFSET+1);
	cbuff[2] = *(p+VERSION_OFFSET+3);
	cbuff[3] = *(p+VERSION_OFFSET+4);
	cbuff[4] = *(p+VERSION_OFFSET+6);
	cbuff[5] = *(p+VERSION_OFFSET+7);
	cbuff[6] = '\0';

	cbuff[7] = *(q+VERSION_OFFSET);
	cbuff[8] = *(q+VERSION_OFFSET+1);
	cbuff[9] = *(q+VERSION_OFFSET+3);
	cbuff[10] = *(q+VERSION_OFFSET+4);
	cbuff[11] = *(q+VERSION_OFFSET+6);
	cbuff[12] = *(q+VERSION_OFFSET+7);
	cbuff[13] = '\0';

	pnum = strtol((const char*)cbuff,&s,16);
	qnum = strtol((const char*)cbuff+7,&s,16);

	if( pnum < qnum )
		return NEW_VERSION_IN_FILE;
	else if( pnum > qnum )
		return NEW_VERSION_ON_BOARD;
	
	return BOTH_VERSION_EQUALS;
}

static
int
compare_versions( char *pfn )
{
	FILE *f;
	uchar *pv_board, *pv_file;
	static char namebuff[10];
	uint num_read;

	if( do_getversion() < 0 )
		return -1;

	pv_board = swfw_version;

	if( ( f = fopen( pfn, "rb" ) ) == NULL )
	{
		perror( "Firmware File Not Found" );
		return -1;
	}

	fseek( f, START_FILE_VERSION, SEEK_SET );

	memset(readbuff,'\0',KBYTE);

	if( ( num_read = fread( readbuff, 1 , TOTAL_VERSION_SIZE, f ) ) < 0 )
	{
		printf("Error reading source file\n");
		return -1;
	}
	
	fclose( f );

	pv_file = readbuff;

	printf( "\n\nFile %s Version: ", pfn );
	color_printf( GREEN_ON_BLACK, "%s\n", pv_file );

	switch ( is_qmajq( pv_board, pv_file ) )
	{
		case NEW_VERSION_ON_BOARD:
		case NEW_VERSION_IN_FILE:
		default:
			return -1;
//			color_printf( RED_ON_BLACK, "Download Error\n" )
		case BOTH_VERSION_EQUALS:
			return 0;
//			color_printf( GREEN_ON_BLACK, "Download Error\n" )
	}
}

int
do_bindownload( void )
{
	char *pfn;

	color_printf( BLUE_ON_WHITE, "\n\nBinary Download\n\n");

	pfn = getstring( "Source File Name" );

	if( strlen(pfn) <= 0 )
	{
		printf( "Use Default Source File: \"%s\"\n", SOURCE_FILENAME_DFT );
		pfn = SOURCE_FILENAME_DFT;
	}

	do_upgrade( pfn );
	return 0;
}

int
do_binupload( void )
{
	FILESYS_T sta;
	FILE *f;
	char *pfn;
	uint num_items;
	int status;
	ulong count, num_to_read, qty, rest;

	color_printf( BLUE_ON_WHITE, "\n\nBinary Upload\n\n");

	pfn = getstring( "Target File Name" );

	if( strlen(pfn) <= 0 )
	{
		printf( "Use Default Target File: \"%s\"\n", TARGET_FILENAME_DFT );
		pfn = TARGET_FILENAME_DFT;
	}

	if( ( f = fopen( pfn, "wb" ) ) == NULL )
	{
		perror( "salida" );
		return -1;
	}
	fseek( f, 0L, SEEK_SET );
	
	if( ( status = seekfile( DEV_SAFEBOX, FD_FW, 0, SEEK_SET ) ) != DFILE_OK )
		printf( "\t\t%s\n", users_msg[ -status ] );

	statusfile( DEV_SAFEBOX, FD_FW, &sta );

	num_to_read = getlong( "num bytes to read <maximum=0>" );
	
	if( num_to_read == 0 )
		num_to_read = sta.num_units; 


	init_show_progress( num_to_read );

	num_items = MAX_READ_SIZE;
	qty = num_to_read / num_items;
	rest = num_to_read - ( qty * MAX_READ_SIZE );

	for( count = 0; count < qty ;  ++count )
		if( read_file( f, &sta, MAX_READ_SIZE) < 0 )
		{
			color_printf( RED_ON_BLACK, "\nError Reading FS, Upload Aborted\n" );
			return -1;
		}

	if( rest && ( read_file( f, &sta, rest ) < 0 ) )
	{
		color_printf( RED_ON_BLACK, "\nError Reading FS, Upload Aborted\n" );
		return -1;
	}

	finish_show_progress();
	
	fclose( f );

	color_printf( GREEN_ON_BLACK, "\nUpload OK\n" );
	fclose( f );
	return 0;
}

int
do_getversion( void )
{
	ST_T stat;

	printf( "\n\nConnecting Safe Board Board... " );

	if( gr1_status( DEV_SAFEBOX, &stat ) < 0 )
	{
		color_printf( RED_ON_BLACK, "\nSafe Board don't response, please check connections\n" );
		return -1;
	}

	if( version( DEV_SAFEBOX, (char *)swfw_version ) < 0 )
	{
		color_printf( RED_ON_BLACK, "\nSafe Board don't response, please check connections\n" );
		return -1;
	}

	color_printf( GREEN_ON_BLACK, "OK\n" );
	printf( "\n\nSafe Board Version: " );
	color_printf( GREEN_ON_BLACK, "%s\n", swfw_version );

	return 0;
}

/*
 * safe_chk_grstat:	
 *  Verify the state of the Group1 Device.
 *  	arg1	: see Group1 Devices definition
 *  	arg2	: verifing state, acording to the device passed in arg1
 * 		returns : SUCCESS if the state of the device is equal to the
 * 					verifing state.
 * 				  FAIL otherwise.
 */
int
safe_chk_grstat( int which, int must_be, char *msg )
{
	ST_T stat;
	unsigned char val;

	if( gr1_status( DEV_SAFEBOX, &stat ) < 0 )
	{
		color_printf( RED_ON_BLACK, "\nSafe Board don't response, please check connections\n" );
		return -1;
	}

	switch ( which )
	{
		case GR1_LOCKER0 :
			val = stat.locker0_status;
			break;
		case GR1_VD_PLUNGER :
			val = stat.plunger0_status;
			break;
		case GR1_LOCKER1 :
			val = stat.locker1_status;
			break;
		case GR1_MD_PLUNGER :
			val = stat.plunger1_status;
			break;
		case GR1_PWRSYS:
			val = ( (stat.safebox_status & PS_MASK) >> PS_SHIFTS );
			break;
		case GR1_MEMSTAT:
			val = ( (stat.safebox_status & MS_MASK) >> MS_SHIFTS );
			break;
		case GR1_SYSTAT:
			val = ( (stat.safebox_status & S_MASK) >> S_SHIFTS );
			break;
		case GR1_BATTST:
			val = (stat.safebox_status & BS_MASK);
			break;
		case GR1_STACKER0:
			val = stat.stacker0_status;
			break;
		case GR1_STACKER1:
			val = stat.stacker1_status;
			break;
		default :
			val = (char)must_be + 1;
			break;
	}

	if( val != must_be )
	{
		color_printf( RED_ON_BLACK, msg );
		return -1;
	}
	return 0;
}

int
secure_download( void )
{
	FILE *f;
	uchar *pv_board, *pv_file;
	static char namebuff[10];
	char *pfn;
	uint num_read;
	int versions, new_version;
	ST_T stat;

	if( do_getversion() < 0 )
		return -1;

	printf( "\nSafe Board Connection: ");
	if( safe_chk_grstat(GR1_SYSTAT, PRIMARY_SYS, "SECONDARY, Connect to Primary Access to Upgrade\n" ) < 0 )
		return -1;
	color_printf( GREEN_ON_BLACK, "PRIMARY\n" );

	printf( "\nPower Status: " );
	if( safe_chk_grstat(GR1_PWRSYS, EXT, "BACKUP BATTERY, Connect External Power Supply to Upgrade\n" ) < 0 )
		return -1;
	color_printf( GREEN_ON_BLACK, "EXTERNAL\n" );

	printf( "\nBattery Status: " );
	if( safe_chk_grstat(GR1_BATTST, BATTOK, "NO BATTERY or too LOW, Connect Backup Battery to Upgrade\n" ) < 0 )
		return -1;
	color_printf( GREEN_ON_BLACK, "BATTERY OK\n" );

	printf( "\nMemories Access: " );
	if( safe_chk_grstat(GR1_MEMSTAT, BOTH_MEM_OK, "Error in Memories Primary Acces please check SafeBoard\n" ) < 0 )
		return -1;
	color_printf( GREEN_ON_BLACK, "M1/M2 OK\n" );
		
	pv_board = swfw_version;

	printf("\n\n");
	strcpy( namebuff, getstring( "Source File Name" ) );

	pfn = namebuff;

	if( strlen(pfn) <= 0 )
	{
		printf( "Use Default Source File: \"%s\"\n", SOURCE_FILENAME_DFT );
		pfn = SOURCE_FILENAME_DFT;
	}

	if( ( f = fopen( pfn, "rb" ) ) == NULL )
	{
		perror( "pfn" );
		return -1;
	}

	fseek( f, START_FILE_VERSION, SEEK_SET );

	memset(readbuff,'\0',KBYTE);

	if( ( num_read = fread( readbuff, 1 , TOTAL_VERSION_SIZE, f ) ) < 0 )
	{
		printf("Error reading source file\n");
		return -1;
	}
	
	fclose( f );

	pv_file = readbuff;

	printf( "\n\nFile %s Version: ", pfn );
	color_printf( GREEN_ON_BLACK, "%s\n", pv_file );

	versions = is_beta( pv_board ) | ( is_beta( pv_file ) << 1 );

	switch ( versions )
	{
		case BOTH_NO_BETA:
			new_version = is_qmajq( pv_board, pv_file );
			if( new_version != NEW_VERSION_IN_FILE )
				printf("Installed Safe Board version is higher\n");
			else 
				printf("Version File %s is equal to installed\n", pfn );
			break;
		case BOTH_BETA:
			new_version = is_qmajq( pv_board, pv_file );
			printf("Both Beta Version ");
			if( new_version != NEW_VERSION_IN_FILE )
				printf("Installed Safe Board version is higher\n");
			else
				printf("Version File %s is higher\n", pfn );
			break;
		case BOARD_ONLY_BETA:
			printf("Installed Safe Board version is Beta Version\n");
			new_version = NEW_VERSION_IN_FILE;
			break;
		case FILE_ONLY_BETA:
			printf("File %s is beta version Download forced\n", pfn);
			new_version = NEW_VERSION_IN_FILE;
			break;
		default:
			new_version = NEW_VERSION_ON_BOARD;
			break;
	}

	if( new_version != NEW_VERSION_IN_FILE )
		color_printf( RED_ON_BLACK, "Upgrade Cancelled\n" );
	else
	{
		color_printf( BLUE_ON_WHITE, "\n\nBinary Upgrade\n\n");
		if( do_upgrade( pfn ) < 0 )
			return -1; 

		color_printf( BLUE_ON_WHITE, "\n\nSAFE Board Reset, please wait...\n\n");
		forcereset( DEV_SAFEBOX );

		while( gr1_status( DEV_SAFEBOX, &stat ) < 0 );

		if( compare_versions( pfn ) < 0 )
		{
			color_printf( RED_ON_BLACK, "\nDownload Error\n" );
			return -1;
		}

		color_printf( GREEN_ON_BLACK, "\nUpgrade OK\n" );
	}

	return 0;
}


int
create_test_file( void )
{
	ulong size, count;
	int c, next;
	FILE *f;
	char *pfn, *pver;

	printf( "Creating test file......\n" );

	pfn = getstring( "Test File Name" );

	if( strlen(pfn) <= 0 )
	{
		printf( "Use Default Test File Name: \"%s\"\n", TEST_FILENAME_DFT );
		pfn = TEST_FILENAME_DFT;
	}

	pver = get_tstversion(); 

	remove( pfn );

	if( ( f = fopen( pfn, "wb" ) ) == NULL )
	{
		perror( pfn );
		return -1;
	}

	size = getlong( "file size in Kbytes" );

	for( count = 0, next = -1, c = '0' ; count < (size * KBYTE) ; ++count, ++c )
	{
		if( count >= START_FILE_ADDR && count < START_FILE_VERSION )
		{
			fputc( '0', f );
			continue;
		}
		if( count == START_FILE_VERSION )
		{
			while( *pver != '\0' )
			{
				fputc( *pver++, f );
				++count;
			}
		}

		if( next > 0 )
		{
			fputc( next, f );
			next = -1;
			--c;
		}
		if( c == '9'+1 )
			c = 'A';
		else if( c == 'Z'+1 )
			c = 'a';
		else if( c == 'z'+1 )
		{
			c = '0';
			next = '\n';
		}
		if( next < 0 )
			fputc( c, f );
	}
	fclose( f );

	printf( "Creating test file ended......\n" );
	return 0;
}

int
do_power_up( void )
{
	FILE *f;
	uchar *pv_board, *pv_file;
	static char namebuff[10];
	char *pfn;
	uint num_read;
	int versions, new_version;
	ST_T stat;

	if( do_getversion() < 0 )
		return -1;
	pv_board = swfw_version;

	pfn = SOURCE_FILENAME_DFT;

	if( ( f = fopen( pfn, "rb" ) ) == NULL )
	{
		perror( "Firmware File Not Found" );
		return -1;
	}

	fseek( f, START_FILE_VERSION, SEEK_SET );

	memset(readbuff,'\0',KBYTE);

	if( ( num_read = fread( readbuff, 1 , TOTAL_VERSION_SIZE, f ) ) < 0 )
	{
		printf("Error reading source file\n");
		return -1;
	}
	
	fclose( f );

	pv_file = readbuff;

	printf( "\n\nFile %s Version: ", pfn );
	color_printf( GREEN_ON_BLACK, "%s\n", pv_file );

	versions = is_beta( pv_board ) | ( is_beta( pv_file ) << 1 );

	switch ( versions )
	{
		case BOTH_NO_BETA:
			new_version = is_qmajq( pv_board, pv_file );
			if( new_version == NEW_VERSION_ON_BOARD )
				printf("Installed Safe Board version is higher\n");
			else
				printf("Version File %s is higher\n", pfn );
			break;
		case BOTH_BETA:
			new_version = is_qmajq( pv_board, pv_file );
			printf("Both Beta Version ");
			if( new_version == NEW_VERSION_ON_BOARD )
				printf("Installed Safe Board version is higher\n");
			else
				printf("Version File %s is higher\n", pfn );
			break;
		case BOARD_ONLY_BETA:
			printf("Installed Safe Board version is Beta Version\n");
			new_version = NEW_VERSION_IN_FILE;
			break;
		case FILE_ONLY_BETA:
			printf("File %s is beta version Download forced\n", pfn);
			new_version = NEW_VERSION_IN_FILE;
			break;
		default:
			new_version = NEW_VERSION_ON_BOARD;
			break;
	}

	if( new_version == NEW_VERSION_ON_BOARD )
		color_printf( RED_ON_BLACK, "Upgrade Cancelled\n" );
	else
	{
		color_printf( BLUE_ON_WHITE, "\n\nBinary Upgrade\n\n");
		if( do_upgrade( pfn ) < 0 )
			return -1; 

		color_printf( BLUE_ON_WHITE, "\n\nSAFE Board Reset, please wait...\n\n");
		forcereset( DEV_SAFEBOX );

		while( gr1_status( DEV_SAFEBOX, &stat ) < 0 );

		if( compare_versions( pfn ) < 0 )
		{
			color_printf( RED_ON_BLACK, "\nDownload Error\n" );
			return -1;
		}

		color_printf( GREEN_ON_BLACK, "\nUpgrade OK\n" );
	}
	return 0;
}

void
reset_mcu( void )
{
	forcereset( DEV_SAFEBOX );
}

