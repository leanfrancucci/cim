/*
 * imcmd.c
 */

#include <stdio.h>

#define CMD_DELIM		'\n'

static FILE *fim;

#define HCS08IM		"hcs08im"
#define TOTALIMS19	"totalim.s19"

enum 
{ 
	HCS08, TOTALIM
};
 
static const char *outfiles[] = 
{
	HCS08IM, TOTALIMS19
};

static unsigned char fnidx; 

int
init_imcmd( void )
{
	fnidx = HCS08;
	if( ( fim = fopen( outfiles[fnidx], "w+b" ) ) == NULL )
	{
		fprintf( stderr, "Can't open image and command file hcs08im\n" );
		return -1;
	}
	return 0;
}

int
init_ims19( void )
{
	fnidx = TOTALIM;
	if( ( fim = fopen( outfiles[fnidx], "w+b" ) ) == NULL )
	{
		fprintf( stderr, "Can't open image and command file totalim.s19\n" );
		return -1;
	}
	return 0;
}

void
set_byte( unsigned char b )
{
	fputc( b, fim );
}

void
set_word( unsigned short w )
{
	fputc( ( w >> 8 ) & 0xFF , fim );
	fputc( w & 0xFF, fim );
}

void
set_delim( void )
{
	fputc( CMD_DELIM, fim );
}

void
close_imcmd( void )
{
	printf( "\t\tOUTPUT FILE: %s\r\n", outfiles[fnidx]);
	fclose( fim );
}

void
set_str_s19( const char *p )
{
	fputs( p, fim );
}

void
set_byte_s19( unsigned char b )
{
	fprintf( fim, "%02X", b );

}

void
set_word_s19( unsigned short w )
{
	fprintf( fim, "%02X", ( w >> 8 ) & 0xFF );
	fprintf( fim, "%02X", w & 0xFF );
}

void
flush_imcmd( void )
{
	fflush( fim );
}

