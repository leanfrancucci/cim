/*
 * upgrade.h
 */

#include <stdio.h>
#include "..\..\projlibs\include\cmd485.h"

enum
{
	NEW_VERSION_ON_BOARD, NEW_VERSION_IN_FILE, BOTH_VERSION_EQUALS
};

enum
{
	BOTH_NO_BETA, BOARD_ONLY_BETA, 
	FILE_ONLY_BETA, BOTH_BETA
};

#define START_FILE_ADDR		0
#define CHECKSUM_SIZE		2 
#define WR_CMD_SIZE			4
#define E_CMD_SIZE			3
#define START_FILE_VERSION (START_FILE_ADDR+CHECKSUM_SIZE+WR_CMD_SIZE+E_CMD_SIZE)
#define VERSION_STR_SIZE	20
#define DEFAULT_VERSION		"SWFF.FF.bbHWFF.FF"
#define TOTAL_VERSION_SIZE	(strlen(DEFAULT_VERSION))

#define MAX_WRITE_SIZE		250
#define MAX_READ_SIZE		250
#define TEST_FILENAME_DFT	"tstfile.s19"
#define SOURCE_FILENAME_DFT "S08IMDWR"
#define TARGET_FILENAME_DFT "target.s19"

int do_bindownload( void );
int do_binupload( void );
int do_getversion( void );
int secure_download( void );
void reset_mcu( void );
int do_power_up( void );
int write_file( FILE *f, FILESYS_T *sta, uint qty );
