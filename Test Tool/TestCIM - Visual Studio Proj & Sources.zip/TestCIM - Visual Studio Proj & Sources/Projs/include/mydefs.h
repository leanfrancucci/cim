#ifndef __MYDEFS_H__
#define __MYDEFS_H__

#ifdef __cplusplus
extern "C" {
#endif
	
#define forever	for(;;)
#define ESC		0x1b

#ifdef __cplusplus
}
#endif

#endif
