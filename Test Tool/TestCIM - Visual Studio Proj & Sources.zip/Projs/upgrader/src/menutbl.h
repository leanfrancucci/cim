/*
 * menutbl.h
 */

#include "menus.h"

extern const MENU_T menus[];
