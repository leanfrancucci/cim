/*
 * 	userifc.c
 * 		User Interface
 * 		for testing
 */

#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>

#include "..\..\projlibs\include\cmd485.h"
#include "..\..\projlibs\include\c485defs.h"
#include "datafs.h"
#include "mytypes.h"
#include "dfdata.h"
#include "safedefs.h"
#include "vaultdef.h"

#define LAST_DEVICE		254
#define LAST_USER		999999999UL

#define MEGA			((ulong)KBYTE*KBYTE)
#define KBYTE			1024

static char * const init_msg[] =
{
	"INIT_OK",					/*	No errors in both flashes			*/
	"COLD_FORMATTED",			/*	Typical in first use				*/
	"RECOVERED",				/*	Errors recovered					*/
};

char * const users_msg[] =
{
	"USER_OK",
	"ERR_USER_NOT_EXISTS",			/*	user_id doesn't exists				*/
	"ERR_USER_BAD_PASSWORD",		/*	Password presented does not match	*/
	"ERR_USER_NUM_EXCEEDED",		/*	Can't add a new user				*/
	"ERR_USER_EXISTS",				/*	user_id	exists						*/
	"ERR_FREE1",					/*	Error not exists			 		*/
	"ERR_USER_COMM_NOT_IN_EMERG",	/*	Command not allowed in emergency	*/
	"ERR_FREE2",					/*	Error not exists					*/
	"ERR_FLASH_BAD_PROGRAM",		/*	Programming does not verify			*/
	"ERR_INVALID_CONTENT",

	"ERR_DFILE_INVALID_DF",			/*	Invalid file descriptor				*/
	"ERR_DFILE_BAD_ACCESS",			/*	Bad access in create				*/
	"ERR_DFILE_NOT_ENOUGH",			/*	Not enough place for creation		*/
	"ERR_DFILE_NOT_ALLOWED",		/*	Operation not allowed				*/
	"ERR_DFILE_BAD_WHENCE",			/*	Bad whence data in seek				*/
	"ERR_DFILE_BAD_SEEK",			/*	Seeks cannot be done				*/
	"ERR_DFILE_BAD_FDESC",			/*	File descriptor out of range		*/
	"ERR_DFILE_EXISTS_FDESC",		/*	File exists for the same descriptor	*/
	"ERR_DFILE_NOT_EXISTS",			/*	File not exists						*/
	"ERR_DFILE_BAD_ORIGIN",			/*	Invocation origin not exists		*/
	"ERR_DFILE_SECTOR_ERROR",		/*	Sector error in reading				*/
	"ERR_DFILE_BAD_OFFSET",			/*	Offset out of limits				*/
	"ERR_DFILE_BAD_UNITSIZE",		/*	Record size is too long or zero		*/
	"ERR_DFILE_BAD_NUMUNITS",		/*	Record number is zero				*/
};

static char * const validate_msg[] =
{
	"PASS0_MATCH",
	"PASS1_MATCH",
	"PASS_BAD",
};

static char * const edit_msg[] =
{
	"EDIT_PASS0 <0>",
	"EDIT_PASS1 <1>",
	"BOTH_EDIT <2>"
};

static char * const part_number[] =
{
	"AT45DB161B",
	"AT45DB321B"
};

typedef struct
{
	uchar	used;
	uchar signature;
	USER_T	user;
} FUSER_T;

static FUSER_T	usert;

static USER_T user, user_new;
static USER_T userp =
{
	{ '0' }, 0, 
	{ '1', '2', '3', '4', '5', '6', '7', '8' },
	{ '8', '7', '6', '5', '4', '3', '2', '1' }
};

#define fname	"wtest"
#define outfile	"rtest"

static uchar buff[1024];
static uchar tbuff[256];
static uint num_users;
static char *flsel = "aflsel";
static uint wthru;
static char refresh_file[] = "refresh.csv";
char *file_flash0 = "afl0";
char *file_flash1 = "afl1";

extern uint dflash_index[2];

FILE *frf;

void dataflash_power_down( void );

static
void
write_which( uint index_main, uint index_sec )
{
	FILE *f;

	if( ( f = fopen( flsel, "wb" ) ) == NULL )
	{
		perror( flsel );
		exit( EXIT_FAILURE );
	}
	fwrite( &index_main, 1, sizeof( index_main ), f );
	fwrite( &index_sec, 1, sizeof( index_sec ), f );
	fclose( f );
}

static
int
read_which( uint *pindex_main, uint *pindex_sec )
{
	FILE *f;

	if( ( f = fopen( flsel, "rb" ) ) == NULL )
		return 0;
	fread( pindex_main, 1, sizeof( *pindex_main ), f );
	fread( pindex_sec, 1, sizeof( *pindex_sec ), f );
	fclose( f );
	return 1;
}

static
void
set_dflash_index( uint index_main, uint index_sec )
{
	dflash_index[0] = index_main;
	dflash_index[1] = index_sec;
	write_which( index_main, index_sec );
}

long
getlong( char const *msg )
{
	uint first;
	long value;

	first = 0;
	for(;;)
	{
		printf( "Input %s :" , msg);
		if( !first ) first = 1; else putchar( '\a' );
		if( fgets( (char *)buff, sizeof( buff ), stdin ) == NULL )
			exit( EXIT_SUCCESS );
		if( sscanf( (const char *)buff, "%ld", &value ) == 1 )
			return value;
	}
}

static
uint
getint( char const *msg, uint max )
{
	uint value, first;

	first = 0;
	do
	{
		printf( "Input %s : ( 0 to %u )", msg, max );
		if( !first ) first = 1; else putchar( '\a' );
		if( fgets( (char *)buff, sizeof( buff ), stdin ) == NULL )
			exit( EXIT_SUCCESS );
		if( sscanf( (const char *)buff, "%u", &value ) != 1 )
			continue;
	} while( value > max );
	return value;
}

char *
get_string( char const *msg, uint max )
{
	uint first, len;

	first = 0;
	do
	{
		printf( "Input %s: <exactly %d> ", msg, max );
		if( !first ) first = 1; else putchar( '\a' );
		if( fgets( (char *)buff, sizeof( buff ), stdin ) == NULL )
			exit( EXIT_SUCCESS );
		len = strlen( (char *)buff );
		if( buff[ ( len = strlen( (const char *)buff ) ) - 1 ] == '\n' )
			buff[ --len ] = '\0';
	} while( len != max );
	return (char *)buff;
}

static
uint
getint_hex( char const *msg, uint max )
{
	uint value, first;

	first = 0;
	do
	{
		printf( "Input %s : ( 0 to %X )", msg, max );
		if( !first ) first = 1; else putchar( '\a' );
		if( fgets( (char *)buff, sizeof( buff ), stdin ) == NULL )
			exit( EXIT_SUCCESS );
		if( sscanf( (const char *)buff, "%x", &value ) != 1 )
			continue;
	} while( value > max );
	return value;
}

static
uint
verify_ascii( uchar *p, uint num )
{
	while( num-- )
		if( !isgraph( *p++ ) )
			return 0;
	return 1;
}

static
void
getpass( char const *msg, uint num, uchar *p )
{
	uint status, first;

	first = 0;
	do
	{
		status = 0;
		printf( "Input %s (exactly %u characters) : ", msg, num );
		if( !first ) first = 1; else putchar( '\a' );
		if( fgets( (char *)buff, sizeof( buff ), stdin ) == NULL )
			exit( EXIT_SUCCESS );
		if( strlen( (const char *)buff ) == num + 1 )
		{
			memcpy( p, buff, num );
			status = verify_ascii( p, 8 );
		}
	} while( !status );
}

static
void
one_complement( void *p, int qty )
{
	uchar *q;

	for( q = p; qty-- ; ++q )
		*q ^= 0xff;
}

static
long
get_file_size( const char *name )
{
	FILE *f;
	long size;

	if( ( f = fopen( name, "rb" ) ) == NULL )
		return 0;
	fseek( f, 0L, SEEK_END );
	size = ftell( f );
	fclose( f );
	return size;
}

static
int
get_fd( void )
{
	char b[50];

	sprintf( b, "file descriptor <0-%u>", NUM_FDS-1 );
	return getint( b, FD_FW );
}

void
open_refresh( void )
{
	if( ( frf = fopen( refresh_file, "at" ) ) == NULL )
	{
		perror( "refresh.csv" );
		exit( EXIT_FAILURE );
	}
}

int
filesys_blanking( void )
{
	printf( "File system blanking.....\n" );
	blankdfs( DEV_SAFEBOX );
	printf( "File system blanking ends.....\n" );
	return 1;
}

static
void
show_this_dir( int fd )
{
	FILESYS_T fsta;
	int status;

	printf( "\tfd = %2u : ", fd );  
	if( ( status = statusfile( DEV_SAFEBOX, fd, &fsta ) ) != DFILE_OK )
	{
		printf( "\t\t%s\n", users_msg[ -status ] );
		return;
	}
	printf( "type = %s, unit_size = %u, num_units = %lu\n",
		( fsta.file_type == RANDOM ? "RANDOM" : "QUEUE" ),
		fsta.unit_size, fsta.num_units );
	if( fsta.file_type == QUEUE )
		printf( "\t\tin_index = %lu, out_index %lu, num_elems %u\n", fsta.in_index, fsta.out_index, fsta.num_elems );
	printf( "\t\tposition = %lu\n", fsta.position );
}

static
void
show_whole_dir( void )
{
	int fd;

	for( fd = DF_FIRST_DESC ; fd < NUM_FDS ; ++fd ) 
		show_this_dir( fd );
}


int
show_dir( void )
{
	printf( "Showing directory.....\n" );
	show_whole_dir();
	printf( "Showing directory ended.....\n" );
	return 1;
}

static int get_fd( void );
int
do_create_file( void )
{
	long num_units;
	int access, unit_size, fd;
	int status;

	printf( "File creation.....\n" );
	show_whole_dir();
	do
	{
		fd = get_fd();
		do
			unit_size = getint( "unit size <1, 255> : ", 255 );
		while( unit_size == 0 );

		access = getint( "access <0-RANDOM, 1-QUEUE> : ", 1 );
		num_units = getlong( "File size in units <0:all remaining space> : " );
		if( num_units == 0L )
			num_units = -1L;
	} while( getint( "are you sure ? <0:NO - 1:YES> : ", 1 ) == 0 ); 

	if( ( status = createfile( DEV_SAFEBOX, fd, unit_size, access, &num_units ) ) != DFILE_OK )
	{
		printf( "\t\t%s\n", users_msg[ -status ] );
		if( -status == ERR_DFILE_NOT_ENOUGH )
			printf( "\t\tSpace remaining is for %lu units\n", num_units );
	}else
		printf( "\tSpace allocated %lu units\n", num_units );
	printf( "File creation ended.....\n" );
	return 1;

}

int
show_sys_info( void )
{
	DFS_INFO_T p;

	printf( "Showing space information.....\n" );
	getdfsinfo(DEV_SAFEBOX, &p);
	printf( "\tRemaining file system space = %lu bytes\n", p.dfs_size );

	printf( "Showing space information ended.....\n" );
	return 1;

}

static
void
show_this_file_status( int fd )
{
	FILESYS_T fsta;
	int status;

	if( ( status = statusfile( DEV_SAFEBOX, fd, &fsta ) ) != DFILE_OK )
		printf( "%s\n", users_msg[ -status ] );
	else
	{
		printf( "\tfile_type = %s\n", fsta.file_type == RANDOM ? "RANDOM" : "QUEUE" );
		printf( "\tunit_size = %u, num_units = %lu\n", fsta.unit_size, fsta.num_units );
		if( fsta.file_type == QUEUE )
			printf( "\tin_index = %lu, out_index %lu\n", fsta.in_index, fsta.out_index );
		printf( "\tposition = %lu\n", fsta.position );
	}
}


int
show_file_status( void )
{
	unsigned fd;

	printf( "Showing file status.....\n" );
	show_whole_dir();
	fd = get_fd();
	show_this_file_status( fd );

	printf( "Showing file status ended.....\n" );
	return 1;
}

#define	MAXIMUM_NUM	0xFFFFFFFF

int
do_read_file( void )
{
	int fd, status;
	FILESYS_T sta;
	FILE *f;
	uint num_items;
	ulong count, num_to_read;

	printf( "Reading whole file.....\n" );
	if( ( f = fopen( outfile, "wb" ) ) == NULL )
	{
		perror( "salida" );
		return 1;
	}

	show_whole_dir();
	fd = get_fd();
	fseek( f, 0L, SEEK_SET );
	statusfile( DEV_SAFEBOX, fd, &sta );

	num_to_read = getlong( "num elements to read <maximum=0>" );
	if( num_to_read == 0 )
		num_to_read = MAXIMUM_NUM;

	num_items = 1;

	for( count = 0; count < num_to_read ; ++count )
	{
		if( ( status = readfile( DEV_SAFEBOX, fd, num_items, buff ) ) < 0 )
		{
			printf( "read_file: %s\n", users_msg[ -status ] );
			break;
		}
		printf( "\t%8ld: %d units\n", count, status );
		if( status == 0 )
			break;
		if( fwrite( buff, sta.unit_size , num_items, f ) < 0 )
		{
			perror( "salida" );
			return 1;
		}
	}
	printf( "\nReading whole file ended.....\n" );
	fclose( f );

	return 1;
}

int
do_write_file( void )
{
	int fd, status;
	FILESYS_T sta;
	FILE *f;
	uint num_items, num_read, num_bytes;
	char *pfname;

	pfname = fname;
	printf( "Writing file.....\n" );
	if( ( f = fopen( pfname, "rb" ) ) == NULL )
	{
		perror( "fname" );
		return 1;
	}

	show_whole_dir();
	fd = get_fd();

	do
	{
		num_items = getint( "num items to write", 250 );
		statusfile( DEV_SAFEBOX, fd, &sta );
		if( ( num_bytes = num_items * sta.unit_size ) > LEO_BUFFER )
			printf( "Comm buffer exceeded, expected maximum %u bytes, current %u\n", LEO_BUFFER, num_bytes );
	} while( num_bytes > LEO_BUFFER );


	printf( "\tPosition informed by file sistem %ld\n", (long)sta.position * sta.unit_size );
	fseek( f, (long)sta.position * sta.unit_size, SEEK_SET );


	if( ( num_read = fread( buff, sta.unit_size , num_items, f ) ) < 0 )
	{
		perror( fname );
		return 1;
	}
	printf( "\tnum_elems read %u\n", num_read );

	if( ( status = writefile( DEV_SAFEBOX, fd, num_read, buff, num_bytes ) ) < 0 )
		printf( "writefile: %s\n", users_msg[ -status ] );
	else
		printf( "\tnum_elems written %u\n", status );
	printf( "Writing file ended.....\n" );
	return 1;
}

int
do_write_whole_file( void )
{
	int fd, status;
	FILESYS_T sta;
	FILE *f;
	uint num_items, num_read, num_bytes;
	ulong count, num_to_write;


	printf( "Writing whole file.....\n" );
	if( ( f = fopen( fname, "rb" ) ) == NULL )
	{
		perror( "fname" );
		return 1;
	}

	show_whole_dir();
	fd = get_fd();
	fseek( f, 0L, SEEK_SET );
	statusfile( DEV_SAFEBOX, fd, &sta );

	num_to_write = getlong( "num elements to write <maximum=0>" );
	if( num_to_write == 0 )
		num_to_write = 	MAXIMUM_NUM;

	num_items = 1;

	num_bytes = num_items * sta.unit_size;

	count = 0;
	for( count = 0 ; count < num_to_write ; ++count )
	{
		if( ( num_read = fread( buff, sta.unit_size , num_items, f ) ) < 0 )
		{
			perror( fname );
			return 1;
		}
//		printf( "\t%ld: %u\r", count++, num_read );

		if( ( status = writefile( DEV_SAFEBOX, fd, num_read, buff, num_bytes ) ) < 0 )
		{
			printf( "writefile: %s\n", users_msg[ -status ] );
			return 1;
		}
		printf( "\t%ld: %u\n", count, status );
		if( status == 0 )
			break;
	}
	printf( "Writing whole file ended.....\n" );

	return 1;
}

int
do_read_whole_file( void )
{
	int fd, status;
	FILESYS_T sta;
	FILE *f;
	uint num_items;
	ulong count, num_to_read;

	printf( "Reading whole file.....\n" );
	if( ( f = fopen( "salida", "wb" ) ) == NULL )
	{
		perror( "salida" );
		return 1;
	}

	show_whole_dir();
	fd = get_fd();
	fseek( f, 0L, SEEK_SET );
	statusfile( DEV_SAFEBOX, fd, &sta );

	num_to_read = getlong( "num elements to read <maximum=0>" );
	if( num_to_read == 0 )
		num_to_read = MAXIMUM_NUM;

	num_items = 1;

	for( count = 0; count < num_to_read ; ++count )
	{
		if( ( status = readfile( DEV_SAFEBOX, fd, num_items, buff ) ) < 0 )
		{
			printf( "readfile: %s\n", users_msg[ -status ] );
			break;
		}
		printf( "\t%8ld: %d units\n", count, status );
		if( status == 0 )
			break;
		if( fwrite( buff, sta.unit_size , num_items, f ) < 0 )
		{
			perror( "salida" );
			return 1;
		}
	}
	printf( "\nReading whole file ended.....\n" );
	fclose( f );

	return 1;
}


int
do_seek_file( void )
{
	int fd, status;
	long offset;
	uint whence;

	printf( "Seeking file.....\n" );
	show_whole_dir();
	fd = get_fd();
	offset = getlong( "offset " );
	whence = getint( "whence <0=SEEK_SET,1=SEEK_CUR,2=SEEK_END>", 2 );
	if( ( status = seekfile( DEV_SAFEBOX, fd, offset, whence ) ) != DFILE_OK )
		printf( "\t\t%s\n", users_msg[ -status ] );
	show_this_file_status( fd );
	printf( "Seeking file ended.....\n" );
	return 1;
}

int
do_reinit_file( void )
{
	int fd, status;

	printf( "Reiniting file.....\n" );
	show_whole_dir();
	fd = get_fd();
	if( ( status = reinitfile( DEV_SAFEBOX, fd ) ) != DFILE_OK )
		printf( "\t\t%s\n", users_msg[ -status ] );
	printf( "Reiniting file ended.....\n" );
	return 1;
}


