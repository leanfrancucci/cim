/*
 * 	messages.c
 * 		Here the message table for
 * 		each recognized language
 */


#include "messages.h"
#include "lang.h"

/*
 * 	In file options.c
 */

char const * const help_message[ NUM_LANG ] =
{
		"Option usage:\n"
		"\tf: option file (default optdef.txt)\n"
		"\tl: language ( [E]nglish, [S]panish - default English )\n"
		"If option file doesn't exists, default options\n"
		"are taken from program:\n",

		"Uso de las opciones:\n"
		"\tf: archivo de opciones (default optdef.txt)\n"
		"\tl: idioma ( [E] para ingles, [S] para espanol - default Ingles )\n"
		"De no existir el archivo se toman opciones default\n"
		"dentro del programa:\n"
};

char const * const usage_msg[ NUM_LANG ] =
{
		"Usage: %s\n"
		"\t -f option_file (default optdef.txt)\n"
		"\t -l language ( [E]nglish, [S]panish - default English )\n"
	   	"\t -h (help)\n",

		"Uso: %s\n"
		"\t -f archivo_de_opciones) (default optdef.txt)\n"
		"\t -l: idioma ( [E] para ingles, [S] para espanol - default Ingles )\n"
	   	"\t -h (ayuda)\n"
};

char const * const option_line_command[ NUM_LANG ] =
{
		"Line command option: options file %s",
		"Opcion en linea de comando: archivo de opciones %s"
};

char const * const no_options_file[ NUM_LANG ] =
{
		"Option file %s doesn't exists...\n"
		"Installing default options",

		"No existe el archivo de opciones %s\n"
		"Tomando opciones default"
};

char const * const getting_options_from[ NUM_LANG ] =
{
		"Obtaining options from file %s",
		"Tomando opciones del archivo %s"	
};

char const * const error_in_options_file[ NUM_LANG ] =
{
	"Error in options file %s on line %u",
	"Error en archivo de opciones %s en linea %u"
};

char const * const msg_comm_channel[ NUM_LANG ] =
{
	"Serial channel %s: %s,%6u,%u,%c,%c,%6lu,%6lu",
	"Canal serie %s: %s,%6u,%u,%c,%c,%6lu,%6lu"
};

/*
 *	In file testmain.c
 */

char const * const input_serial_number[ NUM_LANG ] =
{
	"Input test serial number....\n",
	"Ingrese numero de serie para la prueba....\n"
};

char const * const console_eof[ NUM_LANG ] =
{
	"EOF as console input",
	"Ingresado EOF en consola"
};

char const * const input_serial_or_terminate[ NUM_LANG ] =
{
	"Please input a serial number or terminate testing\n",
	"Debe ingresar un numero de serie o terminar las pruebas\n"
};

char const * const invalid_serial[ NUM_LANG ] =
{
	"Invalid serial number",
	"Numero de serie invalido"
};


char const * const selected_serial[ NUM_LANG ] =
{
	"Selected serial number %s",
	"Numero de serie elegido %s"
};

char const * const failed_previous_test[ NUM_LANG ] =
{
	"There is a failed previous test on same number\n"
	"Proceed with new test on same board",

	"Existe prueba anterior FALLIDA	del mismo numero\n"
	"Realiza nueva prueba de la misma plaqueta"
};

char const * const new_test_on_failed[ NUM_LANG ] =
{
	"%sccepted new test for previous failed serial number %s",
	"%scepta nueva prueba para numero de serie %s en falla"
};

char const * const passed_previous_test[ NUM_LANG ] =
{
	"There is a succesful previous test on same number\n"
	"Proceed with new test on same board",

	"Existe prueba anterior EXITOSA	del mismo numero\n"
	"Realiza nueva prueba de la misma plaqueta"
};

char const * const new_test_on_passed[ NUM_LANG ] =
{
	"%sccepted new test for previous passed serial number %s",
	"%scepta nueva prueba para numero de serie %s previamente aceptada"
};


char const * const more_tests_to_go[ NUM_LANG ] =
{
	"Proceed with another board test",
	"Prueba mas plaquetas"
};

char const * const test_end_msg[ NUM_LANG ] =
{
	"End of test for board number %s, result %s",
	"Fin de prueba de placa numero %s resultado %s"
};


char const * const want_to_print[ NUM_LANG ] =
{
	"Print detailed results",
	"Desea imprimir los resultados detallados"
};

char const * const printed_results_msg[ NUM_LANG ] =
{
	"Printed results for number %s",
	"Impresion de resultados para numero %s"
};

char const * const install_board[ NUM_LANG ] =
{
	"Please, install board to test\n",
	"Proceda a colocar la plaqueta para test\n"
};

char const * const board_test_begin[ NUM_LANG ] =
{
	"Beginning board test number %s",
	"Comienzo de prueba para numero %s"
};

char const * const board_file[ NUM_LANG ] =
{
	"Board file",
	"Archivo de placa"
};

char const * const historical_test_file[ NUM_LANG ] =
{
	"Historical tests file",
	"Archivo historico de pruebas"
};

char const * const end_of_all_tests[ NUM_LANG ] =
{
	"All tests ended",
	"Finalizacion de todas las pruebas"
};

char const * const begin_test_program[ NUM_LANG ] =
{
	"Begin program test",
	"Comienzo de programa de test"
};

char const * const abnormal_program_end[ NUM_LANG ] =
{
	"Program terminated by early aborting",
	"Programa terminado por consola"
};

/*
 *	In file internal.c
 */

char const * const ending_tests_in_error[ NUM_LANG ] =
{
	"Ending last test and all other tests by errors",
	"Terminando ultima prueba y todas las pruebas por errores"
};

char const * const error_in_analog_test[ NUM_LANG ] =
{
	"\tError in test: %s { %.2f [ %.2f ] %.2f }",
	"\tError en prueba: %s { %.2f [ %.2f ] %.2f }"
};

char const * const error_in_digital_test[ NUM_LANG ] =
{
	"\tError in test: %s { %d [%d] }",
	"\tError en prueba: %s { %d [%d] }"
};

char const * const sleeping_process[ NUM_LANG ] =
{
	"Sleeping during %lu msecs",
	"Durmiendo durante %lu msegs"
};

char const * const begin_test_msg[ NUM_LANG ] =
{
	">>> Beginning %s: %s",
	">>> Comienzo %s: %s"
};

char const * const end_test_msg[ NUM_LANG ] =
{
	"<<< End %s: %s",
	"<<< Fin %s: %s"
};

char const * const end_test_msg_console[ NUM_LANG ] =
{
	"<<< End: %s\n",
	"<<< Fin: %s\n"
};

char const * const redoing_test[ NUM_LANG ] =
{
	"Redoing test",
	"Rehaciendo prueba"
};
