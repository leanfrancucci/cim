/*
 * 	dump.h
 * 		To be inserted in dfilesys.h
 * 		Written in other file till acceptance
 * 		by Delsat
 */

/*
 * 	fs_data:
 * 		Returns data from whole file system
 * 		Three data are returned:
 * 			'fs_size' as number of pages from function return
 * 			'page_size' by reference
 * 			'segment_size' by reference (same as definition of LEO_BUFFER)
 * 		No errors are informed
 * 			For each NULL pointer, its information will not be returned
 * 			(This will be a logical error, becaus the information must
 * 			be saved for file system recover)
 */

unsigned fs_data( unsigned *ppage_size, unsigned *psegment_size ); 

/*
 * 	dump_page:
 * 		Dumps a file system page whose order is 'page_no' (From
 * 		0 to fs_size-1).
 * 		The 'segment_no' is a chunk counter that goes from 0.
 * 		If no error, the contents of that 'page_no' and 'segment_no'
 * 		is copied to 'pseg'.
 * 		The function returns 0 or positive in case of no error;
 * 		the value returned is how many bytes where copied in 'pseg'.
 * 		Normally, this is the same quantity as a segment length which
 * 		is defined as LEO_BUFFER.
 * 		When the value returned is less than LEO_BUFFER (including 0),
 * 		that means	that the last segment was read.
 * 		In case the function returns a negative number, its module
 * 		expresses the error cause.
 * 			Errors to be informed (must be coded after acceptance):
 * 				Bad 'page_no': 'page_no' is outside the range od 0 to
 * 					fs_size-1
 * 				Page in error: page can't be dumped because has a checksum
 * 					error. 'pseg' contents has no meaning.
 * 			In case 'segment_no' is outside the allowed range, no error
 * 				is informed, but function returns 0. This is so becuase if
 * 				page_size is divisible by LEO_BUFFER, the only way to detect
 * 				the last segment is to read next to last and receive 0.
 *
 * 		Notes:
 * 			1.- Each page dump has more bytes that the bytes used for pure
 * 			information: each flash page contains user information and system
 * 			information.
 * 			2.- For example, a flash page can have 512 bytes for user information
 * 			and 16 bytes for system information totalizing 528 bytes. All the
 * 			bytes (user and system) must be retained in the dump
 * 			3.- If a page is in error, has no meaning to retrieve more segments
 * 			of the same page.
 * 			4.- In order to retrieve as much information as it can be, all the
 * 			good pages and segments must be saved in order, with a hole of the
 * 			same size as a page initialized to all 0's  for the page/s in error
 * 			5.- As a result, a whole dump must be retained in one file that has
 * 			'fs_size' pages of 'page_size' of length totalizing 'fs_size' * 'page_size'
 * 			bytes. The bad pages will be recognized because if they are in 0, its checksum
 * 			will be wrong.
 * 			6.- Also, 'fs_size' and 'page_size' must be saved in reference to that file
 */

int dump_page( unsigned page_no, MUInt segment_no, uchar *pseg );

