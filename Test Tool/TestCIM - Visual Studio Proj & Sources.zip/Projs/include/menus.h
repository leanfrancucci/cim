/*
 * 		menus.h
 * 			Menu manager
 */
 
typedef struct
{
	char *menu_msg;
	int (*pfunc)( void );
} MENU_T;

void do_menu( const MENU_T *p );

int terminate( void );

void set_begin_char( int beg_char );
